"""
自我修正核心模块：自动优化 AI Prompt 和策略参数
"""

import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict, field
from datetime import datetime
from enum import Enum
from pathlib import Path


class OptimizationMethod(Enum):
    """优化方法"""
    GRID_SEARCH = "GRID_SEARCH"  # 网格搜索
    RANDOM_SEARCH = "RANDOM_SEARCH"  # 随机搜索
    BAYESIAN = "BAYESIAN"  # 贝叶斯优化
    GENETIC = "GENETIC"  # 遗传算法


@dataclass
class PromptVersion:
    """Prompt 版本"""
    version_id: str  # 版本 ID
    role: str  # 角色：trader, risk, reviewer
    content: str  # Prompt 内容
    created_at: str
    backtest_score: float = 0.0  # 回测评分
    is_active: bool = False  # 是否为当前活跃版本
    remarks: str = ""


@dataclass
class StrategyParameter:
    """策略参数"""
    param_name: str
    value: float
    min_value: float
    max_value: float
    step: float  # 调整步长
    description: str = ""


@dataclass
class OptimizationHistory:
    """优化历史"""
    iteration: int
    timestamp: str
    method: str
    parameters: Dict[str, float]
    metrics: Dict[str, float]
    improvement_pct: float


class SelfCorrectionEngine:
    """
    自我修正引擎：
    - 自动优化 Prompt 内容
    - 调整策略参数
    - 对比模型版本
    - 推荐最优配置
    """

    def __init__(self, prompt_dir: str, config_dir: str):
        """
        Args:
            prompt_dir: Prompt 文件所在目录
            config_dir: 配置文件所在目录
        """
        self.prompt_dir = Path(prompt_dir)
        self.config_dir = Path(config_dir)

        self.prompt_versions: Dict[str, List[PromptVersion]] = {
            "trader": [],
            "risk": [],
            "reviewer": [],
        }

        self.strategy_parameters: Dict[str, StrategyParameter] = {}
        self.optimization_history: List[OptimizationHistory] = []
        self.current_best_config: Dict = {}

        self._load_prompts()

    def _load_prompts(self):
        """加载现有 Prompt"""
        for role in ["trader", "risk", "reviewer"]:
            prompt_file = self.prompt_dir / f"role_{role}.md"

            if prompt_file.exists():
                with open(prompt_file, "r", encoding="utf-8") as f:
                    content = f.read()

                version = PromptVersion(
                    version_id=f"{role}_v1",
                    role=role,
                    content=content,
                    created_at=datetime.now().isoformat(),
                    is_active=True,
                )

                self.prompt_versions[role].append(version)

    def create_prompt_variant(
        self,
        role: str,
        original_content: str,
        modifications: Dict[str, str],
    ) -> PromptVersion:
        """
        创建 Prompt 变体（用于 A/B 测试）

        Args:
            role: 角色
            original_content: 原始内容
            modifications: 修改字典 {pattern: replacement}

        Returns:
            新的 Prompt 版本
        """
        modified_content = original_content

        for pattern, replacement in modifications.items():
            modified_content = modified_content.replace(pattern, replacement)

        # 生成版本 ID
        version_num = len(self.prompt_versions[role]) + 1
        version_id = f"{role}_v{version_num}_var"

        new_version = PromptVersion(
            version_id=version_id,
            role=role,
            content=modified_content,
            created_at=datetime.now().isoformat(),
            is_active=False,
        )

        self.prompt_versions[role].append(new_version)
        return new_version

    def suggest_prompt_modifications(
        self,
        backtest_results: Dict,
    ) -> Dict[str, Dict[str, str]]:
        """
        基于回测结果建议 Prompt 修改

        Args:
            backtest_results: 回测结果 {role: metrics}

        Returns:
            建议的修改 {role: {pattern: replacement}}
        """
        suggestions = {}

        # 交易官：如果胜率低，建议更保守
        if "trader" in backtest_results:
            trader_metrics = backtest_results["trader"]

            if trader_metrics.get("win_rate", 0) < 40:
                suggestions["trader"] = {
                    "# 决策置信度": "# 决策置信度 (严格要求 > 70%)",
                    "不允许拒绝决策": "除非置信度不足，否则不允许拒绝决策",
                }

            elif trader_metrics.get("win_rate", 0) > 70:
                suggestions["trader"] = {
                    "# 保守": "# 进攻性",
                    "严格": "灵活",
                }

        # 风控官：如果最大回撤大，建议更严格
        if "risk" in backtest_results:
            risk_metrics = backtest_results["risk"]

            if risk_metrics.get("max_drawdown", 0) > 20:
                suggestions["risk"] = {
                    "风险阈值": "风险阈值 (严格至 5%)",
                    "允许亏损": "不允许单次亏损超过总资金的 2%",
                }

        return suggestions

    def optimize_parameters(
        self,
        method: OptimizationMethod,
        parameters: Dict[str, StrategyParameter],
        backtest_function,  # 回测函数
        iterations: int = 10,
    ) -> Dict[str, float]:
        """
        优化策略参数

        Args:
            method: 优化方法
            parameters: 参数定义
            backtest_function: 回测函数 (params) -> score
            iterations: 迭代次数

        Returns:
            最优参数组合
        """
        self.strategy_parameters = parameters
        best_params = {}
        best_score = -float("inf")

        if method == OptimizationMethod.GRID_SEARCH:
            best_params, best_score = self._grid_search(
                parameters, backtest_function, iterations
            )

        elif method == OptimizationMethod.RANDOM_SEARCH:
            best_params, best_score = self._random_search(
                parameters, backtest_function, iterations
            )

        elif method == OptimizationMethod.BAYESIAN:
            best_params, best_score = self._bayesian_optimization(
                parameters, backtest_function, iterations
            )

        # 记录优化历史
        history_entry = OptimizationHistory(
            iteration=len(self.optimization_history) + 1,
            timestamp=datetime.now().isoformat(),
            method=method.value,
            parameters=best_params,
            metrics={"best_score": best_score},
            improvement_pct=0.0,  # 后续计算
        )

        self.optimization_history.append(history_entry)
        self.current_best_config = best_params

        return best_params

    def _grid_search(
        self,
        parameters: Dict[str, StrategyParameter],
        backtest_function,
        max_iterations: int,
    ) -> Tuple[Dict[str, float], float]:
        """网格搜索"""
        best_params = {}
        best_score = -float("inf")
        iterations = 0

        def generate_values(param: StrategyParameter):
            """生成参数网格值"""
            values = []
            current = param.min_value

            while current <= param.max_value:
                values.append(round(current, 4))
                current += param.step

            return values

        # 简化：只搜索第一个参数的网格（完整网格太耗时）
        if parameters:
            first_param_name = list(parameters.keys())[0]
            first_param = parameters[first_param_name]

            for value in generate_values(first_param):
                if iterations >= max_iterations:
                    break

                params = {
                    name: param.value for name, param in parameters.items()
                }
                params[first_param_name] = value

                try:
                    score = backtest_function(params)

                    if score > best_score:
                        best_score = score
                        best_params = params.copy()

                    iterations += 1

                except Exception as e:
                    print(f"Backtest failed for {params}: {e}")
                    continue

        return best_params, best_score

    def _random_search(
        self,
        parameters: Dict[str, StrategyParameter],
        backtest_function,
        iterations: int,
    ) -> Tuple[Dict[str, float], float]:
        """随机搜索"""
        import random

        best_params = {}
        best_score = -float("inf")

        for _ in range(iterations):
            params = {}

            for name, param in parameters.items():
                # 在范围内随机选择值
                value = random.uniform(param.min_value, param.max_value)
                params[name] = round(value, 4)

            try:
                score = backtest_function(params)

                if score > best_score:
                    best_score = score
                    best_params = params.copy()

            except Exception as e:
                print(f"Backtest failed for {params}: {e}")
                continue

        return best_params, best_score

    def _bayesian_optimization(
        self,
        parameters: Dict[str, StrategyParameter],
        backtest_function,
        iterations: int,
    ) -> Tuple[Dict[str, float], float]:
        """贝叶斯优化（简化实现）"""
        # 注：完整的贝叶斯优化需要 scikit-optimize 库
        # 这里使用随机搜索作为后备
        return self._random_search(parameters, backtest_function, iterations)

    def compare_prompt_versions(
        self, role: str
    ) -> List[Dict]:
        """
        对比同一角色的不同 Prompt 版本

        Args:
            role: 角色

        Returns:
            版本对比列表
        """
        if role not in self.prompt_versions:
            return []

        versions = self.prompt_versions[role]

        comparison = []

        for version in versions:
            comparison.append(
                {
                    "version_id": version.version_id,
                    "created_at": version.created_at,
                    "backtest_score": version.backtest_score,
                    "is_active": version.is_active,
                    "content_length": len(version.content),
                }
            )

        # 按回测评分排序
        comparison.sort(key=lambda x: x["backtest_score"], reverse=True)

        return comparison

    def activate_prompt_version(self, version_id: str) -> bool:
        """
        激活指定 Prompt 版本

        Args:
            version_id: 版本 ID

        Returns:
            是否激活成功
        """
        for role, versions in self.prompt_versions.items():
            for version in versions:
                if version.version_id == version_id:
                    # 将该角色的其他版本设为非活跃
                    for v in versions:
                        v.is_active = False

                    version.is_active = True
                    return True

        return False

    def update_prompt_score(
        self, version_id: str, score: float
    ) -> bool:
        """
        更新 Prompt 版本的回测评分

        Args:
            version_id: 版本 ID
            score: 评分

        Returns:
            是否更新成功
        """
        for role, versions in self.prompt_versions.items():
            for version in versions:
                if version.version_id == version_id:
                    version.backtest_score = score
                    return True

        return False

    def export_correction_report(self, filepath: str):
        """
        导出自我修正报告

        Args:
            filepath: 输出文件路径
        """
        report = {
            "export_time": datetime.now().isoformat(),
            "prompt_versions": {
                role: [
                    {
                        "version_id": v.version_id,
                        "created_at": v.created_at,
                        "backtest_score": v.backtest_score,
                        "is_active": v.is_active,
                    }
                    for v in versions
                ]
                for role, versions in self.prompt_versions.items()
            },
            "current_best_config": self.current_best_config,
            "optimization_history": [
                asdict(h) for h in self.optimization_history[-50:]
            ],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
