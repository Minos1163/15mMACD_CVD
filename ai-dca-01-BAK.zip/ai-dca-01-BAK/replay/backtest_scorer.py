"""
回测评分系统：评估 AI 策略的表现，支持对比和优化
"""

import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
import math


class MetricType(Enum):
    """指标类型"""
    RETURNS = "RETURNS"  # 收益率
    SHARPE_RATIO = "SHARPE_RATIO"  # 夏普比
    MAX_DRAWDOWN = "MAX_DRAWDOWN"  # 最大回撤
    WIN_RATE = "WIN_RATE"  # 胜率
    PROFIT_FACTOR = "PROFIT_FACTOR"  # 盈利因子
    SORTINO_RATIO = "SORTINO_RATIO"  # 索提诺比


@dataclass
class BacktestMetrics:
    """回测指标"""
    total_return_pct: float = 0.0  # 总收益率 (%)
    annualized_return_pct: float = 0.0  # 年化收益率 (%)
    sharpe_ratio: float = 0.0  # 夏普比
    sortino_ratio: float = 0.0  # 索提诺比
    max_drawdown_pct: float = 0.0  # 最大回撤 (%)
    win_rate_pct: float = 0.0  # 胜率 (%)
    profit_factor: float = 0.0  # 盈利因子 (赚钱交易总额/赔钱交易总额)
    num_trades: int = 0  # 交易次数
    num_winning_trades: int = 0  # 赢利交易数
    num_losing_trades: int = 0  # 亏损交易数
    avg_trade_return_pct: float = 0.0  # 平均交易收益率 (%)
    calmar_ratio: float = 0.0  # Calmar 比率
    recovery_factor: float = 0.0  # 恢复因子


@dataclass
class BacktestResult:
    """单个回测结果"""
    backtest_id: str  # 回测 ID
    strategy_name: str  # 策略名称
    model_version: str  # AI 模型版本
    parameters: Dict = field(default_factory=dict)  # 策略参数
    metrics: BacktestMetrics = field(default_factory=BacktestMetrics)
    start_date: str = ""  # 回测开始日期
    end_date: str = ""  # 回测结束日期
    created_at: str = ""  # 创建时间
    trades: List[Dict] = field(default_factory=list)  # 交易详情
    remarks: str = ""  # 备注


class BacktestScorer:
    """
    回测评分器：
    - 计算各种性能指标
    - 对比不同策略/模型
    - 自动筛选优秀模型
    """

    def __init__(self):
        self.results: Dict[str, BacktestResult] = {}  # backtest_id -> result
        self.result_history: List[BacktestResult] = []

    def create_backtest_result(
        self,
        strategy_name: str,
        model_version: str,
        parameters: Dict,
        start_date: str,
        end_date: str,
        remarks: str = "",
    ) -> BacktestResult:
        """
        创建回测结果对象

        Args:
            strategy_name: 策略名称
            model_version: AI 模型版本
            parameters: 策略参数
            start_date: 回测开始日期
            end_date: 回测结束日期
            remarks: 备注

        Returns:
            回测结果对象
        """
        backtest_id = f"BT_{int(datetime.now().timestamp() * 1000)}"

        result = BacktestResult(
            backtest_id=backtest_id,
            strategy_name=strategy_name,
            model_version=model_version,
            parameters=parameters,
            start_date=start_date,
            end_date=end_date,
            created_at=datetime.now().isoformat(),
            remarks=remarks,
        )

        self.results[backtest_id] = result
        self.result_history.append(result)
        return result

    def calculate_metrics(
        self,
        backtest_result: BacktestResult,
        initial_capital: float,
        final_capital: float,
        trades: List[Dict],
        risk_free_rate: float = 0.02,
    ) -> BacktestMetrics:
        """
        计算回测指标

        Args:
            backtest_result: 回测结果对象
            initial_capital: 初始资本
            final_capital: 最终资本
            trades: 交易列表
            risk_free_rate: 无风险利率（年化）

        Returns:
            计算后的指标
        """
        # 总收益率
        total_return = final_capital - initial_capital
        total_return_pct = (total_return / initial_capital * 100) if initial_capital > 0 else 0

        # 交易统计
        num_trades = len(trades)
        winning_trades = [t for t in trades if t.get("pnl", 0) > 0]
        losing_trades = [t for t in trades if t.get("pnl", 0) < 0]
        num_winning_trades = len(winning_trades)
        num_losing_trades = len(losing_trades)

        win_rate_pct = (num_winning_trades / num_trades * 100) if num_trades > 0 else 0

        # 盈利因子
        winning_amount = sum(t.get("pnl", 0) for t in winning_trades)
        losing_amount = abs(sum(t.get("pnl", 0) for t in losing_trades))
        if losing_amount == 0:
            profit_factor = 1000.0 if winning_amount > 0 else 0.0
        else:
            profit_factor = winning_amount / losing_amount

        # 平均交易收益率
        avg_trade_return_pct = (total_return_pct / num_trades) if num_trades > 0 else 0

        # 最大回撤
        max_drawdown_pct = self._calculate_max_drawdown(initial_capital, trades)

        # 年化收益率（假设数据为 1 年）
        annualized_return_pct = total_return_pct

        # 计算日收益率（用于夏普比和索提诺比）
        daily_returns = self._calculate_daily_returns(initial_capital, trades)

        # 夏普比
        sharpe_ratio = self._calculate_sharpe_ratio(
            daily_returns, risk_free_rate / 252
        )

        # 索提诺比
        sortino_ratio = self._calculate_sortino_ratio(
            daily_returns, risk_free_rate / 252
        )

        # Calmar 比率
        calmar_ratio = (
            (annualized_return_pct / max(max_drawdown_pct, 0.01))
            if max_drawdown_pct > 0
            else 0
        )

        # 恢复因子
        recovery_factor = (
            (total_return / max_drawdown_pct) if max_drawdown_pct > 0 else 0
        )

        metrics = BacktestMetrics(
            total_return_pct=round(total_return_pct, 2),
            annualized_return_pct=round(annualized_return_pct, 2),
            sharpe_ratio=round(sharpe_ratio, 2),
            sortino_ratio=round(sortino_ratio, 2),
            max_drawdown_pct=round(max_drawdown_pct, 2),
            win_rate_pct=round(win_rate_pct, 2),
            profit_factor=round(profit_factor, 2),
            num_trades=num_trades,
            num_winning_trades=num_winning_trades,
            num_losing_trades=num_losing_trades,
            avg_trade_return_pct=round(avg_trade_return_pct, 2),
            calmar_ratio=round(calmar_ratio, 2),
            recovery_factor=round(recovery_factor, 2),
        )

        backtest_result.metrics = metrics
        backtest_result.trades = trades

        return metrics

    def _calculate_max_drawdown(
        self, initial_capital: float, trades: List[Dict]
    ) -> float:
        """计算最大回撤 (%)"""
        capital = initial_capital
        peak_capital = initial_capital
        max_drawdown = 0.0

        for trade in sorted(trades, key=lambda x: x.get("timestamp", 0)):
            pnl = trade.get("pnl", 0)
            capital += pnl

            if capital > peak_capital:
                peak_capital = capital

            drawdown = (peak_capital - capital) / peak_capital if peak_capital > 0 else 0
            max_drawdown = max(max_drawdown, drawdown)

        return max_drawdown * 100

    def _calculate_daily_returns(
        self, initial_capital: float, trades: List[Dict]
    ) -> List[float]:
        """计算日收益率"""
        daily_returns = []
        capital = initial_capital

        # 简化：假设每笔交易为一个周期
        for trade in trades:
            pnl = trade.get("pnl", 0)
            capital += pnl
            daily_return = pnl / capital if capital > 0 else 0
            daily_returns.append(daily_return)

        return daily_returns

    def _calculate_sharpe_ratio(
        self, returns: List[float], risk_free_rate: float
    ) -> float:
        """计算夏普比"""
        if not returns or len(returns) < 2:
            return 0.0

        avg_return = sum(returns) / len(returns)
        variance = sum((r - avg_return) ** 2 for r in returns) / len(returns)
        std_dev = math.sqrt(variance) if variance > 0 else 0.001

        return (avg_return - risk_free_rate) / std_dev if std_dev > 0 else 0

    def _calculate_sortino_ratio(
        self, returns: List[float], risk_free_rate: float
    ) -> float:
        """计算索提诺比（只考虑下方波动）"""
        if not returns or len(returns) < 2:
            return 0.0

        avg_return = sum(returns) / len(returns)

        # 只考虑负收益的波动
        downside_returns = [r for r in returns if r < risk_free_rate]

        if not downside_returns:
            # 没有下行波动，视为完美风险调整收益，返回一个较大的有限值
            return 1000.0

        downside_variance = sum((r - risk_free_rate) ** 2 for r in downside_returns) / len(returns)
        downside_std = math.sqrt(downside_variance) if downside_variance > 0 else 0.001

        return (avg_return - risk_free_rate) / downside_std if downside_std > 0 else 0

    def compare_results(
        self, result_ids: List[str], metric: MetricType = MetricType.SHARPE_RATIO
    ) -> Dict:
        """
        对比多个回测结果

        Args:
            result_ids: 回测 ID 列表
            metric: 比较指标

        Returns:
            对比结果
        """
        comparison = {
            "metric": metric.value,
            "results": [],
        }

        for result_id in result_ids:
            if result_id not in self.results:
                continue

            result = self.results[result_id]
            metric_value = getattr(result.metrics, metric.value.lower())

            comparison["results"].append(
                {
                    "backtest_id": result_id,
                    "strategy_name": result.strategy_name,
                    "model_version": result.model_version,
                    "metric_value": metric_value,
                }
            )

        # 按指标值从高到低排序
        comparison["results"].sort(
            key=lambda x: x["metric_value"], reverse=True
        )

        return comparison

    def select_best_result(
        self, result_ids: List[str]
    ) -> Optional[BacktestResult]:
        """
        从多个结果中选择最好的（基于综合评分）

        Args:
            result_ids: 回测 ID 列表

        Returns:
            最好的回测结果
        """
        best_result = None
        best_score = -float("inf")

        for result_id in result_ids:
            if result_id not in self.results:
                continue

            result = self.results[result_id]
            # 综合评分：夏普比 + 胜率 - 最大回撤
            score = (
                result.metrics.sharpe_ratio * 2
                + result.metrics.win_rate_pct
                - result.metrics.max_drawdown_pct
            )

            if score > best_score:
                best_score = score
                best_result = result

        return best_result

    def export_results(self, filepath: str):
        """导出所有回测结果"""
        export_data = {
            "export_time": datetime.now().isoformat(),
            "total_backtests": len(self.result_history),
            "results": [
                {
                    "backtest_id": r.backtest_id,
                    "strategy_name": r.strategy_name,
                    "model_version": r.model_version,
                    "parameters": r.parameters,
                    "metrics": asdict(r.metrics),
                    "start_date": r.start_date,
                    "end_date": r.end_date,
                    "created_at": r.created_at,
                    "remarks": r.remarks,
                }
                for r in self.result_history
            ],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)

    def get_summary(self) -> Dict:
        """获取回测汇总"""
        if not self.result_history:
            return {
                "total_backtests": 0,
                "avg_sharpe_ratio": 0,
                "avg_win_rate": 0,
            }

        total = len(self.result_history)
        avg_sharpe = sum(r.metrics.sharpe_ratio for r in self.result_history) / total
        avg_win_rate = sum(r.metrics.win_rate_pct for r in self.result_history) / total

        return {
            "total_backtests": total,
            "avg_sharpe_ratio": round(avg_sharpe, 2),
            "avg_win_rate_pct": round(avg_win_rate, 2),
            "best_model": (
                max(
                    self.result_history,
                    key=lambda r: r.metrics.sharpe_ratio,
                ).model_version
                if self.result_history
                else "N/A"
            ),
        }
