"""
回放引擎：支持历史数据的回测和分析
"""

import json
import gzip
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from enum import Enum


class ReplayMode(Enum):
    """回放模式"""
    BACKTEST = "BACKTEST"  # 历史回测
    FORWARD_TEST = "FORWARD_TEST"  # 前向测试（实时记录）
    REPLAY = "REPLAY"  # 回放（复现历史）


@dataclass
class MarketSnapshot:
    """市场快照"""
    timestamp: float  # 时间戳
    symbol: str
    price: float
    volume: float
    bid: float  # 买一价
    ask: float  # 卖一价
    high_24h: float
    low_24h: float
    momentum_24h: float  # 涨幅 %
    volatility: float


@dataclass
class AccountSnapshot:
    """账户快照"""
    timestamp: float
    balance: float  # 总资产
    available: float  # 可用资金
    positions: Dict[str, float] = field(default_factory=dict)  # symbol -> quantity
    positions_value: float = 0.0  # 持仓总价值
    unrealized_pnl: float = 0.0  # 未实现损益
    realized_pnl: float = 0.0  # 已实现损益


@dataclass
class Decision:
    """AI 决策记录"""
    timestamp: float
    decision_id: str
    symbol: str
    action: str  # BUY, SELL, HOLD
    quantity: float
    confidence: float  # 置信度 0-1
    reasoning: str
    model_version: str


class ReplayEngine:
    """
    回放引擎：
    - 加载历史市场数据
    - 模拟 AI 决策执行
    - 记录回放过程中的所有状态变化
    - 支持对 AI 决策的事后分析
    """

    def __init__(self, mode: ReplayMode = ReplayMode.BACKTEST):
        self.mode = mode
        self.market_snapshots: List[MarketSnapshot] = []
        self.account_snapshots: List[AccountSnapshot] = []
        self.decisions: List[Decision] = []
        self.trades: List[Dict] = []
        self.current_index = 0
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None

    def load_market_data_from_file(self, filepath: str) -> bool:
        """
        从文件加载市场数据

        Args:
            filepath: 数据文件路径（支持 .jsonl 和 .jsonl.gz）

        Returns:
            是否加载成功
        """
        path = Path(filepath)

        if not path.exists():
            return False

        try:
            if filepath.endswith(".gz"):
                with gzip.open(filepath, "rt", encoding="utf-8") as f:
                    lines = f.readlines()
            else:
                with open(filepath, "r", encoding="utf-8") as f:
                    lines = f.readlines()

            self.market_snapshots.clear()

            for line in lines:
                if not line.strip():
                    continue

                data = json.loads(line)
                snapshot = MarketSnapshot(
                    timestamp=data["timestamp"],
                    symbol=data["symbol"],
                    price=data["price"],
                    volume=data.get("volume", 0),
                    bid=data.get("bid", data["price"]),
                    ask=data.get("ask", data["price"]),
                    high_24h=data.get("high_24h", data["price"]),
                    low_24h=data.get("low_24h", data["price"]),
                    momentum_24h=data.get("momentum_24h", 0),
                    volatility=data.get("volatility", 0),
                )
                self.market_snapshots.append(snapshot)

            # 排序
            self.market_snapshots.sort(key=lambda x: x.timestamp)

            if self.market_snapshots:
                self.start_time = self.market_snapshots[0].timestamp
                self.end_time = self.market_snapshots[-1].timestamp

            return True

        except Exception as e:
            print(f"Failed to load market data: {e}")
            return False

    def load_decisions_from_file(self, filepath: str) -> bool:
        """
        从文件加载 AI 决策

        Args:
            filepath: 决策文件路径

        Returns:
            是否加载成功
        """
        path = Path(filepath)

        if not path.exists():
            return False

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                lines = f.readlines()

            self.decisions.clear()

            for line in lines:
                if not line.strip():
                    continue

                data = json.loads(line)
                decision = Decision(
                    timestamp=data["timestamp"],
                    decision_id=data["decision_id"],
                    symbol=data["symbol"],
                    action=data["action"],
                    quantity=data["quantity"],
                    confidence=data.get("confidence", 0.5),
                    reasoning=data.get("reasoning", ""),
                    model_version=data.get("model_version", "unknown"),
                )
                self.decisions.append(decision)

            # 排序
            self.decisions.sort(key=lambda x: x.timestamp)
            return True

        except Exception as e:
            print(f"Failed to load decisions: {e}")
            return False

    def record_market_snapshot(self, snapshot: MarketSnapshot):
        """记录市场快照"""
        self.market_snapshots.append(snapshot)

        if self.start_time is None:
            self.start_time = snapshot.timestamp

        self.end_time = snapshot.timestamp

    def record_account_snapshot(self, snapshot: AccountSnapshot):
        """记录账户快照"""
        self.account_snapshots.append(snapshot)

    def record_decision(self, decision: Decision):
        """记录 AI 决策"""
        self.decisions.append(decision)

    def record_trade(self, trade: Dict):
        """记录交易"""
        self.trades.append(trade)

    def get_market_data_at_time(
        self, timestamp: float, symbol: Optional[str] = None
    ) -> List[MarketSnapshot]:
        """
        获取指定时间的市场数据

        Args:
            timestamp: 时间戳
            symbol: 币种（可选，不指定则返回所有币种）

        Returns:
            市场快照列表
        """
        snapshots = [
            s for s in self.market_snapshots if abs(s.timestamp - timestamp) < 1
        ]

        if symbol:
            snapshots = [s for s in snapshots if s.symbol == symbol]

        return snapshots

    def get_account_performance(self) -> Dict:
        """
        计算账户绩效

        Returns:
            绩效指标字典
        """
        if not self.account_snapshots:
            return {}

        start_snapshot = self.account_snapshots[0]
        end_snapshot = self.account_snapshots[-1]

        initial_balance = start_snapshot.balance
        final_balance = end_snapshot.balance
        total_return = final_balance - initial_balance
        return_pct = (total_return / initial_balance * 100) if initial_balance > 0 else 0

        # 计算最大回撤
        max_balance = initial_balance
        max_drawdown = 0.0

        for snapshot in self.account_snapshots:
            if snapshot.balance > max_balance:
                max_balance = snapshot.balance
            drawdown = (max_balance - snapshot.balance) / max_balance
            max_drawdown = max(max_drawdown, drawdown)

        return {
            "initial_balance": round(initial_balance, 2),
            "final_balance": round(final_balance, 2),
            "total_return_usd": round(total_return, 2),
            "return_pct": round(return_pct, 2),
            "max_drawdown_pct": round(max_drawdown * 100, 2),
            "num_snapshots": len(self.account_snapshots),
        }

    def get_decision_accuracy(self) -> Dict:
        """
        分析 AI 决策准确性

        Returns:
            准确性指标
        """
        if not self.decisions or not self.market_snapshots:
            return {}

        correct_predictions = 0
        buy_decisions = 0
        sell_decisions = 0

        for decision in self.decisions:
            if decision.action == "BUY":
                buy_decisions += 1
                # 检查决策后价格是否上涨
                future_price = self._get_future_price(
                    decision.timestamp, decision.symbol, lookAhead=3600
                )
                if future_price and future_price > decision.confidence * 100:
                    correct_predictions += 1

            elif decision.action == "SELL":
                sell_decisions += 1
                # 检查决策后价格是否下跌
                future_price = self._get_future_price(
                    decision.timestamp, decision.symbol, lookAhead=3600
                )
                if future_price and future_price < 100 / decision.confidence:
                    correct_predictions += 1

        total_decisions = len(self.decisions)
        accuracy = (correct_predictions / total_decisions * 100) if total_decisions > 0 else 0

        return {
            "total_decisions": total_decisions,
            "buy_decisions": buy_decisions,
            "sell_decisions": sell_decisions,
            "correct_predictions": correct_predictions,
            "accuracy_pct": round(accuracy, 2),
            "avg_confidence": round(
                sum(d.confidence for d in self.decisions) / total_decisions, 2
            ),
        }

    def _get_future_price(
        self, timestamp: float, symbol: str, lookAhead: int = 3600
    ) -> Optional[float]:
        """
        获取未来某个时间的价格

        Args:
            timestamp: 当前时间戳
            symbol: 币种
            lookAhead: 前向看多少秒

        Returns:
            价格（如果存在）
        """
        target_time = timestamp + lookAhead

        for snapshot in self.market_snapshots:
            if snapshot.symbol == symbol and abs(snapshot.timestamp - target_time) < 60:
                return snapshot.price

        return None

    def export_replay_report(self, filepath: str):
        """
        导出回放报告

        Args:
            filepath: 输出文件路径
        """
        report = {
            "replay_mode": self.mode.value,
            "data_summary": {
                "market_snapshots": len(self.market_snapshots),
                "account_snapshots": len(self.account_snapshots),
                "decisions": len(self.decisions),
                "trades": len(self.trades),
                "start_time": datetime.fromtimestamp(self.start_time).isoformat()
                if self.start_time
                else None,
                "end_time": datetime.fromtimestamp(self.end_time).isoformat()
                if self.end_time
                else None,
            },
            "account_performance": self.get_account_performance(),
            "decision_accuracy": self.get_decision_accuracy(),
            "exported_at": datetime.now().isoformat(),
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
