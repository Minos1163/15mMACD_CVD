# -*- coding: utf-8 -*-
"""
Monte Carlo runner for backtest: runs baseline (AI disabled) and AI-enabled backtests
with controlled price noise and paired seeds, then computes bootstrap p-value for mean
return difference.
"""
import os
import subprocess
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).parent
PYTHON = os.getenv('VENV_PYTHON', str(Path(ROOT / '..' / '.venv' / 'Scripts' / 'python.exe')))

def run_once(seed: int, noise: float, ai_enabled: bool):
    env = os.environ.copy()
    env['MC_NOISE_STD'] = str(noise)
    env['MC_SEED'] = str(seed)
    env['AI_ENABLED'] = '1' if ai_enabled else '0'

    cmd = [PYTHON, str(ROOT / 'test_full_backtest.py')]
    proc = subprocess.run(cmd, env=env, cwd=str(ROOT))
    if proc.returncode != 0:
        raise RuntimeError(f"Backtest failed (seed={seed}, ai={ai_enabled})")
    # read report
    report_path = ROOT / 'storage' / 'backtest_report.json'
    with open(report_path, 'r', encoding='utf-8') as f:
        report = json.load(f)
    return report['capital']['return_pct']


def bootstrap_pvalue(diffs, n_boot=1000):
    import random
    n = len(diffs)
    boot_means = []
    for _ in range(n_boot):
        sample = [random.choice(diffs) for _ in range(n)]
        boot_means.append(statistics.mean(sample))
    # one-sided p-value: probability mean_diff <= 0
    p = sum(1 for m in boot_means if m <= 0) / len(boot_means)
    return p, statistics.mean(boot_means), statistics.stdev(boot_means)


def main(runs=30, noise=0.005):
    baseline_results = []
    ai_results = []

    for i in range(runs):
        print(f"Running baseline (AI off) seed={i}...")
        base = run_once(seed=i, noise=noise, ai_enabled=False)
        baseline_results.append(base)
        print(f" baseline return: {base:+.2f}%")

        print(f"Running AI-enabled seed={i}...")
        ai = run_once(seed=i, noise=noise, ai_enabled=True)
        ai_results.append(ai)
        print(f" AI return: {ai:+.2f}%")

    diffs = [ai - b for ai, b in zip(ai_results, baseline_results)]

    mean_base = statistics.mean(baseline_results)
    mean_ai = statistics.mean(ai_results)
    mean_diff = statistics.mean(diffs)
    sd_diff = statistics.stdev(diffs) if len(diffs) > 1 else 0.0

    p, boot_mean, boot_sd = bootstrap_pvalue(diffs, n_boot=2000)

    result = {
        'runs': runs,
        'noise': noise,
        'baseline_mean_return_pct': mean_base,
        'ai_mean_return_pct': mean_ai,
        'mean_diff_pct': mean_diff,
        'sd_diff_pct': sd_diff,
        'bootstrap_mean': boot_mean,
        'bootstrap_sd': boot_sd,
        'p_value_one_sided': p,
        'baseline_results': baseline_results,
        'ai_results': ai_results,
        'diffs': diffs
    }

    out_path = ROOT / 'storage' / 'montecarlo_results.json'
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print('\nMonte Carlo completed:')
    print(f" baseline mean: {mean_base:.2f}%")
    print(f" AI mean:       {mean_ai:.2f}%")
    print(f" mean diff:     {mean_diff:.2f}%")
    print(f" sd diff:       {sd_diff:.2f}%")
    print(f" bootstrap p-value (one-sided AI>baseline): {p:.4f}")
    print(f" Results saved: {out_path}")

if __name__ == '__main__':
    main(runs=30, noise=0.01)
