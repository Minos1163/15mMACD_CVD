#!/usr/bin/env python3
"""
测试读取 Binance 账户信息
"""

import sys
import os
from pathlib import Path
from dotenv import load_dotenv
import json

# 加载 .env 文件
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

# 获取 API 凭证
api_key = os.getenv("BINANCE_API_KEY")
api_secret = os.getenv("BINANCE_SECRET")

print("=" * 80)
print("🔍 Binance 账户信息测试")
print("=" * 80)

# ========== 环境检查 ==========
print("\n📋 环境检查")
print("-" * 80)

if not api_key:
    print("❌ 错误: 未找到 BINANCE_API_KEY")
    sys.exit(1)

if not api_secret:
    print("❌ 错误: 未找到 BINANCE_SECRET")
    sys.exit(1)

print(f"✅ API Key 已配置: {api_key[:10]}...{api_key[-5:]}")
print(f"✅ Secret 已配置: {api_secret[:10]}...{api_secret[-5:]}")

# 导入 Broker
from broker.binance_broker import BinanceBroker, AccountMode, ApiCapability

print("\n" + "=" * 80)
print("🔗 Binance Broker 初始化")
print("=" * 80)

try:
    broker = BinanceBroker(api_key=api_key, api_secret=api_secret)
    print(f"\n✅ Broker 已初始化")
    print(f"   账户模式: {broker.mode.value}")
    print(f"   API 能力: {broker.capability.value}")
except Exception as e:
    print(f"\n❌ 初始化失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# ========== 获取现货账户信息 ==========
print("\n" + "=" * 80)
print("💰 现货账户信息")
print("-" * 80)

try:
    spot_account = broker.get_spot_account()
    
    if spot_account:
        print("✅ 成功获取现货账户信息")
        
        # 显示关键信息
        if "balances" in spot_account:
            balances = spot_account["balances"]
            
            # 显示非零余额
            print(f"\n   总资产数量: {len(balances)}")
            
            non_zero = [b for b in balances if float(b["free"]) > 0 or float(b["locked"]) > 0]
            print(f"   非零余额: {len(non_zero)} 个")
            
            print("\n   💵 主要资产:")
            
            for balance in sorted(non_zero, key=lambda x: float(x["locked"]) + float(x["free"]), reverse=True)[:10]:
                asset = balance["asset"]
                free = float(balance["free"])
                locked = float(balance["locked"])
                total = free + locked
                
                if total > 0:
                    print(f"      {asset:8s}: 可用={free:15.8f}, 锁定={locked:15.8f}, 总计={total:15.8f}")
        
        # 显示完整数据样本
        if "makeCommission" in spot_account:
            print(f"\n   交易佣金:")
            print(f"      Maker: {spot_account['makeCommission']}%")
            print(f"      Taker: {spot_account['takerCommission']}%")
    else:
        print("❌ 获取现货账户失败")

except Exception as e:
    print(f"❌ 异常: {e}")
    import traceback
    traceback.print_exc()

# ========== 获取合约账户信息 ==========
print("\n" + "=" * 80)
print("📈 U本位合约账户信息")
print("-" * 80)

try:
    um_account = broker.get_um_account()
    
    if um_account:
        print("✅ 成功获取 U 本位合约账户信息")
        
        account_type = um_account.get("type", "Unknown")
        print(f"\n   账户类型: {account_type}")
        
        if account_type == "UNIFIED":
            print(f"   账户权益: {um_account.get('equity', 0):.2f} USDT")
            print(f"   可用余额: {um_account.get('available', 0):.2f} USDT")
            print(f"   账户状态: {um_account.get('status', 'Unknown')}")
        else:
            print(f"   钱包余额: {um_account.get('wallet_balance', 0):.2f} USDT")
            print(f"   可用余额: {um_account.get('available', 0):.2f} USDT")
            
            if "note" in um_account:
                print(f"   说明: {um_account['note']}")
    else:
        print("❌ 获取合约账户失败")

except Exception as e:
    print(f"❌ 异常: {e}")
    import traceback
    traceback.print_exc()

# ========== 获取合约持仓 ==========
print("\n" + "=" * 80)
print("📊 合约持仓信息")
print("-" * 80)

try:
    positions = broker.get_um_positions()
    
    if positions is not None:
        print(f"✅ 成功获取合约持仓: {len(positions)} 个持仓")
        
        if positions:
            print("\n   📍 持仓详情:")
            for pos in positions[:10]:  # 显示前 10 个持仓
                symbol = pos.get("symbol", "Unknown")
                position_amt = float(pos.get("positionAmt", 0))
                entry_price = float(pos.get("entryPrice", 0))
                mark_price = float(pos.get("markPrice", 0))
                
                if position_amt != 0:
                    side = "LONG" if position_amt > 0 else "SHORT"
                    unrealized_pnl = float(pos.get("unRealizedProfit", 0))
                    roi = float(pos.get("roe", 0)) * 100 if "roe" in pos else 0
                    
                    print(f"      {symbol:12s} | {side:5s} | 数量={abs(position_amt):12.4f} | " + 
                          f"入场={entry_price:12.2f} | 标记={mark_price:12.2f} | " +
                          f"未实现PnL={unrealized_pnl:12.2f} USDT | ROE={roi:6.2f}%")
        else:
            print("   📍 当前无持仓")
    else:
        print("❌ 获取持仓失败")

except Exception as e:
    print(f"❌ 异常: {e}")
    import traceback
    traceback.print_exc()

# ========== 获取账户快照 ==========
print("\n" + "=" * 80)
print("📸 账户快照")
print("-" * 80)

try:
    snapshot = broker.get_account_snapshot()
    
    if snapshot:
        print("✅ 成功获取账户快照")
        print(f"\n   现货 USDT: {snapshot.get('spot_usdt', 0):.2f}")
        print(f"   U 本位权益: {snapshot.get('um_equity', 0):.2f}")
        print(f"   U 本位可用: {snapshot.get('um_available', 0):.2f}")
        print(f"   持仓数量: {snapshot.get('positions', 0)}")
        
        total_value = (snapshot.get('spot_usdt', 0) + 
                      snapshot.get('um_equity', 0))
        print(f"   总资产价值: {total_value:.2f} USDT")
    else:
        print("❌ 获取快照失败")

except Exception as e:
    print(f"❌ 异常: {e}")
    import traceback
    traceback.print_exc()

# ========== 测试总结 ==========
print("\n" + "=" * 80)
print("📊 测试总结")
print("=" * 80)

print("""
✅ 如果上面所有测试都成功，说明：
   - API Key 和 Secret 是有效的
   - 有读取账户权限
   - 网络连接正常
   - 可以在主程序中集成

⚠️ 常见问题排查：
   1. "Invalid API key" → 检查 API Key 是否完整
   2. "IP not allowed" → 检查 API Key 的 IP 白名单
   3. "Signature invalid" → 检查 Secret 是否正确
   4. "Unauthorized" → 检查 API Key 权限设置
   5. 获取 PAPI 账户失败 → 可能是 Classic 账户

💡 建议：
   1. 在本地充分测试账户读取功能
   2. 记录账户快照用于对账
   3. 实现定期账户同步
   4. 设置异常告警
   5. 定期检查 API 密钥的有效性
""")

print("\n✅ 测试完成！")
