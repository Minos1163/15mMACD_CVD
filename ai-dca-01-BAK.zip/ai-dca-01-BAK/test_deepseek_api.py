#!/usr/bin/env python3
"""
测试 DeepSeek API 是否可用
"""

import sys
import os
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env 文件
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

# 获取 API Key
api_key = os.getenv("DEEPSEEK_API_KEY")

print("=" * 80)
print("🔍 DeepSeek API 测试")
print("=" * 80)

if not api_key:
    print("❌ 错误: 未找到 DEEPSEEK_API_KEY")
    sys.exit(1)

print(f"✅ 找到 API Key: {api_key[:10]}...{api_key[-5:]}")

# 导入 DeepSeek 客户端
from ai.deepseek_client import DeepSeekClient

# 初始化客户端
client = DeepSeekClient(api_key=api_key)

# 测试 1: 简单的 JSON 响应
print("\n" + "=" * 80)
print("📝 测试 1: 简单的交易决策请求")
print("=" * 80)

system_prompt = """你是一个专业的加密货币量化交易 AI。
请以 JSON 格式返回交易决策，包含以下字段：
- action: "BUY" / "SELL" / "HOLD"
- confidence: 0-1 之间的置信度
- reasoning: 决策理由"""

user_prompt = """当前 BTCUSDT 价格 42000，24小时涨幅 2.5%，RSI 65。
请给出交易建议。"""

try:
    print("\n📤 发送请求...")
    print(f"   系统提示: {system_prompt[:50]}...")
    print(f"   用户问题: {user_prompt}")
    
    response = client.ask(user_prompt, system_prompt=system_prompt)
    
    print("\n📥 收到响应:")
    import json
    print(json.dumps(response, indent=2, ensure_ascii=False))
    
    if "error" in response:
        print(f"\n❌ API 返回错误: {response['error']}")
    else:
        print("\n✅ API 响应成功！")
        
except Exception as e:
    print(f"\n❌ 请求失败: {e}")
    import traceback
    traceback.print_exc()

# 测试 2: Mock 决策（备用方案）
print("\n" + "=" * 80)
print("📝 测试 2: Mock 决策（本地生成）")
print("=" * 80)

try:
    mock_response = client.mock_decision()
    print("\n✅ Mock 决策:")
    import json
    print(json.dumps(mock_response, indent=2, ensure_ascii=False))
except Exception as e:
    print(f"❌ Mock 决策失败: {e}")

# 测试 3: 测试不同的温度参数
print("\n" + "=" * 80)
print("📝 测试 3: 测试温度参数（temperature）")
print("=" * 80)

temperatures = [0.1, 0.5, 0.9]

for temp in temperatures:
    try:
        print(f"\n🌡️ 温度 = {temp} (创意度)")
        response = client.ask(
            "用一句话总结：什么是区块链？",
            temperature=temp
        )
        if "error" not in response:
            print(f"✅ 成功 (响应长度: {len(str(response))} 字符)")
        else:
            print(f"⚠️ 返回错误: {response['error'][:50]}...")
    except Exception as e:
        print(f"❌ 失败: {str(e)[:50]}...")

# 最终报告
print("\n" + "=" * 80)
print("📊 测试总结")
print("=" * 80)

print("""
✅ 如果上面的测试都成功了，说明：
   - API Key 是有效的
   - 网络连接正常
   - DeepSeek 服务可用
   - 可以在生产环境中使用

⚠️ 如果部分测试失败，可能是：
   - API Key 过期或无效 → 更新 .env 文件
   - 网络问题 → 检查网络连接
   - API 服务故障 → 稍后重试
   - 模型参数问题 → 调整 temperature 等参数

📌 常见问题：
   1. "Invalid API key" → 检查 API Key 是否复制完整
   2. "Rate limit exceeded" → 减少请求频率
   3. "Connection timeout" → 检查网络和防火墙
   4. "Model not found" → 使用正确的模型名称（deepseek-chat）
""")

print("\n✅ 测试完成！")
