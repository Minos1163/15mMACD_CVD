#!/usr/bin/env python3
"""
轮动策略测试：验证轮动引擎在多个策略下的功能
"""

import sys
import json
from datetime import datetime
from pathlib import Path

# 导入轮动引擎
from strategy.rotation_engine import RotationEngine, RotationStrategy, RotationCandidate

print("=" * 80)
print("🔄 轮动策略测试")
print("=" * 80)

# ========== 测试数据 ==========
print("\n📊 准备市场测试数据")
print("-" * 80)

market_data = {
    "BTCUSDT": {
        "current_price": 92000,
        "momentum_24h": 2.5,  # 近24小时涨2.5%
        "momentum_7d": 8.0,   # 近7天涨8%
        "volatility": 0.015,  # 1.5%波动率
        "rsi": 65,  # RSI 65（接近超买）
    },
    "ETHUSDT": {
        "current_price": 3150,
        "momentum_24h": -1.2,  # 下跌1.2%
        "momentum_7d": 3.5,   # 近7天涨3.5%
        "volatility": 0.018,  # 1.8%波动率
        "rsi": 35,  # RSI 35（接近超卖）
    },
    "BNBUSDT": {
        "current_price": 920,
        "momentum_24h": 0.8,   # 小幅上涨
        "momentum_7d": 5.2,   # 近7天涨5.2%
        "volatility": 0.012,  # 1.2%波动率（最低）
        "rsi": 52,  # RSI 52（中性）
    },
    "ADAUSDT": {
        "current_price": 1.25,
        "momentum_24h": -2.5,  # 下跌2.5%
        "momentum_7d": -5.0,  # 近7天跌5%
        "volatility": 0.022,  # 2.2%波动率（较高）
        "rsi": 28,  # RSI 28（超卖）
    },
    "SOLUSDT": {
        "current_price": 185,
        "momentum_24h": 3.2,   # 上涨3.2%
        "momentum_7d": 12.5,  # 近7天涨12.5%（最高）
        "volatility": 0.025,  # 2.5%波动率
        "rsi": 72,  # RSI 72（超买）
    },
}

print(f"✅ 市场数据已准备（{len(market_data)} 个币种）")
for symbol, metrics in market_data.items():
    print(f"   {symbol}: ${metrics['current_price']}, "
          f"24h: {metrics['momentum_24h']:+.1f}%, "
          f"7d: {metrics['momentum_7d']:+.1f}%, "
          f"VOL: {metrics['volatility']*100:.1f}%, "
          f"RSI: {metrics['rsi']:.0f}")

# ========== 测试各策略 ==========
strategies_to_test = [
    RotationStrategy.MOMENTUM,
    RotationStrategy.MEAN_REVERSION,
    RotationStrategy.VOLATILITY,
    RotationStrategy.SHARPE,
]

results = {}

for strategy in strategies_to_test:
    print(f"\n" + "=" * 80)
    print(f"🧪 测试策略: {strategy.value}")
    print("=" * 80)

    # 初始化轮动引擎
    rotation_engine = RotationEngine(strategy=strategy)
    print(f"✅ 轮动引擎已初始化（策略: {strategy.value}）")

    # 评估候选币种
    print(f"\n📈 评估候选币种...")
    candidates = rotation_engine.evaluate_candidates(market_data)

    print(f"✅ 评估完成，排名前 5：")
    for i, candidate in enumerate(candidates[:5], 1):
        print(f"   {i}. {candidate.symbol}: "
              f"评分 {candidate.score:.2f} | "
              f"分配 {candidate.recommended_allocation:.1f}%")

    # 生成新分配
    new_allocation = {
        candidate.symbol: candidate.recommended_allocation
        for candidate in candidates
    }

    # 假设之前的分配（初始均匀分配）
    old_allocation = {symbol: 20.0 for symbol in market_data.keys()}

    print(f"\n🔄 轮动判断:")
    should_rotate = rotation_engine.should_rotate(old_allocation, new_allocation, min_change_pct=10.0)
    print(f"   旧分配: {old_allocation}")
    print(f"   新分配: {new_allocation}")
    print(f"   是否应该轮动: {'✅ 是' if should_rotate else '❌ 否'}")

    if should_rotate:
        # 执行轮动
        current_prices = {sym: metrics['current_price'] for sym, metrics in market_data.items()}
        current_positions = {sym: 0.1 for sym in market_data.keys()}

        print(f"\n💫 执行轮动...")
        rotation_plan = rotation_engine.execute_rotation(
            old_allocation=old_allocation,
            new_allocation=new_allocation,
            current_positions=current_positions,
            current_prices=current_prices,
        )

        print(f"✅ 轮动计划生成：")
        for symbol, plan in rotation_plan.items():
            if plan['action'] != 'HOLD':
                print(f"   {symbol}: {plan['action']} "
                      f"({plan['old_allocation_pct']:.1f}% → {plan['new_allocation_pct']:.1f}%)")

    # 保存结果
    results[strategy.value] = {
        "candidates": [
            {
                "symbol": c.symbol,
                "score": c.score,
                "allocation": c.recommended_allocation,
                "momentum_24h": c.momentum_24h,
                "momentum_7d": c.momentum_7d,
                "volatility": c.volatility,
                "rsi": c.rsi,
            }
            for c in candidates[:5]
        ],
        "should_rotate": should_rotate,
        "timestamp": datetime.now().isoformat(),
    }

# ========== 对比分析 ==========
print(f"\n" + "=" * 80)
print(f"📊 策略对比分析")
print("=" * 80)

print(f"\n各策略推荐的 Top 1 币种：")
for strategy_name, result in results.items():
    if result['candidates']:
        top = result['candidates'][0]
        print(f"   {strategy_name:20s}: {top['symbol']} "
              f"(评分: {top['score']:.2f}, 分配: {top['allocation']:.1f}%)")

# ========== 保存报告 ==========
print(f"\n" + "=" * 80)
print(f"💾 保存报告")
print("=" * 80)

report_file = Path(__file__).parent / "storage" / "rotation_test_report.json"
report_file.parent.mkdir(parents=True, exist_ok=True)

with open(report_file, "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, ensure_ascii=False)

print(f"✅ 报告已保存: {report_file}")

# 生成 Markdown 格式报告
md_file = Path(__file__).parent / "ROTATION_TEST_REPORT.md"
md_content = f"""# 轮动策略测试报告

生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 测试概览

共测试 {len(strategies_to_test)} 个轮动策略：
- MOMENTUM（动量）
- MEAN_REVERSION（均值回归）
- VOLATILITY（波动率对冲）
- SHARPE（夏普比）

测试市场数据涵盖 {len(market_data)} 个币种。

## 各策略结果

"""

for strategy_name, result in results.items():
    md_content += f"\n### {strategy_name}\n\n"
    md_content += f"**轮动判断**: {'需要轮动' if result['should_rotate'] else '无需轮动'}\n\n"
    md_content += "| 排名 | 币种 | 评分 | 推荐分配比 | 24h涨幅 | 7d涨幅 | 波动率 | RSI |\n"
    md_content += "|------|------|----:|--------:|------:|-----:|------:|----:|\n"
    
    for i, candidate in enumerate(result['candidates'], 1):
        md_content += (f"| {i} | {candidate['symbol']} | "
                      f"{candidate['score']:.2f} | "
                      f"{candidate['allocation']:.1f}% | "
                      f"{candidate['momentum_24h']:+.1f}% | "
                      f"{candidate['momentum_7d']:+.1f}% | "
                      f"{candidate['volatility']*100:.2f}% | "
                      f"{candidate['rsi']:.0f} |\n")

with open(md_file, "w", encoding="utf-8") as f:
    f.write(md_content)

print(f"✅ Markdown 报告已保存: {md_file}")

# ========== 测试总结 ==========
print(f"\n" + "=" * 80)
print(f"✅ 轮动策略测试完成")
print("=" * 80)

summary = {
    "test_date": datetime.now().isoformat(),
    "total_strategies": len(strategies_to_test),
    "market_symbols": len(market_data),
    "rotation_required": sum(1 for r in results.values() if r['should_rotate']),
    "results": results,
}

print(f"""
📊 测试摘要:
   ✅ 测试策略数: {summary['total_strategies']}
   ✅ 测试币种数: {summary['market_symbols']}
   ✅ 需要轮动的策略: {summary['rotation_required']}
   
🎯 主要发现:
   - MOMENTUM 策略倾向于持有 {results['MOMENTUM']['candidates'][0]['symbol']}
   - MEAN_REVERSION 策略倾向于持有 {results['MEAN_REVERSION']['candidates'][0]['symbol']}
   - VOLATILITY 策略倾向于持有 {results['VOLATILITY']['candidates'][0]['symbol']}
   - SHARPE 策略倾向于持有 {results['SHARPE']['candidates'][0]['symbol']}

📁 生成的文件:
   • {report_file}
   • {md_file}
""")

print("✅ 测试完成！")
