#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
try:
    from replay.correction_engine import SelfCorrectionEngine, OptimizationMethod, StrategyParameter
    print("导入成功")
    print(f"SelfCorrectionEngine: {SelfCorrectionEngine}")
    print(f"OptimizationMethod: {OptimizationMethod}")
    print(f"StrategyParameter: {StrategyParameter}")
except Exception as e:
    print(f"导入失败: {e}")
    import traceback
    traceback.print_exc()