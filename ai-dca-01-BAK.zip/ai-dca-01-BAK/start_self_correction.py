#!/usr/bin/env python3
"""
启动自我修正机制

该脚本启动系统的自我修正流程，包括：
1. 分析回测结果
2. 建议 Prompt 修改
3. 优化策略参数
4. 导出修正报告
"""

import json
import sys
from pathlib import Path
from replay.correction_engine import SelfCorrectionEngine, OptimizationMethod, StrategyParameter

def main():
    print("=" * 80)
    print("🚀 启动自我修正机制")
    print("=" * 80)
    
    # 初始化自我修正引擎
    prompt_dir = Path(__file__).parent / "ai" / "prompts"
    config_dir = Path(__file__).parent / "config"
    
    print(f"📂 Prompt 目录: {prompt_dir}")
    print(f"📂 Config 目录: {config_dir}")
    
    corrector = SelfCorrectionEngine(
        prompt_dir=str(prompt_dir),
        config_dir=str(config_dir)
    )
    
    # 加载回测结果
    backtest_file = Path(__file__).parent / "storage" / "backtest_metrics.json"
    print(f"📊 加载回测结果: {backtest_file}")
    
    if not backtest_file.exists():
        print("❌ 回测结果文件不存在，使用模拟数据")
        # 模拟回测结果
        backtest_results = {
            "trader": {"win_rate": 35},  # 胜率低，需要更保守
            "risk": {"max_drawdown": 25}  # 回撤大，需要更严格
        }
    else:
        with open(backtest_file, 'r', encoding='utf-8') as f:
            metrics = json.load(f)["metrics"]
        
        # 将全局指标映射到角色
        backtest_results = {
            "trader": {
                "win_rate": metrics.get("win_rate_pct", 50),
            },
            "risk": {
                "max_drawdown": metrics.get("max_drawdown_pct", 0),
            }
        }
    
    print(f"📈 回测指标:")
    for role, metrics in backtest_results.items():
        print(f"  - {role}: {metrics}")
    
    # 步骤1: 基于回测结果建议 Prompt 修改
    print("\n1️⃣ 分析回测结果并建议 Prompt 修改...")
    suggestions = corrector.suggest_prompt_modifications(backtest_results)
    
    if suggestions:
        print("✅ 建议的修改:")
        for role, mods in suggestions.items():
            print(f"  - {role}:")
            for pattern, replacement in mods.items():
                print(f"    '{pattern}' → '{replacement}'")
    else:
        print("ℹ️  无需修改，表现良好")
    
    # 步骤2: 创建 Prompt 变体（如果有建议）
    if suggestions:
        print("\n2️⃣ 创建 Prompt 变体进行 A/B 测试...")
        for role, mods in suggestions.items():
            # 获取原始内容
            prompt_file = prompt_dir / f"role_{role}.md"
            if prompt_file.exists():
                with open(prompt_file, 'r', encoding='utf-8') as f:
                    original_content = f.read()
                
                variant = corrector.create_prompt_variant(
                    role=role,
                    original_content=original_content,
                    modifications=mods
                )
                print(f"  ✓ 创建变体: {variant.version_id}")
    
    # 步骤3: 优化策略参数
    print("\n3️⃣ 优化策略参数...")
    
    # 定义可优化的参数
    strategy_params = {
        "dca_amount": StrategyParameter(
            param_name="dca_amount",
            value=100,
            min_value=50,
            max_value=200,
            step=10,
            description="单次 DCA 投资金额"
        ),
        "max_positions": StrategyParameter(
            param_name="max_positions",
            value=5,
            min_value=3,
            max_value=10,
            step=1,
            description="最大持仓数量"
        ),
    }
    
    # 简单的回测函数（模拟）
    def mock_backtest(params):
        """模拟回测，返回评分"""
        # 基于参数计算评分（简化）
        dca_score = 100 - abs(params["dca_amount"] - 150)  # 最佳值 150
        position_score = 100 - abs(params["max_positions"] - 6) * 10  # 最佳值 6
        return (dca_score + position_score) / 2
    
    # 执行参数优化
    best_params = corrector.optimize_parameters(
        method=OptimizationMethod.GRID_SEARCH,
        parameters=strategy_params,
        backtest_function=mock_backtest,
        iterations=20
    )
    
    print(f"✅ 最优参数: {best_params}")
    
    # 步骤4: 导出修正报告
    print("\n4️⃣ 导出自我修正报告...")
    report_file = Path(__file__).parent / "storage" / "correction_report.json"
    corrector.export_correction_report(str(report_file))
    print(f"📄 报告已保存: {report_file}")
    
    # 显示版本对比
    print("\n📊 Prompt 版本对比:")
    for role in ["trader", "risk", "reviewer"]:
        comparison = corrector.compare_prompt_versions(role)
        if comparison:
            print(f"\n{role}:")
            for item in comparison[:3]:  # 显示前3个版本
                status = "✅ 活跃" if item["is_active"] else "🔲 未激活"
                print(f"  - {item['version_id']}: {status}, 评分: {item['backtest_score']:.1f}")
    
    print("\n" + "=" * 80)
    print("🎯 自我修正机制启动完成")
    print("=" * 80)
    
    # 后续步骤建议
    print("\n📋 后续步骤建议:")
    print("1. 运行 A/B 测试，评估新 Prompt 变体的效果")
    print("2. 将最优参数应用到实际交易策略中")
    print("3. 监控修正后的系统表现")
    print("4. 定期运行自我修正（建议每周一次）")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"❌ 脚本执行失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)