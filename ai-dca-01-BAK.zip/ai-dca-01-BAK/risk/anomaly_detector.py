from typing import Dict, Tuple
from risk.kill_switch import KillSwitch

class AnomalyDetector:
    """Detect market, account, and AI anomalies"""
    
    def __init__(self, kill_switch: KillSwitch):
        self.kill_switch = kill_switch
    
    def check(self, market: Dict, account: Dict, ai: Dict) -> Tuple[int, str]:
        """
        Check for anomalies
        Returns: (anomaly_score, reason)
        """
        score = 0
        reason = ""
        
        # Market anomaly
        if market.get("regime") == "ABNORMAL":
            score += 40
            reason = "Market volatility abnormal"
            self.kill_switch.trigger(reason)
            return score, reason
        
        # Account drawdown
        if account.get("drawdown", 0) > account.get("max_drawdown", 0.2):
            score += 30
            reason = "Account drawdown limit exceeded"
            self.kill_switch.trigger(reason)
            return score, reason
        
        # AI confidence collapse
        if ai.get("confidence_drop", 0) > 0.4:
            score += 25
            reason = "AI confidence collapse"
            self.kill_switch.trigger(reason)
            return score, reason
        
        # Shadow underperformance
        if ai.get("shadow_underperform", False):
            score += 20
            reason = "Shadow trading outperforming live AI"
            # Don't trigger immediately, just lower priority
        
        return score, reason if reason else "Normal"
    
    def get_anomaly_level(self, score: int) -> str:
        """Map score to anomaly level"""
        if score < 20:
            return "NORMAL"
        elif score < 40:
            return "WARNING"
        elif score < 60:
            return "HIGH_RISK"
        elif score < 80:
            return "CRITICAL"
        else:
            return "EMERGENCY"
