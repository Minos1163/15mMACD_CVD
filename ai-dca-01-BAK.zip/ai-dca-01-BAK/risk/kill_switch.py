from enum import Enum
import time
import json
from typing import Optional

class KillState(Enum):
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    HALTED = "HALTED"

class KillSwitch:
    """Global trading halt mechanism"""
    
    def __init__(self):
        self.state = KillState.RUNNING
        self.reason = None
        self.trigger_time = None
        self.halt_count = 0
    
    def trigger(self, reason: str):
        """Trigger emergency halt"""
        if self.state != KillState.HALTED:
            self.state = KillState.HALTED
            self.reason = reason
            self.trigger_time = time.time()
            self.halt_count += 1
            self._on_halt()
    
    def _on_halt(self):
        """Execute halt actions"""
        print("🚨 KILL SWITCH ACTIVATED")
        print(f"Reason: {self.reason}")
        self.cancel_all_orders()
        self.disable_ai()
        self.freeze_trading()
        self.log_incident()
    
    def cancel_all_orders(self):
        print("→ Cancel all open orders")
    
    def disable_ai(self):
        print("→ AI decision engine disabled")
    
    def freeze_trading(self):
        print("→ Trading frozen")
    
    def log_incident(self):
        """Log halt incident"""
        incident = {
            "timestamp": time.time(),
            "reason": self.reason,
            "state": self.state.value
        }
        # Ensure storage directory exists
        try:
            from pathlib import Path
            Path('storage').mkdir(parents=True, exist_ok=True)
            with open("storage/halt_log.jsonl", "a") as f:
                f.write(json.dumps(incident) + "\n")
        except Exception as e:
            print(f"[错误] 无法写入 halt_log: {e}")
    
    def recover(self, manual: bool = False):
        """Manual recovery from halt"""
        if manual:
            self.state = KillState.RUNNING
            self.reason = None
            print("✓ Trading resumed manually")
        else:
            print("❌ Automatic recovery disabled for safety")
    
    def is_running(self) -> bool:
        return self.state == KillState.RUNNING
