#!/usr/bin/env python3
"""
Main entry point for AI DCA Trading System
"""

import json
import time
import os
from ai.prompt_builder import PromptBuilder
from ai.deepseek_client import DeepSeekClient
from broker.binance_broker import BinanceBroker, AccountMode
from shadow.shadow_account import ShadowAccount
from risk.kill_switch import KillSwitch
from risk.anomaly_detector import AnomalyDetector


def run_cycle(broker, shadow, kill_switch, anomaly_detector, prompt_builder, deepseek):
    print("=" * 80)
    print("🚀 AI DCA Trading System - Unified Account Mode")
    print("=" * 80)

    print(f"\n📍 账户信息:")
    print(f"  - 账户模式: {broker.mode.value}")
    print(f"  - API能力: {broker.capability.value}")

    # Get account and market snapshot
    print("\n📊 获取账户快照...")
    account_state = broker.get_account_snapshot()

    print(f"  - Spot USDT: {account_state.get('spot_usdt', 0):.2f}")
    print(f"  - UM权益: {account_state.get('um_equity', 0):.2f}")
    print(f"  - UM可用: {account_state.get('um_available', 0):.2f}")
    print(f"  - 持仓数: {account_state.get('positions', 0)}")

    print("\n📈 获取市场数据...")
    market_state = broker.get_market_snapshot()
    print(f"  - 监控币种: {', '.join(market_state.get('symbols', []))}")
    print(f"  - 波动率: {market_state.get('volatility', 0)}")

    # Build prompt
    context = {
        "account": json.dumps(account_state),
        "market": json.dumps(market_state)
    }
    prompt = prompt_builder.build_prompt(context)

    # Get AI decision (real DeepSeek; fallback to mock on error)
    print("\n🧠 获取AI决策...")
    system_prompt = "你是专业量化交易顾问，必须输出可被 json.loads 解析的决策 JSON。"
    decision = deepseek.ask(prompt=prompt, system_prompt=system_prompt, temperature=0.1, force_json=False)

    if not isinstance(decision, dict) or not decision.get("action"):
        print("  ⚠️  AI 返回异常，使用 mock 决策兜底")
        decision = deepseek.mock_decision()

    if decision.get("error"):
        print(f"  ⚠️  AI 调用警告: {decision.get('error')}")

    print(f"  - 操作: {decision.get('action', 'N/A')}")
    print(f"  - 币种: {decision.get('symbol', 'N/A')}")
    print(f"  - 方向: {decision.get('direction', 'N/A')}")
    print(f"  - 置信度: {decision.get('confidence', 0):.2f}")
    print(f"  - 评分: {decision.get('review_score', 0)}")

    # Check for anomalies
    print("\n⚠️  检查异常...")
    anomaly_score, anomaly_reason = anomaly_detector.check(
        market=market_state,
        account=account_state,
        ai={"confidence_drop": 0}
    )

    print(f"  - 异常分数: {anomaly_score}")
    print(f"  - 异常原因: {anomaly_reason}")

    # Record decision
    if kill_switch.is_running():
        print("\n💾 记录决策...")
        with open("storage/decisions.jsonl", "a") as f:
            record = {
                "timestamp": time.time(),
                "decision": decision,
                "anomaly_score": anomaly_score,
                "account_mode": broker.mode.value
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        print("  ✓ 决策已记录")

        # Shadow account execution
        print("\n🧪 影子账户执行...")
        shadow_result = shadow.apply_decision(decision, market_state["prices"]["BTCUSDT"])
        print(f"  - 状态: {shadow_result.get('status', 'N/A')}")
        print(f"  - 操作: {shadow_result.get('action', 'N/A')}")
        print(f"  - 币种: {shadow_result.get('symbol', 'N/A')}")

        # Real execution (only if confidence high)
        if decision["confidence"] > 0.65:
            print("\n💰 真实账户执行...")
            exec_result = broker.execute(decision)
            print(f"  - 状态: {exec_result.get('status', 'N/A')}")
            print(f"  - 账户模式: {exec_result.get('mode', 'N/A')}")
        else:
            print("\n⏭️  由于置信度不足，跳过真实下单")
    else:
        print("\n🛑 交易已停止 - 未执行决策")

    print("\n" + "=" * 80)
    print("✅ 周期完成")
    print("=" * 80)

def main():
    # Initialize components once
    broker = BinanceBroker()
    shadow = ShadowAccount()
    kill_switch = KillSwitch()
    anomaly_detector = AnomalyDetector(kill_switch)
    prompt_builder = PromptBuilder()
    deepseek = DeepSeekClient()

    loop_seconds = int(os.getenv("LOOP_INTERVAL", "60"))

    while True:
        try:
            run_cycle(broker, shadow, kill_switch, anomaly_detector, prompt_builder, deepseek)
        except Exception as e:
            print(f"[Error] Cycle failed: {e}")

        # 如果 kill switch 关闭，则跳出循环
        if not kill_switch.is_running():
            print("Kill switch is OFF, exiting loop.")
            break

        time.sleep(loop_seconds)

if __name__ == "__main__":
    main()
