# AI 自治量化交易系统 · 文档结构（Playbook）

> 本文将 `TODO.txt` 中的“周级进化 / Prompt 体系 / 可解释决策 / Regime 切换 / Meta-Risk”内容整理为**可交付、可维护**的文档结构，并明确每一层的职责与落地点。

## 0. 你应该从哪里读起

- 想理解 DCA 与参数分工：先读 `DCA_STRATEGY_GUIDE.md`
- 想理解全链路架构：继续读本文件
- 想部署 7×24 与监控：读 `dashboard/` + 本文件「运行与运维」章节

---

## 1. 系统目标与设计哲学

- **目标**：长期稳定运行、自动进化、风险自控、尽量少人工干预。
- **三条铁律**：
  1. **硬风控永远不由 AI 修改**（止损/回撤/敞口上限等）
  2. **Prompt 的进化速度 < 参数进化速度**（避免人格频繁漂移）
  3. **实盘永远小于等于 Shadow 最优**（用 Shadow 做安全阀）

---

## 2. 多币种 DCA（策略层）

### 2.1 DCA 是什么

- 方向确定后，价格不利则分批加仓摊薄成本；达到止盈目标后整体或分批退出。
- 必须用 **max_add_position_count / 总投入止损 / 最大回撤** 防止“无限摊平”。

### 2.2 参数分工（最关键）

- **你控制（硬边界）**：
  - `max_holding_coins` / `max_add_position_count` / `max_pending_orders`
  - `single_coin_stop_loss` / `total_investment_stop_loss` / `max_drawdown_limit`
  - 是否启用 `td_trigger_enabled` / `rsi_add_position_enabled`
- **AI 控制（在区间内微调）**：
  - `single_tp_target` / `add_position_threshold`
  - `ai_*` 仓位与下单基数（用户给上下限，AI 在区间内调度）

> 参数标注已写入 `Parameter.txt`（[USER]/[AI]/[HYBRID]）。

---

## 3. 可解释决策（Explainable Trading）

### 3.1 为什么必须可解释

没有结构化解释就无法：复盘、评分、进化、监管。

### 3.2 决策输出协议（建议）

- 强制 JSON 输出：
  - `action/symbol/direction/confidence`
  - `reasoning`（市场状态、主信号、支撑因素、风险因素）
  - `invalid_if`（失效条件）

### 3.3 执行门禁（Execution Gate）

- **不解释 → 不执行**
- **confidence 过低 → 不执行或降权**
- **缺失 invalid_if → 不执行**

---

## 4. Market Regime × Prompt 自动切换

### 4.1 Regime 划分（够用且稳定）

- `TREND`（趋势）
- `RANGE`（震荡）
- `BREAKOUT`（突破）
- `PANIC`（极端）

### 4.2 Prompt 路由

- TREND：少但稳，适合 DCA 主力
- RANGE：快进快出，轻仓
- BREAKOUT：一次性，快进快出
- PANIC：默认 HOLD（保命优先）

---

## 5. Prompt × Regime 独立评分（避免误杀）

- 评分维度（示例权重）：
  - 盈亏（pnl）
  - 风控服从（risk_violation）
  - 置信度（confidence）
  - 角色一致性（role_ok）

> 核心原则：**Prompt 不分好坏，只分“是否适合这个 Regime”。**

---

## 6. Regime × 币池轮动（选战场）

- 系统先给币池分层：
  - 生存级过滤（成交量、停牌、黑名单等）
  - 结构级分类（TREND 偏动量，RANGE 偏低波动，PANIC 偏 BTC/ETH 等）
- AI 只能在给定候选池里选，不允许推荐池外币。
- DCA 约束：**币不在当前池 → 禁止继续加仓**（降低“死扛垃圾币”风险）。

---

## 7. 周级参数进化（Genetic + Bayesian）

- 进化对象：参数（不是策略逻辑）。
- 周期：建议 7 天（不要日级）。
- Fitness（示例）：
  - `weekly_pnl`（奖励）
  - `max_drawdown`（惩罚）
  - `win_rate`（奖励）
  - `equity_volatility`（惩罚）

落地流程（周更）：
1) Shadow/实盘记录指标
2) 计算 fitness
3) 选择 elites → 交叉 → 变异
4) 仅替换“胜出参数”进入下周

---

## 8. 参数 × Prompt 联合进化（Strategy Genome）

- 一个 Prompt + 一组参数 = 一个“物种”（Genome）。
- Shadow 同时跑多个 genome，实盘只用 Top1。
- 联合 fitness 必须包含：
  - PnL、回撤、稳定性
  - Prompt 一致性（flip rate）
  - 风控越权（risk violation，重罚）

---

## 9. Prompt 遗传 / Meta-Prompt / Meta-Risk（终局层）

### 9.1 Prompt 自动变异（低频）

- 只变异“结构化 DNA”（entry/exit/dca_policy 等），不让模型自由改文本。
- 风控语句（risk_sentence）建议**禁止变异**。

### 9.2 Meta-Prompt（AI 造新 Prompt）

- Meta 层不交易，只负责生成新的 Prompt DNA，经过 validator 后进入 prompt pool。

### 9.3 Meta-Risk（风险宪法）

- Meta-Risk 产出的规则是系统级“宪法”：
  - hard limits
  - soft limits
  - kill switch 条件
- **RiskEnforcer 永远在下单前执行，且不可被 AI 绕过。**

---

## 10. 运行与运维（Ubuntu 24.04 / 7×24）

- 运行位置：`/root/git/`
- 建议：
  - 用 systemd 管理主进程（自动重启、开机自启）
  - 用 Dashboard 后端提供：状态、日志 tail、启停、参数编辑、收益曲线、账户信息

> Docker 相关内容已从仓库与文档主线中移除（docker 目录已删除，按你的要求）。
