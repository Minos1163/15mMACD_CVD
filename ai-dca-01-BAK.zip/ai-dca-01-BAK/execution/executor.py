"""
交易执行器：将 AI 决策转换为实际交易指令
"""

import json
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum


class OrderType(Enum):
    """订单类型"""
    MARKET = "MARKET"  # 市价单
    LIMIT = "LIMIT"  # 限价单


class OrderSide(Enum):
    """订单方向"""
    BUY = "BUY"
    SELL = "SELL"


class OrderStatus(Enum):
    """订单状态"""
    PENDING = "PENDING"  # 待执行
    SUBMITTED = "SUBMITTED"  # 已提交
    FILLED = "FILLED"  # 已成交
    PARTIAL_FILLED = "PARTIAL_FILLED"  # 部分成交
    CANCELLED = "CANCELLED"  # 已取消
    FAILED = "FAILED"  # 失败


@dataclass
class Order:
    """订单"""
    order_id: str  # 订单唯一 ID
    symbol: str  # 币种对，如 BTCUSDT
    order_type: OrderType
    side: OrderSide
    quantity: float  # 数量
    price: float  # 价格（市价单为 0）
    status: OrderStatus
    created_at: str  # 创建时间
    submitted_at: Optional[str] = None  # 提交时间
    filled_at: Optional[str] = None  # 成交时间
    filled_quantity: float = 0.0  # 成交数量
    filled_price: float = 0.0  # 成交价格
    fee: float = 0.0  # 交易费用
    remarks: str = ""  # 备注


class ExecutionEngine:
    """
    执行引擎：
    - 将 AI 决策转换为交易指令
    - 管理订单生命周期
    - 记录执行历史
    """

    def __init__(self):
        self.orders: Dict[str, Order] = {}  # order_id -> Order
        self.execution_history: List[Dict] = []
        self.counter = 0  # 用于生成订单 ID

    def create_order(
        self,
        symbol: str,
        side: OrderSide,
        quantity: float,
        price: float = 0.0,
        order_type: OrderType = OrderType.MARKET,
        remarks: str = "",
    ) -> Order:
        """
        创建订单

        Args:
            symbol: 币种对
            side: 买/卖
            quantity: 数量
            price: 价格（市价单可为 0）
            order_type: 订单类型
            remarks: 备注

        Returns:
            创建的订单对象
        """
        self.counter += 1
        order_id = f"ORD_{int(time.time())}_{self.counter:05d}"

        order = Order(
            order_id=order_id,
            symbol=symbol,
            order_type=order_type,
            side=side,
            quantity=quantity,
            price=price,
            status=OrderStatus.PENDING,
            created_at=datetime.now().isoformat(),
            remarks=remarks,
        )

        self.orders[order_id] = order
        return order

    def submit_order(self, order_id: str) -> bool:
        """
        提交订单到交易所

        Args:
            order_id: 订单 ID

        Returns:
            是否提交成功
        """
        if order_id not in self.orders:
            return False

        order = self.orders[order_id]
        if order.status != OrderStatus.PENDING:
            return False

        order.status = OrderStatus.SUBMITTED
        order.submitted_at = datetime.now().isoformat()
        return True

    def fill_order(
        self,
        order_id: str,
        filled_quantity: float,
        filled_price: float,
        fee: float = 0.0,
        partial: bool = False,
    ) -> bool:
        """
        标记订单为已成交

        Args:
            order_id: 订单 ID
            filled_quantity: 成交数量
            filled_price: 成交价格
            fee: 交易费用
            partial: 是否部分成交

        Returns:
            是否成功
        """
        if order_id not in self.orders:
            return False

        order = self.orders[order_id]
        order.filled_quantity = filled_quantity
        order.filled_price = filled_price
        order.fee = fee
        order.filled_at = datetime.now().isoformat()

        if partial:
            order.status = OrderStatus.PARTIAL_FILLED
        else:
            order.status = OrderStatus.FILLED

        # 记录到执行历史
        self._record_execution(order)
        return True

    def cancel_order(self, order_id: str, reason: str = "") -> bool:
        """
        取消订单

        Args:
            order_id: 订单 ID
            reason: 取消原因

        Returns:
            是否取消成功
        """
        if order_id not in self.orders:
            return False

        order = self.orders[order_id]
        if order.status in [OrderStatus.FILLED, OrderStatus.CANCELLED, OrderStatus.FAILED]:
            return False

        order.status = OrderStatus.CANCELLED
        order.remarks = reason
        return True

    def _record_execution(self, order: Order):
        """记录订单执行"""
        execution_record = {
            "order_id": order.order_id,
            "symbol": order.symbol,
            "side": order.side.value,
            "quantity": order.quantity,
            "filled_quantity": order.filled_quantity,
            "filled_price": order.filled_price,
            "fee": order.fee,
            "status": order.status.value,
            "created_at": order.created_at,
            "filled_at": order.filled_at,
            "pnl": self._calculate_pnl(order),
        }
        self.execution_history.append(execution_record)

    def _calculate_pnl(self, order: Order) -> float:
        """
        计算订单的损益（仅对卖单有意义）

        Args:
            order: 订单对象

        Returns:
            损益金额
        """
        if order.side == OrderSide.BUY:
            return 0.0

        # 简化计算：假设之前的平均成本可知
        # 这里需要与 broker 集成获取实际成本
        return order.filled_quantity * (order.filled_price - order.price)

    def get_order(self, order_id: str) -> Optional[Order]:
        """获取订单"""
        return self.orders.get(order_id)

    def get_orders_by_symbol(self, symbol: str) -> List[Order]:
        """获取某币种的所有订单"""
        return [order for order in self.orders.values() if order.symbol == symbol]

    def get_orders_by_status(self, status: OrderStatus) -> List[Order]:
        """获取指定状态的所有订单"""
        return [order for order in self.orders.values() if order.status == status]

    def get_pending_orders(self) -> List[Order]:
        """获取待执行的订单"""
        return self.get_orders_by_status(OrderStatus.PENDING)

    def get_execution_summary(self) -> Dict:
        """
        获取执行汇总

        Returns:
            执行统计信息
        """
        if not self.execution_history:
            return {
                "total_orders": 0,
                "successful_orders": 0,
                "total_fee": 0.0,
                "total_pnl": 0.0,
                "win_rate": 0.0,
            }

        successful = len(
            [e for e in self.execution_history if e["status"] == "FILLED"]
        )
        total_fee = sum(e["fee"] for e in self.execution_history)
        total_pnl = sum(e["pnl"] for e in self.execution_history)

        win_rate = (successful / len(self.execution_history) * 100) if self.execution_history else 0.0

        return {
            "total_orders": len(self.execution_history),
            "successful_orders": successful,
            "success_rate_pct": round(win_rate, 2),
            "total_fee": round(total_fee, 2),
            "total_pnl": round(total_pnl, 2),
        }

    def get_execution_history(self, limit: int = 100) -> List[Dict]:
        """获取执行历史"""
        return self.execution_history[-limit:]

    def export_state(self) -> str:
        """导出执行器状态"""
        pending_orders = [
            asdict(order)
            for order_id, order in self.orders.items()
            if order.status == OrderStatus.PENDING
        ]

        return json.dumps(
            {
                "pending_orders": pending_orders,
                "execution_summary": self.get_execution_summary(),
                "execution_history_count": len(self.execution_history),
                "exported_at": datetime.now().isoformat(),
            },
            indent=2,
            default=str,
        )
