import os
import time
import hmac
import hashlib
import requests
import json
from typing import Dict, List, Optional, Any
from enum import Enum
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# ========== API 配置 ==========
API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_SECRET")

if not API_KEY or not API_SECRET:
    print("⚠️ 警告: 未配置BINANCE_API_KEY和BINANCE_SECRET，使用模拟模式")
else:
    assert API_KEY is not None and API_SECRET is not None, "API密钥不能为None"

BINANCE_API_KEY: str = API_KEY if API_KEY else ""
BINANCE_SECRET: str = API_SECRET if API_SECRET else ""

# ========== 签名函数 ==========
def generate_signature(params: dict, secret: str) -> str:
    """生成币安API签名"""
    query_string = '&'.join([f"{k}={v}" for k, v in sorted(params.items())])
    return hmac.new(secret.encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256).hexdigest()

# ========== API请求函数 ==========
def send_request(url: str, params: Optional[Dict] = None, method: str = "GET", 
                 api_key: str = "", api_secret: str = "", signed: bool = True, 
                 timeout: int = 10) -> Optional[Any]:
    """发送HTTP请求"""
    params = params or {}
    headers = {"Content-Type": "application/json"}
    
    if signed and api_key and api_secret:
        api_params = params.copy()
        api_params["timestamp"] = int(time.time() * 1000)
        api_params["signature"] = generate_signature(api_params, api_secret)
        headers["X-MBX-APIKEY"] = api_key
    else:
        api_params = params
    
    try:
        if method == "GET":
            r = requests.get(url, params=api_params, headers=headers, timeout=timeout)
        elif method == "POST":
            r = requests.post(url, params=api_params, headers=headers, timeout=timeout)
        elif method == "DELETE":
            r = requests.delete(url, params=api_params, headers=headers, timeout=timeout)
        else:
            raise ValueError("不支持的请求方法")
        
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[错误] API请求失败: {e}")
        return None

# ========== 账户类型检测 ==========
class AccountMode(Enum):
    CLASSIC = "CLASSIC"
    UNIFIED = "UNIFIED"

class ApiCapability(Enum):
    PAPI_ONLY = "PAPI_ONLY"
    STANDARD = "STANDARD"

def detect_api_capability(api_key: str, api_secret: str) -> ApiCapability:
    """检测API密钥能力：PAPI专用 vs 标准密钥"""
    if not api_key or not api_secret:
        return ApiCapability.STANDARD
    
    try:
        url = "https://fapi.binance.com/fapi/v2/account"
        params: Dict[str, Any] = {"timestamp": int(time.time() * 1000)}
        params["signature"] = generate_signature(params, api_secret)
        
        r = requests.get(url, params=params, headers={"X-MBX-APIKEY": api_key}, timeout=5)
        
        if r.status_code == 200:
            return ApiCapability.STANDARD
        if r.status_code == 401:
            return ApiCapability.PAPI_ONLY
    except Exception:
        pass
    
    return ApiCapability.PAPI_ONLY

class AccountDetector:
    """账户模型自动判定"""
    
    def __init__(self, api_key: str, api_secret: str, timeout: int = 10):
        self.api_key = api_key
        self.api_secret = api_secret
        self.timeout = timeout
    
    def _headers(self) -> Dict[str, str]:
        return {"X-MBX-APIKEY": self.api_key}
    
    def detect(self) -> AccountMode:
        """自动判断账户模型"""
        if not self.api_key or not self.api_secret:
            return AccountMode.CLASSIC
        
        try:
            data = self._get_papi_um_account()
            if isinstance(data, dict):
                equity = float(data.get("accountEquity", 0))
                status = data.get("accountStatus")
                
                if status in ("NORMAL", "MARGIN_CALL") and equity > 0:
                    return AccountMode.UNIFIED
        except Exception:
            pass
        
        return AccountMode.CLASSIC
    
    def _get_papi_um_account(self) -> Optional[Dict]:
        """获取PAPI UM账户信息"""
        url = "https://papi.binance.com/papi/v1/um/account"
        params: Dict[str, Any] = {"timestamp": int(time.time() * 1000)}
        params["signature"] = generate_signature(params, self.api_secret)
        
        r = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        return r.json()

class BinanceBroker:
    """币安统一账户代理"""
    
    def __init__(self, api_key: str = "", api_secret: str = ""):
        self.api_key = api_key or BINANCE_API_KEY
        self.api_secret = api_secret or BINANCE_SECRET
        self.timeout = 10
        
        # 自动检测账户类型和API能力
        self.capability = detect_api_capability(self.api_key, self.api_secret)
        detector = AccountDetector(self.api_key, self.api_secret)
        self.mode = detector.detect()
        
        print(f"[初始化] 账户模式: {self.mode.value}, API能力: {self.capability.value}")
    
    def _headers(self) -> Dict[str, str]:
        return {"X-MBX-APIKEY": self.api_key}
    
    # ========== 现货账户 ==========
    def get_spot_account(self) -> Optional[Dict]:
        """获取现货账户信息"""
        url = "https://api.binance.com/api/v3/account"
        return send_request(url, api_key=self.api_key, api_secret=self.api_secret, 
                          signed=True, timeout=self.timeout)
    
    # ========== U本位合约账户 ==========
    def get_um_account(self) -> Optional[Dict]:
        """获取U本位合约账户（自动适配账户类型）"""
        if self.mode == AccountMode.UNIFIED:
            return self._get_unified_account()
        else:
            return self._get_classic_um_account()
    
    def _get_unified_account(self) -> Optional[Dict]:
        """获取统一账户信息"""
        url = "https://papi.binance.com/papi/v1/um/account"
        params: Dict[str, Any] = {"timestamp": int(time.time() * 1000)}
        params["signature"] = generate_signature(params, self.api_secret)
        
        try:
            r = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
            r.raise_for_status()
            data = r.json()
            
            return {
                "type": "UNIFIED",
                "equity": float(data.get("accountEquity", 0)),
                "available": float(data.get("availableBalance", 0)),
                "status": data.get("accountStatus"),
                "raw": data
            }
        except Exception as e:
            print(f"[错误] 获取统一账户失败: {e}")
            return None
    
    def _get_classic_um_account(self) -> Optional[Dict]:
        """获取Classic UM账户信息"""
        if self.capability == ApiCapability.STANDARD:
            return self._get_classic_um_via_fapi()
        else:
            return self._get_classic_um_via_papi()
    
    def _get_classic_um_via_fapi(self) -> Optional[Dict]:
        """通过FAPI获取Classic UM账户"""
        url = "https://fapi.binance.com/fapi/v2/account"
        
        try:
            data = send_request(url, api_key=self.api_key, api_secret=self.api_secret,
                              signed=True, timeout=self.timeout)
            
            if data and "totalWalletBalance" in data:
                return {
                    "type": "CLASSIC_UM",
                    "wallet_balance": float(data.get("totalWalletBalance", 0)),
                    "available": float(data.get("availableBalance", 0)),
                    "margin_balance": float(data.get("totalMarginBalance", 0)),
                    "raw": data
                }
            elif data and "error" in data:
                return {
                    "type": "CLASSIC_UM",
                    "error": data.get("message", "无Futures权限"),
                    "raw": data
                }
        except Exception as e:
            print(f"[错误] 通过FAPI获取Classic UM失败: {e}")
        
        return None
    
    def _get_classic_um_via_papi(self) -> Optional[Dict]:
        """通过PAPI获取Classic UM账户（PAPI-only密钥）"""
        # 获取现货USDT作为保证金参考
        spot = self.get_spot_account()
        spot_usdt = 0
        
        if spot and "balances" in spot:
            for b in spot["balances"]:
                if b["asset"] == "USDT":
                    spot_usdt = float(b["free"]) + float(b["locked"])
                    break
        
        return {
            "type": "CLASSIC_UM_SIMULATED",
            "wallet_balance": spot_usdt,
            "available": spot_usdt,
            "source": "PAPI_SIMULATED",
            "note": "使用现货USDT余额作为保证金参考"
        }
    
    # ========== 持仓 ==========
    def get_um_positions(self) -> List[Dict]:
        """获取U本位合约持仓"""
        if self.mode == AccountMode.UNIFIED:
            return self._get_unified_positions()
        else:
            return self._get_classic_um_positions()
    
    def _get_unified_positions(self) -> List[Dict]:
        """获取统一账户持仓"""
        url = "https://papi.binance.com/papi/v1/um/positionRisk"
        params: Dict[str, Any] = {"timestamp": int(time.time() * 1000)}
        params["signature"] = generate_signature(params, self.api_secret)
        
        try:
            r = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
            r.raise_for_status()
            
            positions = r.json()
            return [p for p in positions if float(p.get("positionAmt", 0)) != 0]
        except Exception as e:
            print(f"[错误] 获取统一账户持仓失败: {e}")
            return []
    
    def _get_classic_um_positions(self) -> List[Dict]:
        """获取Classic UM持仓"""
        if self.capability == ApiCapability.STANDARD:
            return self._get_classic_um_positions_via_fapi()
        else:
            return self._get_classic_um_positions_via_papi()
    
    def _get_classic_um_positions_via_fapi(self) -> List[Dict]:
        """通过FAPI获取Classic UM持仓"""
        url = "https://fapi.binance.com/fapi/v2/positionRisk"
        
        try:
            data = send_request(url, api_key=self.api_key, api_secret=self.api_secret,
                              signed=True, timeout=self.timeout)
            
            if isinstance(data, list):
                return [p for p in data if float(p.get("positionAmt", 0)) != 0]
            elif isinstance(data, dict) and "error" in data:
                print(f"[警告] 无法读取Classic UM持仓: {data.get('message')}")
                return []
        except Exception as e:
            print(f"[错误] 通过FAPI获取Classic UM持仓失败: {e}")
        
        return []
    
    def _get_classic_um_positions_via_papi(self) -> List[Dict]:
        """通过PAPI获取Classic UM持仓"""
        url = "https://papi.binance.com/papi/v1/um/positionRisk"
        params: Dict[str, Any] = {"timestamp": int(time.time() * 1000)}
        params["signature"] = generate_signature(params, self.api_secret)
        
        try:
            r = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout)
            r.raise_for_status()
            
            positions = r.json()
            return [p for p in positions if float(p.get("positionAmt", 0)) != 0]
        except Exception as e:
            print(f"[警告] 通过PAPI获取Classic UM持仓失败: {e}")
            return []
    
    # ========== 交易执行 ==========
    def get_account_snapshot(self) -> Dict:
        """获取账户快照"""
        spot = self.get_spot_account()
        um = self.get_um_account()
        positions = self.get_um_positions()
        
        spot_usdt = 0
        if spot and "balances" in spot:
            for b in spot["balances"]:
                if b["asset"] == "USDT":
                    spot_usdt = float(b["free"]) + float(b["locked"])
                    break
        
        um_equity = um.get("equity", 0) if um and "equity" in um else um.get("wallet_balance", 0) if um else 0
        um_available = um.get("available", 0) if um else 0
        
        return {
            "mode": self.mode.value,
            "spot_usdt": spot_usdt,
            "um_equity": um_equity,
            "um_available": um_available,
            "positions": len(positions),
            "timestamp": int(time.time() * 1000)
        }
    
    def get_market_snapshot(self) -> Dict:
        """获取市场快照（模拟）"""
        return {
            "symbols": ["BTCUSDT", "ETHUSDT", "RENDERUSDT"],
            "prices": {
                "BTCUSDT": 42000,
                "ETHUSDT": 2200,
                "RENDERUSDT": 8.5
            },
            "rsi": {
                "BTCUSDT": 45,
                "ETHUSDT": 52,
                "RENDERUSDT": 38
            },
            "volatility": 1.2,
            "timestamp": int(time.time() * 1000)
        }
    
    def open_long(self, symbol: str, quantity: float) -> Dict:
        """开多仓"""
        return {
            "order_id": f"test_{int(time.time())}",
            "symbol": symbol,
            "side": "BUY",
            "quantity": quantity,
            "status": "FILLED",
            "mode": self.mode.value
        }
    
    def open_short(self, symbol: str, quantity: float) -> Dict:
        """开空仓"""
        return {
            "order_id": f"test_{int(time.time())}",
            "symbol": symbol,
            "side": "SELL",
            "quantity": quantity,
            "status": "FILLED",
            "mode": self.mode.value
        }
    
    def close_position(self, symbol: str) -> Dict:
        """平仓"""
        return {
            "order_id": f"test_{int(time.time())}",
            "symbol": symbol,
            "side": "CLOSE",
            "status": "CLOSED",
            "mode": self.mode.value
        }
    
    def execute(self, decision: Dict) -> Dict:
        """执行决策"""
        action = decision.get("action", "HOLD")
        
        if action == "BUY":
            return self.open_long(decision.get("symbol", "BTCUSDT"), 0.01)
        elif action == "SELL":
            return self.close_position(decision.get("symbol", "BTCUSDT"))
        elif action == "HOLD":
            return {"status": "HOLD", "mode": self.mode.value}
        
        return {"status": "UNKNOWN"}
    
    def get_klines(self, symbol: str, interval: str = '1d', limit: int = 100) -> Optional[List[List[Any]]]:
        """获取币安K线数据"""
        url = "https://api.binance.com/api/v3/klines"
        params = {
            "symbol": symbol,
            "interval": interval,
            "limit": limit
        }
        return send_request(url, params=params, api_key=self.api_key, api_secret=self.api_secret, signed=False, timeout=self.timeout)
