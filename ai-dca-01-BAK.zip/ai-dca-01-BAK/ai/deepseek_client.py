import os
import requests
import json
import re
from typing import Dict, List, Optional, Any

class DeepSeekClient:
    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://api.deepseek.com/v1"):
        # 优先使用显式传入的 api_key，其次读取环境变量 DEEPSEEK_API_KEY
        self.api_key = api_key or os.getenv("DEEPSEEK_API_KEY")
        self.base_url = base_url

    def ask(self, prompt: str, system_prompt: Optional[str] = None, temperature: float = 0.1, force_json: bool = False) -> Dict[str, Any]:
        """
        Call DeepSeek API for trading decision
        
        Args:
            prompt: User message
            system_prompt: System role instruction
            temperature: Model temperature (0-1)
            force_json: Whether to force JSON response format (disabled by default, use prompt guidance instead)
            
        Returns:
            Decision dict with action, confidence, etc.
        """
        
        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        else:
            # 如果未配置 API Key，直接退回 mock 决策以便测试继续
            return self.mock_decision()
        
        messages = []
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        
        messages.append({
            "role": "user",
            "content": prompt
        })
        
        payload = {
            "model": "deepseek-chat",
            "messages": messages,
            "temperature": temperature,
        }
        
        # 不再强制 response_format（避免 400 Bad Request）
        # 改用提示词引导模型返回 JSON 格式（更可靠）
        
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            
            # 尝试解析 JSON
            try:
                return json.loads(content)
            except json.JSONDecodeError:
                # 如果不是有效 JSON，尝试提取 JSON
                json_content = self._extract_json_from_text(content)
                if json_content:
                    try:
                        return json.loads(json_content)
                    except json.JSONDecodeError:
                        pass
                
                # 如果都失败，返回原始内容包装
                return {
                    "action": "HOLD",
                    "confidence": 0.5,
                    "raw_response": content,
                    "error": "Invalid JSON format in response"
                }
        
        except requests.exceptions.Timeout:
            return {
                "action": "HOLD",
                "confidence": 0.0,
                "error": "API request timeout (30s)"
            }
        except requests.exceptions.ConnectionError:
            return {
                "action": "HOLD",
                "confidence": 0.0,
                "error": "Network connection error"
            }
        except requests.exceptions.HTTPError as e:
            error_msg = str(e)
            if "400" in error_msg:
                error_msg += " (Bad Request - check payload format)"
            elif "401" in error_msg:
                error_msg += " (Unauthorized - check API key)"
                # 认证失败时回退到 mock 决策，便于离线测试流程继续
                return self.mock_decision()
            elif "429" in error_msg:
                error_msg += " (Rate limited - slow down requests)"
            
            return {
                "action": "HOLD",
                "confidence": 0.0,
                "error": error_msg
            }
        except Exception as e:
            return {
                "action": "HOLD",
                "confidence": 0.0,
                "error": str(e)
            }
    
    def _extract_json_from_text(self, text: str) -> Optional[str]:
        """
        Extract JSON object from text that may contain other content
        """
        import re
        # 查找 { 开始和 } 结束的 JSON 块
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            return match.group(0)
        return None
    
    def _fix_json_format(self, text: str) -> str:
        """
        Fix common JSON formatting issues
        """
        # 移除尾部逗号
        text = re.sub(r',\s*}', '}', text)
        text = re.sub(r',\s*]', ']', text)
        # 修复单引号为双引号（仅在 JSON 上下文中）
        return text
    
    def mock_decision(self) -> Dict:
        """
        Mock decision for testing (when API not available)
        """
        return {
            "action": "BUY",
            "symbol": "BTCUSDT",
            "direction": "LONG",
            "confidence": 0.72,
            "position_ratio": 0.15,
            "reason": "Momentum增强 + 回调完成",
            "risk_comment": "仓位可控",
            "review_score": 82
        }
