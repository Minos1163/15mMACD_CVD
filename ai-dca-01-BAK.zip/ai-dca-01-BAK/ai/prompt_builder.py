from pathlib import Path
from typing import Dict

class PromptBuilder:
    def __init__(self, prompt_dir: str = "ai/prompts"):
        self.prompt_dir = Path(prompt_dir)
    
    def read_file(self, filename: str) -> str:
        """Read prompt template file"""
        file_path = self.prompt_dir / filename
        if file_path.exists():
            return file_path.read_text(encoding="utf-8")
        return ""
    
    def build_prompt(self, context: Dict) -> str:
        """
        Build complete prompt from templates and context
        
        Args:
            context: Market data and account state
            
        Returns:
            Complete prompt string
        """
        system_base = self.read_file("system_base.md")
        role_trader = self.read_file("role_trader.md")
        role_risk = self.read_file("role_risk.md")
        role_reviewer = self.read_file("role_reviewer.md")
        
        prompt = f"""
{system_base}

## 交易官
{role_trader}

## 风控官
{role_risk}

## 复盘官
{role_reviewer}

### 账户状态:
{context.get('account', 'N/A')}

### 市场数据:
{context.get('market', 'N/A')}

## 输出要求
你必须以有效的 JSON 格式输出决策，格式如下（确保是完整的可解析的 JSON）：

```json
{{
  "action": "BUY",
  "symbol": "BTCUSDT",
  "direction": "LONG",
  "confidence": 0.85,
  "position_ratio": 0.2,
  "reason": "市场趋势向好，关键支撑位确认",
  "risk_comment": "注意可能的回调风险",
  "review_score": 85
}}
```

重要：
1. 输出必须是有效的 JSON，可以直接被 json.loads() 解析
2. 不要包含任何 JSON 之外的文本或解释
3. 使用双引号而不是单引号
4. 确保没有尾随逗号
5. action 必须是以下之一：BUY, SELL, HOLD, ROTATE
6. confidence 和 position_ratio 是 0-1 之间的数字
7. review_score 是 0-100 之间的整数
"""
        return prompt
