# -*- coding: utf-8 -*-
"""
验证 DeepSeek API 调用格式修复
"""
import json
import sys
from datetime import datetime, timedelta
import requests
from ai.deepseek_client import DeepSeekClient
from ai.prompt_builder import PromptBuilder
from broker.binance_broker import BinanceBroker

def test_api_format_fix():
    """Test API format fix with improved prompt strategy"""
    
    print("=" * 60)
    print("🔧 DeepSeek API 格式修复测试")
    print("=" * 60)
    print(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # 初始化客户端
    deepseek = DeepSeekClient()
    prompt_builder = PromptBuilder()
    broker = BinanceBroker()
    
    # 测试符号
    symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
    test_results = []
    
    for symbol in symbols:
        print(f"\n📊 测试符号: {symbol}")
        print("-" * 50)
        
        try:
            # 获取市场数据（直接调用 Binance REST，避免依赖本地 broker.get_klines）
            r = requests.get(
                "https://api.binance.com/api/v3/klines",
                params={"symbol": symbol, "interval": "1d", "limit": 7},
                timeout=10,
            )
            r.raise_for_status()
            klines = r.json()
            if not klines:
                print(f"❌ 无法获取 {symbol} 的市场数据")
                continue

            # 构建市场上下文（使用原始 kline 列表）
            price = float(klines[-1][4])  # 收盘价
            change_pct = ((float(klines[-1][4]) - float(klines[0][1])) / float(klines[0][1])) * 100

            highs = [float(k[2]) for k in klines]
            lows = [float(k[3]) for k in klines]
            market_context = f"""
符号: {symbol}
当前价格: ${price:,.2f}
7日涨幅: {change_pct:+.2f}%
最高价: ${max(highs):,.2f}
最低价: ${min(lows):,.2f}
"""
            
            account_context = """
账户余额: $10,000
当前持仓: 无
可用额度: $10,000
"""
            
            # 构建完整提示词
            context = {
                'market': market_context,
                'account': account_context
            }
            prompt = prompt_builder.build_prompt(context)
            
            print(f"✅ 市场数据已获取")
            print(f"   价格: ${price:,.2f}, 涨幅: {change_pct:+.2f}%")
            
            # API 调用（新格式）
            print(f"🔄 正在调用 DeepSeek API（禁用强制 JSON）...")
            response = deepseek.ask(
                prompt=prompt,
                system_prompt="你是一个专业的量化交易顾问，需要基于市场数据和账户状态做出交易决策。",
                temperature=0.1,
                force_json=False  # 默认关闭强制 JSON
            )
            
            # 验证响应格式
            print(f"\n📋 API 响应:")
            print(f"   Action: {response.get('action', 'N/A')}")
            print(f"   Confidence: {response.get('confidence', 'N/A')}")
            print(f"   Error: {response.get('error', 'None')}")
            
            # 检查是否成功
            if 'error' in response and response['error']:
                print(f"   ⚠️  API 错误: {response['error']}")
                status = "API_ERROR"
            elif response.get('action') in ['BUY', 'SELL', 'HOLD', 'ROTATE']:
                print(f"   ✅ 决策有效")
                status = "SUCCESS"
            else:
                print(f"   ⚠️  决策格式异常")
                status = "FORMAT_ERROR"
            
            # 记录结果
            test_results.append({
                'symbol': symbol,
                'status': status,
                'action': response.get('action'),
                'confidence': response.get('confidence'),
                'error': response.get('error')
            })
            
        except Exception as e:
            print(f"❌ 测试异常: {e}")
            test_results.append({
                'symbol': symbol,
                'status': 'EXCEPTION',
                'action': 'N/A',
                'confidence': 0,
                'error': str(e)
            })
    
    # 生成报告
    print("\n" + "=" * 60)
    print("📊 测试结果总结")
    print("=" * 60)
    
    success_count = sum(1 for r in test_results if r['status'] == 'SUCCESS')
    error_count = sum(1 for r in test_results if r['status'] in ['API_ERROR', 'FORMAT_ERROR', 'EXCEPTION'])
    
    print(f"\n测试总数: {len(test_results)}")
    print(f"✅ 成功: {success_count}")
    print(f"❌ 失败: {error_count}")
    print(f"成功率: {(success_count/len(test_results)*100):.1f}%")
    
    print("\n详细结果:")
    for result in test_results:
        status_icon = "✅" if result['status'] == 'SUCCESS' else "❌"
        print(f"{status_icon} {result['symbol']:10} | {result['status']:15} | {result['action']:6} | Conf: {result['confidence']}")
    
    # 保存报告
    report = {
        'timestamp': datetime.now().isoformat(),
        'test_name': 'API Format Fix Verification',
        'total_tests': len(test_results),
        'success_count': success_count,
        'error_count': error_count,
        'success_rate': success_count / len(test_results) if test_results else 0,
        'results': test_results,
        'improvements': [
            '移除强制 JSON 模式（避免 400 Bad Request）',
            '优化提示词策略（明确 JSON 格式要求）',
            '改进 JSON 解析（自动提取和修复）',
            '增强错误处理（不同错误类型的区分）'
        ]
    }
    
    # 保存 JSON 报告
    with open('storage/api_fix_report.json', 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n💾 报告已保存: storage/api_fix_report.json")
    
    return success_count / len(test_results) if test_results else 0

if __name__ == "__main__":
    success_rate = test_api_format_fix()
    sys.exit(0 if success_rate > 0.5 else 1)
