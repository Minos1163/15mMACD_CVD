"""
轮动引擎：在多个币种间动态分配资金，追求最优收益
"""

import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class RotationStrategy(Enum):
    """轮动策略"""
    MOMENTUM = "MOMENTUM"  # 追逐动量（近期涨幅最大）
    MEAN_REVERSION = "MEAN_REVERSION"  # 均值回归（买跌）
    VOLATILITY = "VOLATILITY"  # 波动率对冲（避免高波动）
    SHARPE = "SHARPE"  # 夏普比（风险调整收益）


@dataclass
class RotationCandidate:
    """轮动候选币种"""
    symbol: str
    current_price: float
    momentum_24h: float  # 24小时涨幅 (%)
    momentum_7d: float  # 7天涨幅 (%)
    volatility: float  # 波动率
    rsi: float  # RSI 指标 (0-100)
    score: float  # 综合评分
    recommended_allocation: float  # 推荐分配比例


class RotationEngine:
    """
    轮动引擎：
    - 评估多个币种的吸引力
    - 动态调整持仓分配
    - 支持多种轮动策略
    """

    def __init__(self, strategy: RotationStrategy = RotationStrategy.MOMENTUM):
        """
        Args:
            strategy: 轮动策略
        """
        self.strategy = strategy
        self.history: List[Dict] = []
        self.current_allocation: Dict[str, float] = {}  # symbol -> allocation_pct
        self.rotation_log: List[Dict] = []

    def evaluate_candidates(
        self,
        market_data: Dict[str, Dict],
    ) -> List[RotationCandidate]:
        """
        评估候选币种

        Args:
            market_data: 市场数据 {symbol: {metrics}}

        Returns:
            排序后的候选币种列表
        """
        candidates = []

        for symbol, metrics in market_data.items():
            score = self._calculate_score(metrics)

            candidate = RotationCandidate(
                symbol=symbol,
                current_price=metrics.get("current_price", 0),
                momentum_24h=metrics.get("momentum_24h", 0),
                momentum_7d=metrics.get("momentum_7d", 0),
                volatility=metrics.get("volatility", 0),
                rsi=metrics.get("rsi", 50),
                score=score,
                recommended_allocation=0.0,  # 稍后计算
            )
            candidates.append(candidate)

        # 按评分从高到低排序
        candidates.sort(key=lambda x: x.score, reverse=True)

        # 计算推荐分配比例
        candidates = self._allocate_capital(candidates)

        return candidates

    def _calculate_score(self, metrics: Dict) -> float:
        """
        根据策略计算币种评分

        Args:
            metrics: 币种指标

        Returns:
            评分（0-100）
        """
        if self.strategy == RotationStrategy.MOMENTUM:
            return self._score_momentum(metrics)
        elif self.strategy == RotationStrategy.MEAN_REVERSION:
            return self._score_mean_reversion(metrics)
        elif self.strategy == RotationStrategy.VOLATILITY:
            return self._score_volatility(metrics)
        elif self.strategy == RotationStrategy.SHARPE:
            return self._score_sharpe(metrics)
        else:
            return 0.0

    def _score_momentum(self, metrics: Dict) -> float:
        """动量策略评分"""
        momentum_24h = metrics.get("momentum_24h", 0)
        momentum_7d = metrics.get("momentum_7d", 0)
        volatility = metrics.get("volatility", 0)

        # 高近期涨幅 + 适度波动
        momentum_score = (momentum_24h * 0.4 + momentum_7d * 0.3)
        volatility_penalty = max(0, 1 - volatility * 10) * 10
        
        return momentum_score * 0.7 + volatility_penalty * 0.3

    def _score_mean_reversion(self, metrics: Dict) -> float:
        """均值回归策略评分"""
        momentum_24h = metrics.get("momentum_24h", 0)
        rsi = metrics.get("rsi", 50)

        # 买超跌币（低涨幅）且 RSI 超卖
        reversion_score = max(0, -momentum_24h * 2)  # 跌幅越大越好
        rsi_score = max(0, 30 - rsi) if rsi < 50 else 0  # RSI < 30 超卖

        return reversion_score * 0.6 + rsi_score * 0.4

    def _score_volatility(self, metrics: Dict) -> float:
        """波动率对冲策略评分"""
        volatility = metrics.get("volatility", 0)
        momentum_24h = metrics.get("momentum_24h", 0)

        # 低波动 + 小幅正收益
        volatility_score = max(0, 1 - volatility) * 100
        momentum_score = max(0, momentum_24h) if momentum_24h > 0 else 0

        return volatility_score * 0.7 + momentum_score * 0.3

    def _score_sharpe(self, metrics: Dict) -> float:
        """夏普比策略评分（风险调整收益）"""
        momentum_24h = metrics.get("momentum_24h", 0)
        volatility = metrics.get("volatility", 0.01)
        rsi = metrics.get("rsi", 50)

        # Sharpe Ratio ≈ (收益 / 风险)
        risk_adjusted_return = (momentum_24h / max(volatility, 0.01)) * 10
        
        # RSI 平衡（避免极端）
        rsi_balance = max(0, 1 - abs(rsi - 50) / 50) * 10

        return min(100, max(0, risk_adjusted_return + rsi_balance))

    def _allocate_capital(
        self, candidates: List[RotationCandidate]
    ) -> List[RotationCandidate]:
        """
        根据评分分配资本

        Args:
            candidates: 候选列表

        Returns:
            分配后的候选列表
        """
        if not candidates:
            return candidates

        # 获取前 5 个候选
        top_candidates = candidates[:5]

        # 权重分配：排名越靠前权重越高
        weights = [5, 3, 2, 1, 0.5][:len(top_candidates)]
        total_weight = sum(weights)

        for candidate, weight in zip(top_candidates, weights):
            candidate.recommended_allocation = (weight / total_weight) * 100

        # 其他币种分配 0%
        for candidate in candidates[len(top_candidates):]:
            candidate.recommended_allocation = 0.0

        return candidates

    def should_rotate(
        self,
        old_allocation: Dict[str, float],
        new_allocation: Dict[str, float],
        min_change_pct: float = 10.0,
    ) -> bool:
        """
        判断是否应该执行轮动

        Args:
            old_allocation: 当前分配
            new_allocation: 新分配
            min_change_pct: 最小变化百分比

        Returns:
            是否应该轮动
        """
        total_change = 0.0

        all_symbols = set(old_allocation.keys()) | set(new_allocation.keys())

        for symbol in all_symbols:
            old_pct = old_allocation.get(symbol, 0)
            new_pct = new_allocation.get(symbol, 0)
            change = abs(old_pct - new_pct)
            total_change += change

        # 变化幅度足够大才轮动（避免频繁轮动）
        return total_change >= min_change_pct

    def execute_rotation(
        self,
        old_allocation: Dict[str, float],
        new_allocation: Dict[str, float],
        current_positions: Dict[str, float],  # symbol -> quantity
        current_prices: Dict[str, float],  # symbol -> price
    ) -> Dict:
        """
        执行轮动：生成具体的交易指令

        Args:
            old_allocation: 当前分配
            new_allocation: 新分配
            current_positions: 当前持仓数量
            current_prices: 当前价格

        Returns:
            轮动计划 {symbol: action}
        """
        rotation_plan = {}
        timestamp = datetime.now().isoformat()

        all_symbols = set(old_allocation.keys()) | set(new_allocation.keys())

        for symbol in all_symbols:
            old_pct = old_allocation.get(symbol, 0)
            new_pct = new_allocation.get(symbol, 0)

            # 需要调整的方向
            if new_pct > old_pct:
                action = "BUY"
                change_pct = new_pct - old_pct
            elif new_pct < old_pct:
                action = "SELL"
                change_pct = old_pct - new_pct
            else:
                action = "HOLD"
                change_pct = 0

            rotation_plan[symbol] = {
                "action": action,
                "old_allocation_pct": old_pct,
                "new_allocation_pct": new_pct,
                "change_pct": change_pct,
                "current_price": current_prices.get(symbol, 0),
            }

        # 记录轮动日志
        log_entry = {
            "timestamp": timestamp,
            "strategy": self.strategy.value,
            "rotation_plan": rotation_plan,
        }
        self.rotation_log.append(log_entry)
        self.current_allocation = new_allocation

        return rotation_plan

    def get_rotation_history(self, limit: int = 10) -> List[Dict]:
        """
        获取轮动历史

        Args:
            limit: 返回最近多少条记录

        Returns:
            轮动历史列表
        """
        return self.rotation_log[-limit:]

    def export_state(self) -> str:
        """导出轮动引擎状态"""
        return json.dumps(
            {
                "strategy": self.strategy.value,
                "current_allocation": self.current_allocation,
                "rotation_log": self.rotation_log[-50:],  # 保留最近50条
                "exported_at": datetime.now().isoformat(),
            },
            indent=2,
        )
