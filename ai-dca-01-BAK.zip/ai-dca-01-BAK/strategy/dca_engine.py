"""
DCA (Dollar Cost Averaging) 定投引擎
"""

import json
import math
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class DCAPeriod(Enum):
    HOURLY = "HOURLY"
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"


@dataclass
class DCAPosition:
    symbol: str
    target_position_size: float  # 目标持仓数量
    current_position_size: float  # 当前持仓数量
    average_cost: float  # 平均成本
    entry_times: List[float]  # 多次入场时间戳
    entry_prices: List[float]  # 多次入场价格
    total_invested: float  # 总投入金额
    period: DCAPeriod
    next_buy_time: float


class DCAEngine:
    """
    定投引擎：
    - 定期投入固定金额
    - 分批建仓降低风险
    - 自动计算投入金额和数量
    """

    def __init__(self, base_investment: float = 100, period: DCAPeriod = DCAPeriod.DAILY):
        """
        Args:
            base_investment: 每次定投的基础金额（USDT）
            period: 定投周期
        """
        self.base_investment = base_investment
        self.period = period
        self.positions: Dict[str, DCAPosition] = {}

    def should_dca_buy(self, symbol: str, current_time: float) -> bool:
        """
        检查是否应该执行定投

        Args:
            symbol: 币种
            current_time: 当前时间戳

        Returns:
            是否应该买入
        """
        if symbol not in self.positions:
            return True

        position = self.positions[symbol]
        return current_time >= position.next_buy_time

    def calculate_dca_amount(
        self,
        symbol: str,
        current_price: float,
        account_balance: float,
        volatility: float = 0.01,
    ) -> Tuple[float, float]:
        """
        计算本次定投的金额和数量

        Args:
            symbol: 币种
            current_price: 当前价格
            account_balance: 账户余额
            volatility: 波动率（用于调整投入大小）

        Returns:
            (投入金额 USDT, 购买数量)
        """
        # 基础投入金额
        base_amount = self.base_investment

        # 根据波动率调整投入金额（高波动时降低投入）
        volatility_factor = max(0.5, 1.0 - volatility * 2)
        adjusted_amount = base_amount * volatility_factor

        # 确保不超过账户余额的 5%
        max_safe_amount = account_balance * 0.05
        final_amount = min(adjusted_amount, max_safe_amount)

        # 计算购买数量
        quantity = final_amount / current_price

        return final_amount, quantity

    def add_position(
        self,
        symbol: str,
        initial_price: float,
        initial_amount: float,
        current_time: float,
    ):
        """
        添加新的定投头寸

        Args:
            symbol: 币种
            initial_price: 初始价格
            initial_amount: 初始投入金额
            current_time: 当前时间戳
        """
        quantity = initial_amount / initial_price
        position = DCAPosition(
            symbol=symbol,
            target_position_size=quantity * 1.5,  # 目标为初始投入的1.5倍
            current_position_size=quantity,
            average_cost=initial_price,
            entry_times=[current_time],
            entry_prices=[initial_price],
            total_invested=initial_amount,
            period=self.period,
            next_buy_time=self._calculate_next_buy_time(current_time),
        )
        self.positions[symbol] = position

    def update_position(
        self,
        symbol: str,
        amount: float,
        current_price: float,
        current_time: float,
    ):
        """
        更新定投头寸（增加投入）

        Args:
            symbol: 币种
            amount: 本次投入金额
            current_price: 当前价格
            current_time: 当前时间戳
        """
        if symbol not in self.positions:
            self.add_position(symbol, current_price, amount, current_time)
            return

        position = self.positions[symbol]
        quantity = amount / current_price

        # 更新平均成本
        total_quantity = position.current_position_size + quantity
        position.average_cost = (
            position.total_invested + amount
        ) / total_quantity

        position.current_position_size = total_quantity
        position.total_invested += amount
        position.entry_times.append(current_time)
        position.entry_prices.append(current_price)
        position.next_buy_time = self._calculate_next_buy_time(current_time)

    def should_stop_dca(self, symbol: str, current_price: float) -> bool:
        """
        判断是否应该停止定投

        Args:
            symbol: 币种
            current_price: 当前价格

        Returns:
            是否应该停止定投
        """
        if symbol not in self.positions:
            return False

        position = self.positions[symbol]

        # 如果已达到目标持仓，停止定投
        if position.current_position_size >= position.target_position_size:
            return True

        # 如果亏损超过 20%，也停止定投
        if current_price < position.average_cost * 0.8:
            return True

        return False

    def get_statistics(self, symbol: str, current_price: float) -> Dict:
        """
        获取定投统计信息

        Args:
            symbol: 币种
            current_price: 当前价格

        Returns:
            统计信息字典
        """
        if symbol not in self.positions:
            return {}

        position = self.positions[symbol]
        current_value = position.current_position_size * current_price
        unrealized_pnl = current_value - position.total_invested
        unrealized_pnl_pct = (unrealized_pnl / position.total_invested * 100) if position.total_invested > 0 else 0

        return {
            "symbol": symbol,
            "total_invested": round(position.total_invested, 2),
            "current_quantity": round(position.current_position_size, 4),
            "average_cost": round(position.average_cost, 2),
            "current_price": round(current_price, 2),
            "current_value": round(current_value, 2),
            "unrealized_pnl": round(unrealized_pnl, 2),
            "unrealized_pnl_pct": round(unrealized_pnl_pct, 2),
            "target_quantity": round(position.target_position_size, 4),
            "progress_pct": round(
                (position.current_position_size / position.target_position_size * 100)
                if position.target_position_size > 0
                else 0,
                2,
            ),
            "num_entries": len(position.entry_times),
        }

    def _calculate_next_buy_time(self, current_time: float) -> float:
        """
        计算下次买入时间

        Args:
            current_time: 当前时间戳

        Returns:
            下次买入时间戳
        """
        period_seconds = {
            DCAPeriod.HOURLY: 3600,
            DCAPeriod.DAILY: 86400,
            DCAPeriod.WEEKLY: 604800,
            DCAPeriod.MONTHLY: 2592000,
        }

        return current_time + period_seconds.get(self.period, 86400)

    def export_state(self) -> str:
        """导出定投状态为 JSON"""
        positions_data = {}
        for symbol, position in self.positions.items():
            positions_data[symbol] = {
                "symbol": position.symbol,
                "target_position_size": position.target_position_size,
                "current_position_size": position.current_position_size,
                "average_cost": position.average_cost,
                "total_invested": position.total_invested,
                "period": position.period.value,
                "entry_times": position.entry_times,
                "entry_prices": position.entry_prices,
                "next_buy_time": position.next_buy_time,
            }

        return json.dumps(
            {
                "base_investment": self.base_investment,
                "period": self.period.value,
                "positions": positions_data,
                "exported_at": datetime.now().isoformat(),
            },
            indent=2,
        )
