# AI DCA Trading System - 可自我修正的交易系统

**当前状态**: ✅ **Shadow Mode 测试完成 (2024-01-13)**

一个企业级的 AI 加密货币量化交易系统，集成了 DeepSeek AI、Binance 交易所、影子交易、异常检测等功能。

## 📊 最新进度

### 🎯 2024-01-13 完成事项
- ✅ Shadow Mode DCA 定投模拟 (10 天模拟, 3 笔交易, 100% 成功)
- ✅ 交易日志生成 (`shadow_dca_log.jsonl`)
- ✅ DCA 状态快照 (`dca_state.json`)
- ✅ 详细测试报告 (`SHADOW_MODE_TEST_REPORT.md`)
- ✅ 后续行动计划 (`NEXT_STEPS.md`)
- ✅ 系统评分: 🟢 **优秀 (A+)**

### 📈 核心成就
- 10 个完整的模块实现 (2,447 行代码)
- 3 个关键 API 集成与验证 (DeepSeek, Binance, Shadow Account)
- 5 个详细技术文档
- 4 个系统测试脚本
- 完整的 Shadow Mode 演示
- 100% 交易成功率

---

## 🚀 快速开始

### 快速链接
- 📋 [**执行总结**](EXECUTION_SUMMARY.md) - 5 分钟了解项目现状
- 📅 [**后续计划**](NEXT_STEPS.md) - 立即可执行的任务清单
- 🔍 [**文档索引**](INDEX.md) - 快速查找相关文档
- 📊 [**详细报告**](SHADOW_MODE_TEST_REPORT.md) - 完整的技术数据

### 1. 环境准备（Ubuntu 24.04 / 无需 Docker）

```bash
cd /root/git/ai-dca-system
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. 立即运行 Shadow Mode DCA

```bash
# 运行 Shadow Mode DCA 定投模拟
python test_shadow_dca.py

# 查看生成的文件
dir storage/shadow_dca_log.jsonl
dir storage/dca_state.json
```

### 3. 配置

编辑 `config/execution.yaml` 设置：
- 交易模式 (SHADOW/REAL)
- 风险参数
- API 密钥

### 3. 运行主程序

```bash
python main.py
```

### 4. 启动 Dashboard（可选，便于远程监控与启停）

```bash
# Terminal 1: Backend
cd dashboard/backend
python -m uvicorn app:app --host 0.0.0.0 --port 8000

# Terminal 2: Frontend
# 在浏览器打开 dashboard/frontend/index.html
```

> 提示：如果要在远程服务器上 7x24 运行，可将 backend 部署在 `/root/git/` 同级目录，前端通过反向代理或直接文件服务访问。管理端口请加白名单与认证。

## 核心功能

### ✅ AI 决策引擎
- 多角色 AI（交易官、风控官、复盘官）
- 可解释的决策输出
- 置信度评分

### ✅ 风险控制
- 全局熔断机制 (Kill Switch)
- 异常行情自动检测
- 账户级保护

### ✅ 影子账户
- 无风险策略测试
- 实盘 vs Shadow 对比
- AI 策略评分

### ✅ 市场状态识别
- 趋势/震荡/异常判断
- 自适应 Prompt 选择
- Regime-aware 交易

### ✅ 数据看板
- 实时决策监控
- 交易历史回放
- 性能指标展示

## 文件说明

- `DCA_STRATEGY_GUIDE.md` - DCA 策略说明、AI vs 人工参数分工、远程监控面板设计建议

### 配置文件
- `config/execution.yaml` - 执行模式和风险参数

### AI Prompts
- `ai/prompts/system_base.md` - 基础系统提示词
- `ai/prompts/role_trader.md` - 交易官角色
- `ai/prompts/role_risk.md` - 风控官角色
- `ai/prompts/role_reviewer.md` - 复盘官角色

### 数据存储
- `storage/decisions.jsonl` - AI 决策日志
- `storage/trades_real.jsonl` - 实盘交易记录
- `storage/trades_shadow.jsonl` - 影子交易记录

## 工作流程

```
1. 拉取市场数据
   ↓
2. 构建 AI 提示词
   ↓
3. 调用 DeepSeek API 获取决策
   ↓
4. 风控检查（Kill Switch）
   ↓
5. 影子账户模拟执行
   ↓
6. 真实账户执行（如果启用）
   ↓
7. 记录和评分
```

## 安全说明

### ⚠️ 重要
1. 生产环境必须启用 Kill Switch
2. 首次使用建议 SHADOW 模式测试
3. 定期检查 `storage/halt_log.jsonl` 中的异常记录
4. 不要共享 API 密钥

## 下一步计划

- [ ] Prompt 自动进化
- [ ] 深度学习集成
- [ ] Ubuntu 7×24 部署（systemd + 日志/告警）
- [ ] 监控告警系统
- [ ] 历史回测系统

## 贡献

欢迎提交问题和改进建议！

## 许可证

MIT License
