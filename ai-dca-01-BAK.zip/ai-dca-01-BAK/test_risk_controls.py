# -*- coding: utf-8 -*-
"""
测试风险控制机制：KillSwitch 与 AnomalyDetector 的触发与恢复
"""
import json
from risk.kill_switch import KillSwitch
from risk.anomaly_detector import AnomalyDetector
from shadow.shadow_account import ShadowAccount
from datetime import datetime
from pathlib import Path

# Ensure storage directory exists
Path(__file__).parent.joinpath('storage').mkdir(parents=True, exist_ok=True)

results = []

# 场景1：正常情况（不触发）
ks = KillSwitch()
ad = AnomalyDetector(ks)
market = {"regime": "NORMAL"}
account = {"drawdown": 0.1, "max_drawdown": 0.2}
ai = {"confidence_drop": 0.1}
score, reason = ad.check(market, account, ai)
results.append({"scenario": "normal", "score": score, "reason": reason, "kill_state": ks.state.value})

# 场景2：市场异常触发
ks2 = KillSwitch()
ad2 = AnomalyDetector(ks2)
market2 = {"regime": "ABNORMAL"}
account2 = {"drawdown": 0.0, "max_drawdown": 0.2}
ai2 = {"confidence_drop": 0.0}
score2, reason2 = ad2.check(market2, account2, ai2)
results.append({"scenario": "market_abnormal", "score": score2, "reason": reason2, "kill_state": ks2.state.value})

# 场景3：账户回撤超限触发
ks3 = KillSwitch()
ad3 = AnomalyDetector(ks3)
market3 = {"regime": "NORMAL"}
account3 = {"drawdown": 0.35, "max_drawdown": 0.2}
ai3 = {"confidence_drop": 0.0}
score3, reason3 = ad3.check(market3, account3, ai3)
results.append({"scenario": "account_drawdown", "score": score3, "reason": reason3, "kill_state": ks3.state.value})

# 场景4：AI 信心崩塌触发
ks4 = KillSwitch()
ad4 = AnomalyDetector(ks4)
market4 = {"regime": "NORMAL"}
account4 = {"drawdown": 0.05, "max_drawdown": 0.2}
ai4 = {"confidence_drop": 0.6}
score4, reason4 = ad4.check(market4, account4, ai4)
results.append({"scenario": "ai_confidence_collapse", "score": score4, "reason": reason4, "kill_state": ks4.state.value})

# 场景5：ShadowAccount 卖出与止损模拟
shadow = ShadowAccount(equity=1000.0)
# 模拟建仓
shadow.buy('BTCUSDT', 0.1, 20000.0)
# 价格下跌到 10000，触发止损条件（我们直接调用 sell）
sale = shadow.sell('BTCUSDT', price=10000.0)
results.append({"scenario": "shadow_stop_loss", "sale": sale, "positions_remaining": shadow.get_positions(), "pnl_history": shadow.pnl_history})

# 保存报告
out = {
    'timestamp': datetime.now().isoformat(),
    'results': results
}

Path = __import__('pathlib').Path
out_path = Path(__file__).parent / 'storage' / 'risk_test_report.json'
out_path.parent.mkdir(parents=True, exist_ok=True)
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)

print('Risk control tests completed. Report:', out_path)
