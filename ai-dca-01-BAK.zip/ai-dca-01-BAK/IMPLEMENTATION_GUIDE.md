# 可自我修正的交易系统 - 完整指南

## 📋 新增模块总览

### 1. **策略引擎** (`strategy/`)
- **DCA Engine** (`dca_engine.py`) - 定投引擎
  - 定期投入固定金额
  - 分批建仓降低风险
  - 自动计算投入金额和数量
  
- **Rotation Engine** (`rotation_engine.py`) - 轮动引擎
  - 多策略支持（动量、均值回归、波动率、夏普比）
  - 动态资金分配
  - 自动轮动决策

### 2. **执行器** (`execution/`)
- **Executor** (`executor.py`) - 交易执行器
  - 订单管理（创建、提交、成交、取消）
  - 生命周期跟踪
  - 执行历史记录和统计

### 3. **回放系统** (`replay/`)
- **Replay Engine** (`replay_engine.py`) - 回放引擎
  - 加载历史市场数据
  - 模拟 AI 决策执行
  - 决策准确性分析
  
- **Backtest Scorer** (`backtest_scorer.py`) - 回测评分系统
  - 14+ 性能指标
  - 夏普比、索提诺比、Calmar 比率等
  - 多模型对比评分

- **Correction Engine** (`correction_engine.py`) - 自我修正核心
  - Prompt 版本管理和 A/B 测试
  - 参数优化（网格搜索、随机搜索、贝叶斯优化）
  - 自动修改建议

### 4. **监控与运维** (`dashboard/`)
- `dashboard/backend/app.py` - 监控后端 API（FastAPI）
- `dashboard/frontend/` - 简易前端页面（本地浏览器访问）

> 说明：本项目已切换为 **Ubuntu 24.04 直跑（无 Docker）**，Docker 相关内容已移除。

---

## 🚀 使用示例

### 场景 1: 使用 DCA 定投

```python
from strategy.dca_engine import DCAEngine, DCAPeriod

# 初始化 DCA 引擎：每天投入 100 USDT
dca = DCAEngine(base_investment=100, period=DCAPeriod.DAILY)

# 检查是否应该买入
if dca.should_dca_buy("BTCUSDT", current_time):
    # 计算本次投入金额和数量
    amount, qty = dca.calculate_dca_amount(
        symbol="BTCUSDT",
        current_price=42000,
        account_balance=10000,
        volatility=0.02
    )
    
    # 执行买入并更新头寸
    dca.update_position("BTCUSDT", amount, 42000, current_time)
    
    # 获取统计信息
    stats = dca.get_statistics("BTCUSDT", 42100)
    print(f"DCA 进度: {stats['progress_pct']}%")
```

### 场景 2: 使用轮动引擎

```python
from strategy.rotation_engine import RotationEngine, RotationStrategy

# 初始化轮动引擎
rotator = RotationEngine(strategy=RotationStrategy.MOMENTUM)

# 市场数据
market_data = {
    "BTCUSDT": {
        "current_price": 42000,
        "momentum_24h": 5.2,  # 24小时涨幅
        "momentum_7d": 8.5,
        "volatility": 0.02,
        "rsi": 65
    },
    "ETHUSDT": {
        "current_price": 2500,
        "momentum_24h": 3.1,
        "momentum_7d": 6.2,
        "volatility": 0.018,
        "rsi": 55
    }
}

# 评估候选币种
candidates = rotator.evaluate_candidates(market_data)

# 打印评分排序
for candidate in candidates:
    print(f"{candidate.symbol}: {candidate.score:.2f}, 推荐分配: {candidate.recommended_allocation:.1f}%")

# 决定是否轮动
new_allocation = {c.symbol: c.recommended_allocation for c in candidates}
if rotator.should_rotate(old_allocation, new_allocation):
    plan = rotator.execute_rotation(old_allocation, new_allocation, positions, prices)
```

### 场景 3: 回测和评分

```python
from replay.backtest_scorer import BacktestScorer, MetricType

scorer = BacktestScorer()

# 创建回测结果
result = scorer.create_backtest_result(
    strategy_name="DCA + Rotation",
    model_version="deepseek-v2.5",
    parameters={"dca_amount": 100, "rotation_period": 24},
    start_date="2024-01-01",
    end_date="2024-12-31",
    remarks="初始版本"
)

# 计算性能指标
trades = [
    {"pnl": 150, "timestamp": 1000},
    {"pnl": -50, "timestamp": 2000},
    {"pnl": 200, "timestamp": 3000},
]

metrics = scorer.calculate_metrics(
    result,
    initial_capital=10000,
    final_capital=10300,
    trades=trades
)

print(f"夏普比: {metrics.sharpe_ratio}")
print(f"胜率: {metrics.win_rate_pct}%")
print(f"最大回撤: {metrics.max_drawdown_pct}%")

# 对比多个模型
comparisons = scorer.compare_results([result.backtest_id], MetricType.SHARPE_RATIO)

# 选择最佳模型
best = scorer.select_best_result([result.backtest_id])
```

### 场景 4: 自我修正

```python
from replay.correction_engine import SelfCorrectionEngine, OptimizationMethod
from strategy.dca_engine import StrategyParameter

corrector = SelfCorrectionEngine(
    prompt_dir="./ai/prompts",
    config_dir="./config"
)

# 基于回测结果建议 Prompt 修改
backtest_results = {
    "trader": {"win_rate": 35},
    "risk": {"max_drawdown": 25}
}

suggestions = corrector.suggest_prompt_modifications(backtest_results)
print(f"建议修改: {suggestions}")

# 创建 Prompt 变体进行 A/B 测试
if suggestions.get("trader"):
    variant = corrector.create_prompt_variant(
        role="trader",
        original_content=original_prompt,
        modifications=suggestions["trader"]
    )
    print(f"创建变体: {variant.version_id}")

# 优化参数
def backtest_func(params):
    # 执行回测，返回评分
    return 75.5

params = {
    "dca_amount": StrategyParameter("dca_amount", 100, 50, 200, 10),
    "max_positions": StrategyParameter("max_positions", 5, 3, 10, 1),
}

best_params = corrector.optimize_parameters(
    OptimizationMethod.GRID_SEARCH,
    params,
    backtest_func,
    iterations=20
)
print(f"最优参数: {best_params}")
```

### 场景 5: 交易执行

```python
from execution.executor import ExecutionEngine, OrderSide, OrderType

executor = ExecutionEngine()

# 创建订单
order = executor.create_order(
    symbol="BTCUSDT",
    side=OrderSide.BUY,
    quantity=0.5,
    price=42000,
    order_type=OrderType.LIMIT,
    remarks="DCA buy #1"
)

# 提交到交易所
executor.submit_order(order.order_id)

# 标记为成交
executor.fill_order(
    order_id=order.order_id,
    filled_quantity=0.5,
    filled_price=41990,
    fee=10.5
)

# 获取执行统计
summary = executor.get_execution_summary()
print(f"成功率: {summary['success_rate_pct']}%")
print(f"总费用: {summary['total_fee']} USDT")
```

### 场景 6: 回放分析

```python
from replay.replay_engine import ReplayEngine, ReplayMode

replay = ReplayEngine(mode=ReplayMode.BACKTEST)

# 加载历史数据
replay.load_market_data_from_file("./storage/market_data.jsonl")
replay.load_decisions_from_file("./storage/decisions.jsonl")

# 分析性能
performance = replay.get_account_performance()
print(f"总收益: {performance['total_return_usd']} USDT")
print(f"最大回撤: {performance['max_drawdown_pct']}%")

# 分析决策准确性
accuracy = replay.get_decision_accuracy()
print(f"预测准确率: {accuracy['accuracy_pct']}%")

# 导出报告
replay.export_replay_report("./backtest_report.json")
```

---

## 🔄 自我修正工作流

```
┌─────────────────┐
│ 实时交易系统    │
│ (Running)       │
└────────┬────────┘
         │ 记录决策和交易
         ▼
┌─────────────────────────┐
│ 存储决策日志            │
│ storage/decisions.jsonl │
└────────┬────────────────┘
         │ 定期回测
         ▼
┌──────────────────┐
│ Replay 引擎      │
│ 模拟历史执行     │
└────────┬─────────┘
         │
         ▼
┌──────────────────────┐
│ 回测评分系统         │
│ 计算性能指标         │
└────────┬─────────────┘
         │ 分析结果
         ▼
┌────────────────────────────┐
│ 自我修正引擎               │
│ - 提议 Prompt 修改         │
│ - 优化参数                 │
│ - 创建 A/B 测试变体        │
└────────┬───────────────────┘
         │ 下一轮回测
         ▼
┌──────────────────────┐
│ 对比和评分           │
│ 选择最优配置         │
└────────┬─────────────┘
         │ 自动更新
         ▼
┌──────────────────┐
│ 启用新配置       │
│ (Activate)       │
└──────────────────┘
```

---

## 📊 关键性能指标

### 回测评分指标
| 指标 | 说明 | 目标 |
|------|------|------|
| **夏普比** | 风险调整收益 | > 1.5 |
| **索提诺比** | 下方风险调整收益 | > 2.0 |
| **最大回撤** | 最坏时期亏损幅度 | < 20% |
| **胜率** | 盈利交易比例 | > 55% |
| **盈利因子** | 赚/赔比例 | > 1.5 |
| **Calmar 比率** | 收益/最大回撤 | > 1.0 |

---

## 🖥️ Ubuntu 24.04 部署（无 Docker，推荐 systemd）

> 目标：在 `/root/git/` 下 7×24 稳定运行，并能通过 Dashboard 观察状态与日志。

### 1) 运行环境
- Python 3.10+（你已具备）
- 安装依赖：`pip install -r requirements.txt`

### 2) 启动主程序
- 直接运行：`python main.py`
- 建议用 systemd 做开机自启与异常重启（生产环境更稳）

### 3) 启动 Dashboard 后端
- `dashboard/backend/app.py` 使用 FastAPI
- 推荐启动方式：`python -m uvicorn app:app --host 0.0.0.0 --port 8000`

### 4) 前端访问
- 打开 `dashboard/frontend/index.html`
- 或将其放到任意静态文件服务器中（更方便远程访问）

---

## ✅ 检查清单

项目完成度：

- ✅ 策略引擎 (DCA + Rotation)
- ✅ 执行器 (Order Management)
- ✅ 回放系统 (Backtest + Replay)
- ✅ 回测评分 (14+ 指标)
- ✅ 自我修正 (Prompt + Parameter)
- ✅ 监控和健康检查（Dashboard / 日志 / 指标）
- ✅ 完整的自我修正工作流

**该系统现在可以：**
1. ✅ 实时交易（SHADOW 或 REAL）
2. ✅ 记录所有决策和交易
3. ✅ 回放历史并评分
4. ✅ 自动建议 Prompt 改进
5. ✅ 优化策略参数
6. ✅ A/B 测试不同配置
7. ✅ 选择并激活最优模型
8. ✅ Ubuntu 直跑部署和监控

---

## 🔧 高级用法

### 自定义优化函数
```python
def custom_backtest(params):
    dca = DCAEngine(params['dca_amount'])
    # ... 执行回测 ...
    return sharpe_ratio

corrector.optimize_parameters(
    OptimizationMethod.BAYESIAN,
    parameters,
    custom_backtest,
    iterations=50
)
```

### 导出报告
```python
# 导出自我修正报告
corrector.export_correction_report("./correction_report.json")

# 导出回测结果
scorer.export_results("./backtest_results.json")

# 导出回放分析
replay.export_replay_report("./replay_report.json")
```

