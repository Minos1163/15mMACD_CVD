#!/usr/bin/env python3
"""
DeepSeek API 详细诊断报告
"""

import sys
import os
from pathlib import Path
from dotenv import load_dotenv
import requests
import json

# 加载 .env 文件
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

# 获取 API Key
api_key = os.getenv("DEEPSEEK_API_KEY")

print("\n" + "=" * 80)
print("🔍 DeepSeek API 诊断报告")
print("=" * 80)

# ========== 环境检查 ==========
print("\n📋 环境检查")
print("-" * 80)

if api_key:
    print(f"✅ API Key 已配置: {api_key[:10]}...{api_key[-5:]}")
else:
    print("❌ 错误: 未找到 DEEPSEEK_API_KEY")
    sys.exit(1)
print(f"✅ Python 版本: {sys.version.split()[0]}")
print(f"✅ requests 库: {requests.__version__}")

# ========== API 基础连接测试 ==========
print("\n🌐 API 连接测试")
print("-" * 80)

from ai.deepseek_client import DeepSeekClient

client = DeepSeekClient(api_key=api_key)

test_cases = [
    {
        "name": "标准 JSON 交易决策",
        "prompt": "BTC 价格 42000，请给出交易建议",
        "system_prompt": "你是交易 AI，返回 JSON 格式：{'action': 'BUY|SELL|HOLD', 'confidence': 0-1}",
        "temperature": 0.1,
    },
    {
        "name": "简单文本问题",
        "prompt": "什么是区块链？",
        "system_prompt": None,
        "temperature": 0.1,
    },
    {
        "name": "中文内容测试",
        "prompt": "请简要说明加密货币交易的风险",
        "system_prompt": "你是专业交易顾问",
        "temperature": 0.1,
    },
]

results = []

for i, test in enumerate(test_cases, 1):
    print(f"\n📌 测试 {i}: {test['name']}")
    print(f"   系统提示: {test['system_prompt'][:40] if test['system_prompt'] else 'None'}...")
    print(f"   用户问题: {test['prompt'][:50]}...")
    print(f"   温度: {test['temperature']}")
    
    try:
        response = client.ask(
            test['prompt'],
            system_prompt=test['system_prompt'],
            temperature=test['temperature']
        )
        
        success = "error" not in response
        results.append({
            "test": test['name'],
            "success": success,
            "response": response
        })
        
        if success:
            print(f"   ✅ 成功 (字段数: {len(response)})")
            # 显示返回字段
            fields = ", ".join(list(response.keys())[:3])
            print(f"   📊 返回字段: {fields}...")
        else:
            print(f"   ❌ 失败: {response.get('error', 'Unknown error')[:60]}...")
    
    except Exception as e:
        results.append({
            "test": test['name'],
            "success": False,
            "error": str(e)
        })
        print(f"   ❌ 异常: {str(e)[:60]}...")

# ========== 诊断总结 ==========
print("\n" + "=" * 80)
print("📊 诊断总结")
print("=" * 80)

success_count = sum(1 for r in results if r['success'])
total_count = len(results)

print(f"\n成功率: {success_count}/{total_count} ({success_count*100/total_count:.0f}%)")

if success_count >= 1:
    print("\n✅ 结论: API 可正常使用！")
    print("\n💡 建议:")
    print("   1. API Key 有效，可以在生产环境中使用")
    print("   2. 确保网络连接稳定")
    print("   3. 建议实现重试机制处理偶发错误")
    print("   4. 监控 API 调用配额和速率限制")
else:
    print("\n❌ 结论: API 无法正常使用")
    print("\n🔧 故障排查步骤:")
    print("   1. 验证 API Key 是否正确")
    print("   2. 检查网络连接和防火墙设置")
    print("   3. 确认 DeepSeek 服务是否在线")
    print("   4. 检查是否超过 API 配额")
    print("   5. 查看 API 文档是否有更新")

# ========== 详细响应信息 ==========
print("\n" + "=" * 80)
print("📋 详细响应信息")
print("=" * 80)

for result in results:
    print(f"\n测试: {result['test']}")
    print("-" * 60)
    
    if result['success']:
        print("✅ 成功响应:")
        response = result['response']
        if 'error' not in response:
            # 只显示前几个字段
            display_response = dict(list(response.items())[:5])
            print(json.dumps(display_response, indent=2, ensure_ascii=False))
    else:
        if 'error' in result['response']:
            print(f"❌ API 错误: {result['response']['error']}")
        else:
            print(f"❌ 异常: {result.get('error', 'Unknown')}")

# ========== API 配置建议 ==========
print("\n" + "=" * 80)
print("⚙️ API 配置建议")
print("=" * 80)

print("""
当前配置:
  - Base URL: https://api.deepseek.com/v1
  - Model: deepseek-chat
  - Default Temperature: 0.1
  - Response Format: JSON (可选)

优化建议:
  1. 对于确定性任务（交易决策）: temperature = 0.1
  2. 对于创意性任务（分析讨论）: temperature = 0.7
  3. 实现超时处理: timeout = 30s
  4. 添加重试机制: max_retries = 3
  5. 使用连接池提高性能

错误处理优先级:
  1. 网络错误 (ConnectionError) → 使用 Mock 决策
  2. 超时错误 (Timeout) → 重试或使用 Mock 决策
  3. 认证错误 (401) → 更新 API Key
  4. 请求错误 (400) → 检查数据格式
  5. 速率限制 (429) → 实现退避策略

生产环境建议:
  ✓ 启用日志记录所有 API 调用
  ✓ 设置监控告警
  ✓ 实现优雅降级（Mock 决策）
  ✓ 定期测试 API 可用性
  ✓ 保持 API Key 安全和轮换
""")

print("\n✅ 诊断完成！")
