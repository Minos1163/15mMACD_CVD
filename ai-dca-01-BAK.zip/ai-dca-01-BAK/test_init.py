#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from pathlib import Path
from replay.correction_engine import SelfCorrectionEngine

prompt_dir = Path(__file__).parent / "ai" / "prompts"
config_dir = Path(__file__).parent / "config"

print(f"prompt_dir exists: {prompt_dir.exists()}")
print(f"config_dir exists: {config_dir.exists()}")

try:
    corrector = SelfCorrectionEngine(
        prompt_dir=str(prompt_dir),
        config_dir=str(config_dir)
    )
    print("初始化成功")
except Exception as e:
    print(f"初始化失败: {e}")
    import traceback
    traceback.print_exc()