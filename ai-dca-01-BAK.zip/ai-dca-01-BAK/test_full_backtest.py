#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
首次完整回测：使用历史数据进行完整的 DCA + 轮动策略回测
"""

import sys
import os
import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv
from collections import defaultdict

# 确保输出编码为 UTF-8
if sys.stdout.encoding != 'utf-8':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 加载环境变量
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

# Monte Carlo and AI flags
AI_ENABLED = os.getenv("AI_ENABLED", "1") != "0"
MC_NOISE_STD = float(os.getenv("MC_NOISE_STD", "0.0"))
MC_SEED = os.getenv("MC_SEED")

print("=" * 80)
print("📊 首次完整回测")
print("=" * 80)

# ========== 环境准备 ==========
print("\n📋 环境初始化")
print("-" * 80)

api_key = os.getenv("BINANCE_API_KEY")
api_secret = os.getenv("BINANCE_SECRET")

# 导入系统模块
try:
    from broker.binance_broker import BinanceBroker
    from shadow.shadow_account import ShadowAccount
    from strategy.dca_engine import DCAEngine, DCAPeriod
    from strategy.rotation_engine import RotationEngine, RotationStrategy
    from execution.executor import ExecutionEngine, OrderSide, OrderType
    from replay.backtest_scorer import BacktestScorer
    import requests
    import random
    print("✅ 所有模块导入成功")
except ImportError as e:
    print(f"❌ 模块导入失败: {e}")
    sys.exit(1)

# ========== 初始化组件 ==========
print("\n🔧 初始化组件")
print("-" * 80)

# 如果启用蒙特卡洛噪声且提供了种子，只在外层初始化时设置一次随机种子
if MC_NOISE_STD > 0.0 and MC_SEED is not None:
    try:
        random.seed(int(MC_SEED))
    except Exception:
        pass

try:
    broker = BinanceBroker(api_key=api_key or "", api_secret=api_secret or "")
    shadow = ShadowAccount(equity=5000.0)
    dca = DCAEngine(base_investment=100, period=DCAPeriod.DAILY)
    rotation = RotationEngine(strategy=RotationStrategy.MOMENTUM)
    executor = ExecutionEngine()
    scorer = BacktestScorer()
    
    print(f"✅ Broker 已初始化")
    print(f"✅ Shadow 账户: ${shadow.equity:.2f}")
    print(f"✅ DCA 引擎已初始化（每日投入 $100）")
    print(f"✅ 轮动引擎已初始化（动量策略）")
    print(f"✅ 执行器已初始化")
    print(f"✅ 回测评分器已初始化")
    
    # AI 客户端与提示构建器
    from ai.deepseek_client import DeepSeekClient
    from ai.prompt_builder import PromptBuilder
    deepseek = DeepSeekClient()
    prompt_builder = PromptBuilder()
except Exception as e:
    print(f"❌ 初始化失败: {e}")
    sys.exit(1)

# ========== 获取历史数据 ==========
print("\n" + "=" * 80)
print("📈 获取历史数据")
print("=" * 80)

trading_symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
backtest_days = 30  # 30天回测周期
historical_klines = {}

print(f"\n获取 {backtest_days} 天的历史日线数据...")

for symbol in trading_symbols:
    try:
        r = requests.get(
            "https://api.binance.com/api/v3/klines",
            params={"symbol": symbol, "interval": "1d", "limit": backtest_days},
            timeout=10,
        )
        r.raise_for_status()
        klines = r.json()
        
        # 转换为易用格式 (时间戳, 开盘, 最高, 最低, 收盘, 成交量)
        processed_klines = []
        for kline in klines:
            # 允许在 Monte Carlo 模式下加入随机扰动
            open_p = float(kline[1])
            high_p = float(kline[2])
            low_p = float(kline[3])
            close_p = float(kline[4])

            if MC_NOISE_STD > 0.0:
                # 对每根 K 线应用独立噪声
                factor_o = 1.0 + random.gauss(0, MC_NOISE_STD)
                factor_h = 1.0 + random.gauss(0, MC_NOISE_STD)
                factor_l = 1.0 + random.gauss(0, MC_NOISE_STD)
                factor_c = 1.0 + random.gauss(0, MC_NOISE_STD)
                open_p *= factor_o
                high_p *= factor_h
                low_p *= factor_l
                close_p *= factor_c

            processed_klines.append({
                "timestamp": int(kline[0]) // 1000,  # 毫秒转秒
                "open": open_p,
                "high": high_p,
                "low": low_p,
                "close": close_p,
                "volume": float(kline[7]),
            })
        
        historical_klines[symbol] = processed_klines
        print(f"  ✅ {symbol}: 获取 {len(processed_klines)} 条日线")
        
    except Exception as e:
        print(f"  ❌ {symbol}: 获取失败，{e}")
        sys.exit(1)

# ========== 回测执行 ==========
print("\n" + "=" * 80)
print("🔄 回测执行（DCA + 轮动）")
print("=" * 80)

initial_capital = shadow.equity
backtest_trades = []
daily_values = []
daily_returns = []
prev_value = initial_capital

# 按时间顺序遍历每一天
max_days = max(len(klines) for klines in historical_klines.values())

for day_idx in range(max_days):
    current_prices = {}
    market_data = {}
    ai_executed = set()
    
    # 收集当日数据
    for symbol in trading_symbols:
        if day_idx < len(historical_klines[symbol]):
            kline = historical_klines[symbol][day_idx]
            current_prices[symbol] = kline["close"]
            
            # 计算动量
            if day_idx >= 7:
                price_7d_ago = historical_klines[symbol][day_idx - 7]["close"]
                momentum_7d = (kline["close"] - price_7d_ago) / price_7d_ago * 100
            else:
                momentum_7d = 0
            
            if day_idx >= 1:
                price_1d_ago = historical_klines[symbol][day_idx - 1]["close"]
                momentum_24h = (kline["close"] - price_1d_ago) / price_1d_ago * 100
            else:
                momentum_24h = 0
            
            # 计算波动率（简化）
            if day_idx >= 7:
                prices_7d = [historical_klines[symbol][i]["close"] for i in range(max(0, day_idx - 7), day_idx + 1)]
                avg_price = sum(prices_7d) / len(prices_7d)
                volatility = sum((p - avg_price) ** 2 for p in prices_7d) / len(prices_7d)
                volatility = (volatility ** 0.5) / avg_price
            else:
                volatility = 0.02
            
            # RSI 简化计算
            rsi = 50 + momentum_7d * 0.5
            rsi = max(0, min(100, rsi))
            
            market_data[symbol] = {
                "current_price": kline["close"],
                "momentum_24h": momentum_24h,
                "momentum_7d": momentum_7d,
                "volatility": volatility,
                "rsi": rsi,
            }
    
    # 日期标识
    day_num = day_idx + 1
    sim_timestamp = int(time.time()) + day_idx * 86400
    
    print(f"\n📅 第 {day_num} 天")
    print("-" * 60)
    
    # 1. 轮动评估（每5天一次）
    if day_idx % 5 == 0 and market_data:
        print(f"  🔄 轮动策略评估...")
        candidates = rotation.evaluate_candidates(market_data)
        if candidates:
            print(f"     推荐首选: {candidates[0].symbol} (评分: {candidates[0].score:.2f})")
    
    # 2. DCA 定投
    dca_executed = False
    for symbol in trading_symbols:
        if symbol not in current_prices:
            continue
        # AI 决策先行（每个符号每日一次）
        try:
            context = {
                'market': f"符号: {symbol}\n当前价格: ${current_prices[symbol]:,.2f}\n7日涨幅: {market_data[symbol]['momentum_7d']:+.2f}%",
                'account': f"现金: ${shadow.equity:,.2f} | 持仓: {shadow.get_positions()}"
            }
            prompt = prompt_builder.build_prompt(context)
            ai_decision = deepseek.ask(
                prompt=prompt,
                system_prompt="你是一个专业的量化交易顾问，需要基于市场数据和账户状态做出交易决策。",
                temperature=0.1,
                force_json=False,
            )
        except Exception as e:
            print(f"  ⚠️ AI error for {symbol}: {e}")
            ai_decision = {}

        action = ai_decision.get('action', 'HOLD') if isinstance(ai_decision, dict) else 'HOLD'
        confidence = float(ai_decision.get('confidence', 0)) if isinstance(ai_decision, dict) else 0.0

        # 如果 AI 建议 SELL，则尝试平仓
        if action == 'SELL' and shadow.get_positions().get(symbol, 0) > 0:
            sale = shadow.sell(symbol, price=current_prices[symbol])
            backtest_trades.append({
                'day': day_num,
                'symbol': symbol,
                'action': 'SELL',
                'quantity': sale.get('quantity', 0),
                'price': current_prices[symbol],
                'pnl': sale.get('pnl', 0),
                'timestamp': datetime.fromtimestamp(sim_timestamp).isoformat(),
                'source': 'AI'
            })
            ai_executed.add(symbol)

        # 如果 AI 建议 BUY 且置信度足够高，则优先执行 AI 买入
        if action == 'BUY' and confidence >= 0.5:
            # 使用 DCA 的计算逻辑来确定基础金额和数量
            base_amount, base_quantity = dca.calculate_dca_amount(
                symbol=symbol,
                current_price=current_prices[symbol],
                account_balance=shadow.equity,
                volatility=market_data[symbol]['volatility'],
            )
            amount = base_amount
            # 根据置信度映射放大仓位
            if confidence >= 0.9:
                amount *= 2.0
            elif confidence >= 0.75:
                amount *= 1.5
            elif confidence >= 0.6:
                amount *= 1.25
            # 重新计算数量
            quantity = amount / current_prices[symbol] if current_prices[symbol] > 0 else base_quantity
            if amount > 0 and shadow.equity >= amount:
                order = executor.create_order(
                    symbol=symbol,
                    side=OrderSide.BUY,
                    quantity=quantity,
                    price=current_prices[symbol],
                    order_type=OrderType.MARKET,
                    remarks=f"AI BUY #{day_num}",
                )
                executor.submit_order(order.order_id)
                fee = amount * 0.001
                executor.fill_order(
                    order_id=order.order_id,
                    filled_quantity=quantity,
                    filled_price=current_prices[symbol],
                    fee=fee,
                )

                shadow.buy(symbol, quantity, current_prices[symbol])
                dca.update_position(symbol, amount, current_prices[symbol], sim_timestamp)

                backtest_trades.append({
                    'day': day_num,
                    'symbol': symbol,
                    'action': 'BUY',
                    'quantity': quantity,
                    'price': current_prices[symbol],
                    'amount': amount,
                    'fee': fee,
                    'timestamp': datetime.fromtimestamp(sim_timestamp).isoformat(),
                    'source': 'AI'
                })
                ai_executed.add(symbol)
        
        price = current_prices[symbol]
        
        # 检查是否应该买入（如果 AI 已经执行则跳过 DCA）
        if symbol in ai_executed:
            continue

        # 检查是否应该买入
        if dca.should_dca_buy(symbol, sim_timestamp):
            amount, quantity = dca.calculate_dca_amount(
                symbol=symbol,
                current_price=price,
                account_balance=shadow.equity,
                volatility=market_data[symbol]["volatility"],
            )
            
            if amount > 0 and shadow.equity >= amount:
                # 创建和执行订单
                order = executor.create_order(
                    symbol=symbol,
                    side=OrderSide.BUY,
                    quantity=quantity,
                    price=price,
                    order_type=OrderType.MARKET,
                    remarks=f"DCA #{day_num}",
                )
                
                executor.submit_order(order.order_id)
                fee = amount * 0.001
                executor.fill_order(
                    order_id=order.order_id,
                    filled_quantity=quantity,
                    filled_price=price,
                    fee=fee,
                )
                
                # 更新账户
                shadow.buy(symbol, quantity, price)
                dca.update_position(symbol, amount, price, sim_timestamp)
                
                # 记录交易
                backtest_trades.append({
                    "day": day_num,
                    "symbol": symbol,
                    "action": "BUY",
                    "quantity": quantity,
                    "price": price,
                    "amount": amount,
                    "fee": fee,
                    "timestamp": datetime.fromtimestamp(sim_timestamp).isoformat(),
                })
                
                dca_executed = True
    
    if dca_executed:
        print(f"  ✅ DCA 定投执行")
    
    # 3. 计算当日账户价值
    current_value = shadow.equity
    positions = shadow.get_positions()
    
    for symbol, quantity in positions.items():
        if symbol in current_prices:
            current_value += quantity * current_prices[symbol]
    
    daily_values.append({
        "timestamp": sim_timestamp,
        "total_value": current_value,
    })
    
    # 计算日收益
    daily_return = current_value - prev_value
    daily_returns.append(daily_return)
    prev_value = current_value
    
    # 打印当日快照
    print(f"  💰 账户快照:")
    print(f"     现金: ${shadow.equity:,.2f}")
    positions_str = " | ".join([f"{sym}: ${qty * current_prices.get(sym, 0):,.2f}" 
                                 for sym, qty in positions.items() if sym in current_prices])
    if positions_str:
        print(f"     持仓: {positions_str}")
    print(f"     总资产: ${current_value:,.2f}")
    print(f"     日收益: ${daily_return:+.2f}")

# ========== 回测统计 ==========
print("\n" + "=" * 80)
print("📊 回测统计")
print("=" * 80)

final_value = daily_values[-1]["total_value"] if daily_values else initial_capital
total_return = final_value - initial_capital
return_pct = (total_return / initial_capital * 100)

print(f"\n💼 投资统计:")
print(f"  初始资本: ${initial_capital:,.2f}")
print(f"  最终资产: ${final_value:,.2f}")
print(f"  总收益: ${total_return:+.2f}")
print(f"  收益率: {return_pct:+.2f}%")

# 交易统计
print(f"\n📈 交易统计:")
print(f"  总交易数: {len(backtest_trades)}")

by_symbol = defaultdict(list)
for trade in backtest_trades:
    by_symbol[trade["symbol"]].append(trade)

for symbol in trading_symbols:
    trades = by_symbol[symbol]
    if trades:
        total_amount = sum(t.get("amount", 0) for t in trades)
        print(f"  {symbol}: {len(trades)} 次 | 总投入 ${total_amount:.2f}")

# ========== 使用 BacktestScorer 计算指标 ==========
print("\n" + "=" * 80)
print("📈 性能指标计算")
print("=" * 80)

print("\n计算 Sharpe、Max Drawdown 等指标...")

# 转换为评分器需要的格式
pnl_entries = []
for i, daily_value in enumerate(daily_values):
    if i == 0:
        prev = initial_capital
    else:
        prev = daily_values[i - 1]["total_value"]
    
    pnl = daily_value["total_value"] - prev
    pnl_entries.append({
        "timestamp": daily_value["timestamp"],
        "pnl": pnl,
    })

# 创建回测结果
result = scorer.create_backtest_result(
    strategy_name="DCA + Momentum Rotation",
    model_version="v1.0",
    parameters={
        "base_investment": 100,
        "dca_period": "DAILY",
        "rotation_strategy": "MOMENTUM",
        "backtest_days": backtest_days,
    },
    start_date=datetime.fromtimestamp(historical_klines[trading_symbols[0]][0]["timestamp"]).date().isoformat(),
    end_date=datetime.fromtimestamp(historical_klines[trading_symbols[0]][-1]["timestamp"]).date().isoformat(),
    remarks=f"首次完整回测，{len(backtest_trades)} 笔交易"
)

# 计算指标
metrics = scorer.calculate_metrics(
    result,
    initial_capital=initial_capital,
    final_capital=final_value,
    trades=pnl_entries,
)
import math

def _safe_num(x, default=0.0):
    try:
        xv = float(x)
        return xv if math.isfinite(xv) else default
    except Exception:
        return default

# 清洗并准备展示/报告用的指标值，避免 Infinity/NaN
total_return_pct = _safe_num(metrics.total_return_pct, 0.0)
annualized_return_pct = _safe_num(metrics.annualized_return_pct, 0.0)
sharpe_ratio = _safe_num(metrics.sharpe_ratio, 0.0)
sortino_ratio = _safe_num(metrics.sortino_ratio, 0.0)
max_drawdown_pct = _safe_num(metrics.max_drawdown_pct, 0.0)
win_rate_pct = _safe_num(metrics.win_rate_pct, 0.0)
profit_factor = _safe_num(metrics.profit_factor, 0.0)
calmar_ratio = _safe_num(metrics.calmar_ratio, 0.0)
recovery_factor = _safe_num(metrics.recovery_factor, 0.0)
avg_trade_return_pct = _safe_num(getattr(metrics, 'avg_trade_return_pct', 0.0), 0.0)
num_winning_trades = int(getattr(metrics, 'num_winning_trades', 0) or 0)
num_losing_trades = int(getattr(metrics, 'num_losing_trades', 0) or 0)

print(f"\n✅ 性能指标:")
print(f"  总收益率: {total_return_pct:.2f}%")
print(f"  年化收益率: {annualized_return_pct:.2f}%")
print(f"  Sharpe 比: {sharpe_ratio:.2f}")
print(f"  Sortino 比: {sortino_ratio:.2f}")
print(f"  最大回撤: {max_drawdown_pct:.2f}%")
print(f"  胜率: {win_rate_pct:.2f}%")
print(f"  盈利因子: {profit_factor:.2f}")
print(f"  Calmar 比: {calmar_ratio:.2f}")

# ========== 保存回测报告 ==========
print("\n" + "=" * 80)
print("💾 保存回测报告")
print("=" * 80)

report_data = {
    "backtest_info": {
        "test_date": datetime.now().isoformat(),
        "strategy": "DCA + Momentum Rotation",
        "backtest_period_days": backtest_days,
        "symbols": trading_symbols,
    },
    "capital": {
        "initial": initial_capital,
        "final": final_value,
        "total_return": total_return,
        "return_pct": return_pct,
    },
        "trades": {
        "total_trades": len(backtest_trades),
        "by_symbol": {
            symbol: {
                "count": len(by_symbol[symbol]),
                "total_amount": sum(t.get("amount", 0) for t in by_symbol[symbol]),
            }
            for symbol in trading_symbols
        },
    },
    "metrics": {
        "total_return_pct": total_return_pct,
        "annualized_return_pct": annualized_return_pct,
        "sharpe_ratio": sharpe_ratio,
        "sortino_ratio": sortino_ratio,
        "max_drawdown_pct": max_drawdown_pct,
        "win_rate_pct": win_rate_pct,
        "profit_factor": profit_factor,
        "calmar_ratio": calmar_ratio,
        "recovery_factor": recovery_factor,
    },
    "daily_values": daily_values,
    "trades_list": backtest_trades,
}

# 保存 JSON 报告
report_file = Path(__file__).parent / "storage" / "backtest_report.json"
report_file.parent.mkdir(parents=True, exist_ok=True)

with open(report_file, "w", encoding="utf-8") as f:
    json.dump(report_data, f, indent=2, ensure_ascii=False)

print(f"✅ 回测报告已保存: {report_file}")

# 生成 Markdown 报告
md_file = Path(__file__).parent / "BACKTEST_REPORT.md"
md_content = f"""# 首次完整回测报告

生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 回测概览

| 项目 | 值 |
|------|-----|
| 策略 | DCA + Momentum Rotation |
| 回测周期 | {backtest_days} 天 |
| 测试币种 | {", ".join(trading_symbols)} |
| 总交易数 | {len(backtest_trades)} |

## 资本效果

| 指标 | 值 |
|------|-----|
| 初始资本 | ${initial_capital:,.2f} |
| 最终资产 | ${final_value:,.2f} |
| **总收益** | **${total_return:+.2f}** |
| **收益率** | **{return_pct:+.2f}%** |

## 性能指标

### 收益指标

| 指标 | 值 | 说明 |
|------|-----|------|
| 总收益率 | {metrics.total_return_pct:.2f}% | 整体投资回报 |
| 年化收益率 | {metrics.annualized_return_pct:.2f}% | 年化换算收益 |
| 平均交易收益 | {metrics.avg_trade_return_pct:.2f}% | 平均单笔收益 |

### 风险指标

| 指标 | 值 | 说明 |
|------|-----|------|
| 最大回撤 | {metrics.max_drawdown_pct:.2f}% | 最大亏损幅度 |
| Sharpe 比 | {metrics.sharpe_ratio:.2f} | 风险调整收益（>1 优秀） |
| Sortino 比 | {metrics.sortino_ratio:.2f} | 下行风险调整收益 |
| Calmar 比 | {metrics.calmar_ratio:.2f} | 收益/回撤比 |

### 交易指标

| 指标 | 值 | 说明 |
|------|-----|------|
| 胜率 | {metrics.win_rate_pct:.2f}% | 盈利交易占比 |
| 赢利交易数 | {metrics.num_winning_trades} | 盈利笔数 |
| 亏损交易数 | {metrics.num_losing_trades} | 亏损笔数 |
| 盈利因子 | {metrics.profit_factor:.2f} | 赚钱/亏钱比（>1 正收益） |

## 交易明细

### 按币种统计

"""

# 替换模板中的 metrics 引用为清洗后的变量
md_content = md_content.replace('{metrics.total_return_pct:', '{total_return_pct:') \
                       .replace('{metrics.annualized_return_pct:', '{annualized_return_pct:') \
                       .replace('{metrics.avg_trade_return_pct:', '{avg_trade_return_pct:') \
                       .replace('{metrics.sharpe_ratio:', '{sharpe_ratio:') \
                       .replace('{metrics.sortino_ratio:', '{sortino_ratio:') \
                       .replace('{metrics.max_drawdown_pct:', '{max_drawdown_pct:') \
                       .replace('{metrics.win_rate_pct:', '{win_rate_pct:') \
                       .replace('{metrics.num_winning_trades}', str(num_winning_trades)) \
                       .replace('{metrics.num_losing_trades}', str(num_losing_trades)) \
                       .replace('{metrics.profit_factor:', '{profit_factor:') \
                       .replace('{metrics.calmar_ratio:', '{calmar_ratio:')

positions = shadow.get_positions()

for symbol in trading_symbols:
    trades = by_symbol[symbol]
    if trades:
        total_amount_sym = sum(t.get('amount', 0) for t in trades)
        total_qty_sym = sum(t.get('quantity', 0) for t in trades)
        avg_cost_sym = (total_amount_sym / total_qty_sym) if total_qty_sym > 0 else 0.0

        md_content += f"\n#### {symbol}\n\n"
        md_content += f"- 交易次数: {len(trades)}\n"
        md_content += f"- 总投入: ${total_amount_sym:.2f}\n"
        md_content += f"- 平均成本: ${avg_cost_sym:.2f}\n"
        md_content += f"- 最终持仓: {positions.get(symbol, 0):.6f}\n"

md_content += f"""

## 分析与建议

### 策略评价

- ✅ **定投策略**: DCA 有效平均成本，适合长期投资
- ✅ **轮动机制**: 动量策略有助于优化持仓配置
- ✅ **风险控制**: 使用影子账户的风险隔离设计

### 性能评价

"""

if return_pct > 10:
    md_content += f"✅ **优秀表现**: 在 {backtest_days} 天内获得 {return_pct:.2f}% 收益\n"
elif return_pct > 0:
    md_content += f"✅ **正收益**: 取得 {return_pct:.2f}% 的正收益\n"
else:
    md_content += f"⚠️ **需要改进**: 回测期间出现 {return_pct:.2f}% 的负收益\n"

if sharpe_ratio > 1:
    md_content += f"✅ **风险调整**: Sharpe 比 {sharpe_ratio:.2f}，风险调整收益良好\n"
elif sharpe_ratio > 0:
    md_content += f"⚠️ **风险调整**: Sharpe 比 {sharpe_ratio:.2f}，可继续优化\n"
else:
    md_content += f"⚠️ **风险控制**: 需加强风险管理\n"

md_content += f"""

### 后续优化方向

1. **策略优化**:
   - 调整 DCA 投入金额和周期
   - 尝试其他轮动策略（均值回归、波动率对冲等）
   - 集成 AI 决策引擎进一步优化

2. **风险管理**:
   - 添加止损机制
   - 实现动态仓位管理
   - 设置投资组合对冲

3. **执行优化**:
   - 优化订单执行时机
   - 减少交易滑点和手续费
   - 实现更智能的买卖决策

## 附录

### 系统配置

- **初始资本**: ${initial_capital:,.2f}
- **每日投入**: $100
- **轮动策略**: MOMENTUM（动量）
- **回测期间**: {backtest_days} 天
- **交易币种**: {", ".join(trading_symbols)}

### 关键指标解释

- **Sharpe 比**: (收益 - 无风险利率) / 标准差，>1 表示风险调整收益良好
- **最大回撤**: 从峰值到谷值的最大百分比下降
- **盈利因子**: 赢利交易总金额 / 亏损交易总金额，>1 表示总体盈利
- **Calmar 比**: 年化收益率 / 最大回撤，越高越好

---
*报告生成时间: {datetime.now().isoformat()}*
"""

with open(md_file, "w", encoding="utf-8") as f:
    f.write(md_content)

print(f"✅ Markdown 报告已保存: {md_file}")

# ========== 最终总结 ==========
print("\n" + "=" * 80)
print("✅ 首次完整回测完成")
print("=" * 80)

print(f"""
📊 回测摘要:
   ✅ 回测周期: {backtest_days} 天
   ✅ 总交易数: {len(backtest_trades)}
   ✅ 初始资本: ${initial_capital:,.2f}
   ✅ 最终资产: ${final_value:,.2f}
   ✅ 总收益: ${total_return:+.2f} ({return_pct:+.2f}%)

🎯 核心指标:
   ✅ Sharpe 比: {metrics.sharpe_ratio:.2f}
   ✅ 最大回撤: {metrics.max_drawdown_pct:.2f}%
   ✅ 胜率: {metrics.win_rate_pct:.2f}%
   ✅ 盈利因子: {metrics.profit_factor:.2f}

📁 生成的文件:
   • {report_file}
   • {md_file}

🚀 系统状态: ✅ 回测完成，结果可用
""")

print("✅ 回测完成！")
