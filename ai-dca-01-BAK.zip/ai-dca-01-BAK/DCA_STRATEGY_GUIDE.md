# 多币种 DCA 策略说明

本指南围绕“什么是 DCA”和“哪些参数由 AI 控制、哪些由你手动控制”进行梳理，并给出运行与监控的工程化建议。

## 1. DCA（Dollar Cost Averaging）策略简述

- **定义**：在单方向持仓的前提下，价格每次向不利方向波动时按计划分批加仓，摊低持仓成本；当价格反弹到目标价时整体或分批止盈。
- **适用场景**：震荡或缓慢反转行情；趋势单边时需限制加仓次数与回撤。
- **核心要点**：
  - 设定**最大加仓次数**与**总资金上限**，防止无限摊平。
  - **止盈 / 止损** 必须硬编码，AI 不得突破。
  - 加仓触发条件（如价格回撤幅度、RSI、TD 序列）可由 AI 在安全区间内微调，以适应不同波动环境。

## 2. 参数分工：AI 可调 vs. 人工硬控

| 模块 | 主要参数 | 控制方 | 说明 |
| --- | --- | --- | --- |
| 交易对池 | `BTCUSDT` 等 | 人工 | 列表即硬白名单，AI 只在名单内交易。
| 持仓与加仓上限 | `max_holding_coins`、`max_add_position_count`、`max_pending_orders` | 人工 | 资金分散度与最大摊平次数的硬边界。
| 止盈 | `single_tp_target` | AI（在区间内） | 允许 AI 在 `0.8% ~ 2.5%` 间自适应，用户可调整默认值。
| 加仓触发 | `add_position_threshold` | AI（在区间内） | AI 可在 `0.5% ~ 2.0%` 之间微调回撤/反弹幅度。
| 技术触发 | `td_*`、`rsi_*` | 混合 | 是否启用 TD/RSI 由你决定；具体阈值 AI 在安全区间内微调。
| 止损/回撤 | `single_coin_stop_loss`、`total_investment_stop_loss`、`max_drawdown_limit` | 人工 | 硬风控，AI 不可突破。
| 再投资 | `profit_reinvestment_ratio` | 人工 | 再投比例，100% 表示利润全额再投入。
| 资金与仓位尺寸 | `ai_min_base_amount` ~ `ai_max_base_amount`、`ai_min_position_ratio` ~ `ai_max_position_ratio` | 人工设边界，AI 内部调度 | AI 根据账户余额与行情决定具体下单金额，但不能越界。
| 账户币种偏好 | `auto_convert_usdc_usdt`、`prefer_usdc` | 人工 | 稳定币偏好与转换策略。
| DeepSeek 行为 | `deepseek_control_level`、`deepseek_temperature`、`deepseek_max_tokens` | 人工 | 决定 AI 干预深度与回复稳定性。
| 自动化开关 | `enable_auto_position_adjust`、`enable_trailing_stop`、`dynamic_grid_enabled` | 人工启用/禁用，AI 负责具体数值 | 你决定是否开放；数值计算由 AI 负责且受风控约束。

## 3. 推荐的参数边界（供参考）

- 止盈：`0.8% - 2.5%`，波动大时取高值，低波动取低值。
- 回撤加仓阈值：`0.5% - 2.0%`，快市放宽，慢市收紧。
- RSI 触发：
  - 多头加仓触发：`25 - 45`
  - 多头减仓触发：`55 - 70`
- 单币止损：`3% - 8%`，总回撤：`10% - 30%`（与账户风险偏好匹配）。

## 4. 运行环境与部署（Ubuntu 24.04，无需 Docker）

- Python 3.10 已就绪，推荐在专用虚拟环境中运行：`python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`
- 入口脚本：`python main.py`（实时）或 `python test_shadow_dca.py`（影子模式回放）。
- 配置文件：
  - `Parameter.txt` —— 策略级参数（本文件）
  - `config/execution.yaml` —— 执行模式与风险开关

## 5. 远程监控 / 启停 / 参数面板（设计稿）

> 目标：在本地浏览器管理位于远程服务器 `/root/git/` 下的脚本，支持启停、状态监控、参数编辑、收益曲线查看。

### 5.1 架构建议

- **后端**（部署在远程 Ubuntu）：
  - FastAPI + Uvicorn，监听 `0.0.0.0:<port>`（例如 9000）。
  - 功能：
    - 进程管理：启动/停止主脚本，返回 PID、运行时长、日志尾部。
    - 参数读写：安全编辑 `Parameter.txt` 与 `config/execution.yaml`（带字段校验）。
    - 状态查询：账户余额、当前持仓、最近交易、回撤、收益曲线数据。
    - 权限：建议启用 Basic Auth 或 JWT，并将管理端口限制在内网或通过反向代理加 IP 白名单。
- **前端**（可直接用现有 `dashboard/frontend` 做轻改）：
  - 单页应用（HTML/JS），提供以下组件：
    - **运行控制**：启动/停止按钮、当前状态灯、PID/运行时长显示。
    - **参数面板**：
      - 可编辑字段：交易对列表、杠杆倍率（如有）、K 线周期、止盈止损、最大加仓次数、加仓阈值。
      - AI 边界：ai_min/max_base_amount、ai_min/max_position_ratio 等。
      - 表单提交调用后端 PATCH 接口，改写配置文件。
    - **行情与收益**：
      - 账户净值曲线、每日 PnL、最大回撤、胜率。
      - 逐笔交易表格（时间、币对、方向、开平仓价、P/L、置信度）。
    - **日志 & 告警**：实时 tail 日志，异常高亮（回撤超阈、交易失败、API 异常）。

### 5.2 示例接口设计（后端）

- `GET /health`：返回进程状态与心跳时间戳。
- `POST /process/start`：启动脚本（命令如 `python /root/git/main.py`）。
- `POST /process/stop`：停止脚本（根据 PID 优雅终止）。
- `GET /config/parameters`：读取 `Parameter.txt` 并结构化返回。
- `PATCH /config/parameters`：写回参数（带类型/范围校验）。
- `GET /metrics/account`：余额、仓位、保证金率、未实现盈亏。
- `GET /metrics/performance`：收益曲线、回撤、胜率、Sharpe 等。
- `GET /logs/tail?lines=200`：返回最新日志。

### 5.3 安全注意

- **不要在页面硬编码或展示 root 密码 / API Key**，采用环境变量 + 服务器本地权限控制。
- 管理端口仅在内网或通过反向代理（Nginx）限制访问；必要时开启双因子或跳板机。
- 日志中脱敏 API 响应与密钥字段。

## 6. 日常操作速查

- 修改参数：编辑 `Parameter.txt`，保存后重启进程或由后端热加载模块触发重载。
- 切换 AI 控制深度：调整 `deepseek_control_level`（full / partial / none）。
- 风险阈值调整：仅改动止损/回撤类硬参数，不允许 AI 自动修改。
- 监控异常：检查日志与 `storage/halt_log.jsonl`；若触发 Kill Switch，先排查账户/行情后再手动解锁。

---
以上改动将参数职责清晰划分，便于在多币种 DCA 环境下让 AI 负责“微调”，而你保留“硬风控”与关键开关。