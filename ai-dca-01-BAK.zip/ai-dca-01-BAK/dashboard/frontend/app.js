const API_URL = "http://localhost:8000/api";

async function loadAccount() {
  try {
    const res = await fetch(`${API_URL}/account`);
    const data = await res.json();
    
    const el = document.getElementById("account");
    el.innerHTML = `
      <div class="stats">
        <div class="stat">
          <label>Balance</label>
          <value>$${data.balance.toFixed(2)}</value>
        </div>
        <div class="stat">
          <label>Equity</label>
          <value>$${data.equity.toFixed(2)}</value>
        </div>
        <div class="stat">
          <label>Drawdown</label>
          <value>${(data.drawdown * 100).toFixed(2)}%</value>
        </div>
        <div class="stat">
          <label>Positions</label>
          <value>${data.active_positions}</value>
        </div>
      </div>
    `;
  } catch (e) {
    console.error("Failed to load account:", e);
  }
}

async function loadDecisions() {
  try {
    const res = await fetch(`${API_URL}/decisions`);
    const data = await res.json();
    
    const el = document.getElementById("decisions");
    el.innerHTML = "";
    
    data.slice(-5).reverse().forEach(d => {
      const dec = d.decision || {};
      el.innerHTML += `
        <div class="card-item">
          <div class="action ${dec.action || 'HOLD'}">${dec.action || 'N/A'}</div>
          <div class="details">
            <div>${dec.symbol || 'N/A'} - ${dec.direction || 'N/A'}</div>
            <div class="small">Confidence: ${(dec.confidence || 0).toFixed(2)}</div>
            <div class="small">${dec.reason || ''}</div>
          </div>
        </div>
      `;
    });
  } catch (e) {
    console.error("Failed to load decisions:", e);
  }
}

async function loadTrades() {
  try {
    const res = await fetch(`${API_URL}/trades/real`);
    const data = await res.json();
    
    const el = document.getElementById("trades");
    el.innerHTML = "";
    
    if (data.length === 0) {
      el.innerHTML = "<p>No trades yet</p>";
      return;
    }
    
    data.slice(-5).reverse().forEach(t => {
      el.innerHTML += `
        <div class="card-item">
          <div class="symbol">${t.symbol || 'N/A'}</div>
          <div class="pnl ${t.pnl > 0 ? 'profit' : 'loss'}">
            ${t.pnl > 0 ? '+' : ''}${t.pnl || 0}
          </div>
        </div>
      `;
    });
  } catch (e) {
    console.error("Failed to load trades:", e);
  }
}

function updateTime() {
  document.getElementById("time").textContent = 
    "Time: " + new Date().toLocaleString();
}

async function refresh() {
  await Promise.all([
    loadAccount(),
    loadDecisions(),
    loadTrades()
  ]);
  updateTime();
}

// Initial load
refresh();

// Auto-refresh every 5 seconds
setInterval(refresh, 5000);
