#!/usr/bin/env python3
"""FastAPI Dashboard Backend

Reads live/sim data from storage files; if API 密钥可用，尝试实时拉取账户快照。
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
from typing import Any, List, Dict
import json

from broker.binance_broker import BinanceBroker

BASE_DIR = Path(__file__).resolve().parents[2]
STORAGE = BASE_DIR / "storage"

app = FastAPI(title="AI DCA Trading Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def load_jsonl(path: Path, limit: int = 50) -> List[dict]:
    """Load last N lines from JSONL file"""
    try:
        if not path.exists():
            return []
        with path.open(encoding="utf-8") as f:
            lines = f.readlines()
            return [json.loads(line) for line in lines[-limit:]]
    except Exception:
        return []


def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def account_snapshot_from_broker() -> Dict[str, Any]:
    try:
        broker = BinanceBroker()
        snap = broker.get_account_snapshot() or {}
        equity = snap.get("um_equity", 0) or snap.get("wallet_balance", 0)
        balance = snap.get("spot_usdt", 0) + (snap.get("um_available", 0) or 0)
        return {
            "balance": round(balance, 2),
            "equity": round(equity, 2),
            "drawdown": 0.0,
            "active_positions": snap.get("positions", 0),
            "source": "broker",
        }
    except Exception:
        return {}


def account_snapshot_from_storage() -> Dict[str, Any]:
    state = load_json(STORAGE / "system_state.json", {}) or {}
    equity = state.get("equity", 0) or state.get("balance", 0)
    drawdown = state.get("max_drawdown_pct")
    return {
        "balance": round(state.get("balance", equity), 2),
        "equity": round(equity, 2),
        "drawdown": round(drawdown / 100, 4) if isinstance(drawdown, (int, float)) else 0.0,
        "active_positions": state.get("positions", 0),
        "source": "storage",
    }


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.get("/api/decisions")
async def get_decisions():
    return load_jsonl(STORAGE / "decisions.jsonl")


@app.get("/api/trades/real")
async def get_real_trades():
    return load_jsonl(STORAGE / "trades_real.jsonl")


@app.get("/api/trades/shadow")
async def get_shadow_trades():
    return load_jsonl(STORAGE / "trades_shadow.jsonl")


@app.get("/api/account")
async def get_account():
    # 1) try live broker snapshot; fallback to storage; else zeros
    snap = account_snapshot_from_broker()
    if not snap:
        snap = account_snapshot_from_storage()
    if not snap:
        snap = {
            "balance": 0.0,
            "equity": 0.0,
            "drawdown": 0.0,
            "active_positions": 0,
            "source": "empty",
        }
    return snap


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
