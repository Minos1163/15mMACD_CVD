# 📦 项目交付清单（无 Docker / Ubuntu 24.04 直跑）

**交付日期**: 2026-01-14  
**项目名称**: AI-DCA 自我修正交易系统  
**交付状态**: ✅ 已交付（Docker 已移除，建议 Ubuntu 24.04 + systemd 7×24）

---

## ✅ 交付物清单

### 文档（你/运维人员会直接用到）

- [x] `README.md`：项目概览、Ubuntu 直跑方式、常用入口
- [x] `INDEX.md`：文档索引（主入口）
- [x] `IMPLEMENTATION_GUIDE.md`：实现与使用指南（已按“无 Docker”更新）
- [x] `DCA_STRATEGY_GUIDE.md`：DCA 策略解释 + 多币种参数分工（AI vs 用户）
- [x] `docs/SYSTEM_PLAYBOOK.md`：按 `TODO.txt` 结构整理的系统 Playbook（Regime/Explainable/进化/Meta-Risk 等）

### 配置与参数

- [x] `Parameter.txt`：多币种 DCA 参数（已标注 `[USER]/[AI]/[HYBRID]`）
- [x] `config/execution.yaml`：执行相关配置
- [x] `.env`：运行所需环境变量（API Key 等；注意不要提交到公开仓库）

### 核心代码模块

- [x] `strategy/`：`dca_engine.py`、`rotation_engine.py`
- [x] `execution/`：`executor.py`
- [x] `risk/`：`kill_switch.py`、`anomaly_detector.py`
- [x] `shadow/`：`shadow_account.py`
- [x] `ai/`：`deepseek_client.py`、`prompt_builder.py`、`ai/prompts/*`
- [x] `replay/`：`replay_engine.py`、`backtest_scorer.py`、`correction_engine.py`
- [x] `dashboard/`：`backend/app.py` + `frontend/*`（远程监控与参数入口的基础骨架）

### 测试与报告产物（可选但建议保留）

- [x] `test_*.py`：系统集成、执行器、轮动、风控、AI 评估等
- [x] `storage/*.json`、`*.jsonl`：运行/测试生成的状态与报告（可清理，但建议保留最近一份）
- [x] `*_REPORT.md`：回测/执行/集成测试等报告

---

## 🧹 Docker 清理结果（按要求）

- [x] 已删除 `docker/` 目录及其文件（`Dockerfile`、`docker-compose.yml`、`supervisor.conf`、`health_check.py`）
- [x] 文档主线已切换为 **Ubuntu 24.04 直跑（无 Docker）**

---

## 🚀 Ubuntu 24.04 7×24 部署验收清单（推荐 systemd）

### 1) 运行前检查

- [ ] 服务器时间/时区正确（建议 UTC 或固定到 JST）
- [ ] Python 环境可用（建议 venv，Python 3.10+）
- [ ] `.env` 已配置（至少：`BINANCE_API_KEY`、`BINANCE_SECRET`、`DEEPSEEK_API_KEY`）
- [ ] Binance Key 权限最小化（禁用提币权限；只保留必要交易权限）

### 2) 启动与健康检查

- [ ] `python main.py` 能启动并持续运行
- [ ] `dashboard/backend/app.py`（或 uvicorn）能启动并访问
- [ ] `storage/` 能正常写入（决策日志、状态、报告）
- [ ] Kill Switch 可触发并阻止交易

### 3) systemd（建议项）

- [ ] 配置 `ai-dca.service`（WorkingDirectory 指向 `/root/git/ai-dca-system`）
- [ ] 设置自动重启（`Restart=always` / `on-failure`）
- [ ] 配置日志输出到 journald 或文件

---

## ✅ 验收标准（建议你签收用）

- [x] Docker 目录不存在（确认项目已完全切换为 Ubuntu 直跑）
- [x] `INDEX.md` 指向的文档都能打开，且部署章节不再提 Docker（已全局检索清除 Docker 部署指令）
- [ ] 至少跑通一次：
  - [ ] `test_system_integration.py`
  - [ ] `test_risk_controls.py`
  - [ ] `test_rotation_strategy.py`
- [ ] Shadow Mode 可运行（无实盘风险）
- [ ] 当 `.env` 缺失/Key 缺失时，系统能给出明确报错并退出（避免“静默失败”）

---

## 🔒 安全与运维注意

- 不要把 `.env`、`storage/` 中的敏感内容上传到公开仓库
- Dashboard 对外网暴露时必须加：
  - 访问鉴权（token/basic auth）
  - IP 白名单
  - HTTPS（反向代理）

---

## 📌 备注

- 本清单以“交付可运行”为目标：**先稳定 7×24，再逐步上线 TODO.txt 中的进化/联合进化/Meta-Risk 等增强模块**。
