#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick 3-day / 15m backtest to probe AI decision reliability & effectiveness.
- Uses Binance public klines (15m) for BTC/ETH/BNB by default.
- Simulates leveraged exposure with margin accounting (50x default).
- Capital: 1000 USDT, deploy up to 80% notional (position_pct) under leverage.
- AI: uses DeepSeek (ask) when DEEPSEEK_API_KEY is present; otherwise falls back to mock.

Outputs: console summary + JSON report in storage/backtest_15m_report.json
"""
import os
import json
import math
import statistics
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple
import requests

from ai.deepseek_client import DeepSeekClient

TRADING_SYMBOLS = [s.strip() for s in os.getenv("BACKTEST_SYMBOLS", "BTCUSDT,ETHUSDT,BNBUSDT").split(",") if s.strip()]
INTERVAL = os.getenv("BACKTEST_INTERVAL", "15m")
DAYS = int(os.getenv("BACKTEST_DAYS", "3"))
# 市场选择：um=U本位合约（默认），spot=现货
MARKET = os.getenv("BACKTEST_MARKET", "um").lower()
REQUIRE_REAL_AI = os.getenv("BACKTEST_REQUIRE_REAL_AI", "1").lower() in {"1", "true", "yes", "y"}
INITIAL_EQUITY = float(os.getenv("BACKTEST_EQUITY", "1000"))
# 默认更保守：40% 可用（可通过 BACKTEST_POSITION_PCT 覆盖）
POSITION_PCT = float(os.getenv("BACKTEST_POSITION_PCT", "0.9"))  # deployable fraction of equity
LEVERAGE = float(os.getenv("BACKTEST_LEVERAGE", "50"))
BAR_COUNT = DAYS * 24 * (60 // 15)  # 3 days * 96 = 288 bars
BASE_INVESTMENT = float(
    os.getenv(
        "BACKTEST_BASE_INVESTMENT",
        f"{round(INITIAL_EQUITY * POSITION_PCT * 0.04, 2)}"  # 4% of deployable equity（收益优先）
    )
)
# 风控/止盈参数（可通过环境变量覆盖）
TP1 = float(os.getenv("BACKTEST_TP1", "0.04"))      # 首次止盈 4.0%
TP2 = float(os.getenv("BACKTEST_TP2", "0.15"))      # 二次止盈 15.0%
SL = float(os.getenv("BACKTEST_SL", "-0.03"))       # 止损 -3.0%
TP1_CLOSE = float(os.getenv("BACKTEST_TP1_CLOSE", "0.2"))  # TP1 先落袋 20%
TP2_CLOSE = float(os.getenv("BACKTEST_TP2_CLOSE", "1.0"))  # TP2 平剩余全部
TRAIL_STOP = float(os.getenv("BACKTEST_TRAIL_STOP", "0.03"))   # TP1 触发后回撤 3% 触发移动止盈
NEG_MOM_TRIM = float(os.getenv("BACKTEST_NEG_MOM_TRIM", "0.5"))  # 负动量时仅减仓比例
VOL_HOLD = float(os.getenv("BACKTEST_VOL_HOLD", "0.05"))  # 波动率超阈值强制观望
COOLDOWN_BARS = int(os.getenv("BACKTEST_COOLDOWN_BARS", "6"))   # 单标的建仓/平仓后冷却期
MIN_CONF = float(os.getenv("BACKTEST_MIN_CONF", "0.45"))       # 买入最小置信度
SHORT_MOM_LOOKBACK = int(os.getenv("BACKTEST_SHORT_MOM_BARS", "24"))  # 6h 动量（24*15m）
MOM_24H_MIN = float(os.getenv("BACKTEST_MOM_24H_MIN", "0.0"))          # 24h 动量阈值（%）
MA_SHORT = int(os.getenv("BACKTEST_MA_SHORT", "6"))                    # 短均线窗口
MAX_POSITIONS = int(os.getenv("BACKTEST_MAX_POSITIONS", "3"))          # 同时持仓上限（保留高分）
MA_LONG = int(os.getenv("BACKTEST_MA_LONG", "0"))                      # 长均线窗口（0=关闭，仅用 MA20）
REPORT_PATH = Path(__file__).parents[1] / "storage" / "backtest_15m_report.json"
REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)

def load_dotenv_simple(env_path: Path) -> None:
    if not env_path.exists():
        return
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip("\"")
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception:
        pass

def fetch_klines(symbol: str, interval: str, limit: int) -> List[Dict]:
    if MARKET == "um":
        url = "https://fapi.binance.com/fapi/v1/klines"
    else:
        url = "https://api.binance.com/api/v3/klines"
    r = requests.get(url, params={"symbol": symbol, "interval": interval, "limit": limit}, timeout=15)
    r.raise_for_status()
    data = []
    for k in r.json():
        data.append(
            {
                "open_time": int(k[0]) // 1000,
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
            }
        )
    return data

def momentum(closes: List[float], lookback: int, idx: int) -> float:
    if idx < lookback:
        return 0.0
    prev = closes[idx - lookback]
    if prev == 0:
        return 0.0
    return (closes[idx] - prev) / prev * 100.0

def realized_vol(closes: List[float], window: int, idx: int) -> float:
    start = max(0, idx - window + 1)
    window_closes = closes[start : idx + 1]
    if len(window_closes) < 2:
        return 0.0
    return statistics.pstdev(window_closes) / (statistics.mean(window_closes) or 1.0)

def max_drawdown(equity_curve: List[float]) -> float:
    peak = equity_curve[0]
    mdd = 0.0
    for v in equity_curve:
        peak = max(peak, v)
        mdd = max(mdd, (peak - v) / peak * 100 if peak else 0.0)
    return mdd

def main():
    print("=" * 80)
    print("🔁 15m / 3-day Backtest (AI Reliability Probe)")
    print("=" * 80)
    print(f"Symbols: {', '.join(TRADING_SYMBOLS)} | Interval: {INTERVAL} | Bars: {BAR_COUNT} | Market: {MARKET}")
    print(f"Equity: {INITIAL_EQUITY} USDT | Deployable: {POSITION_PCT*100:.0f}% | Leverage: {LEVERAGE}x")
    print(f"Base investment per signal: {BASE_INVESTMENT} USDT (pre-leverage margin ~{BASE_INVESTMENT/LEVERAGE:.2f})")
    print(f"Max positions: {MAX_POSITIONS}")

    load_dotenv_simple(Path(__file__).parents[1] / ".env")
    deepseek = DeepSeekClient()
    if REQUIRE_REAL_AI and not deepseek.api_key:
        print("❌ Missing DEEPSEEK_API_KEY while REQUIRE_REAL_AI is enabled. Aborting.")
        return

    # 1) Pull klines
    klines: Dict[str, List[Dict]] = {}
    closes: Dict[str, List[float]] = {}
    active_symbols: List[str] = []
    for sym in TRADING_SYMBOLS:
        print(f"⬇️  Fetching {sym} klines ...", end=" ")
        try:
            data = fetch_klines(sym, INTERVAL, BAR_COUNT + 5)
        except Exception as e1:
            print(f"failed ({e1}); retrying once ...", end=" ")
            try:
                data = fetch_klines(sym, INTERVAL, BAR_COUNT + 5)
            except Exception as e2:
                print(f"failed again ({e2}); skipping.")
                continue
        klines[sym] = data
        closes[sym] = [c["close"] for c in data]
        active_symbols.append(sym)
        print(f"{len(data)} bars")

    if not active_symbols:
        print("❌ No symbols fetched successfully; aborting backtest.")
        return

    bars_available = min(len(v) for v in klines.values())
    if bars_available < BAR_COUNT:
        print(f"⚠️ Only {bars_available} bars available; limiting run to that length.")
    steps = min(BAR_COUNT, bars_available)

    cash = INITIAL_EQUITY
    positions: Dict[str, Dict[str, float]] = {}  # symbol -> {qty, cost, margin, tp1_hit}
    equity_curve: List[float] = []
    trades: List[Dict] = []
    ai_actions: List[str] = []
    ai_align_hits = 0
    ai_align_total = 0
    realized_pnl = 0.0
    last_buy_idx: Dict[str, int] = {}

    for idx in range(steps):
        price_map = {sym: klines[sym][idx]["close"] for sym in active_symbols}

        # mark-to-market equity
        equity = cash
        for sym, pos in positions.items():
            price = price_map[sym]
            equity += pos["margin"]
            equity += (price - pos["cost"]) * pos["qty"]
        equity_curve.append(equity)

        for sym in active_symbols:
            price = price_map[sym]
            mom_24h = momentum(closes[sym], lookback=96, idx=idx)  # 96 * 15m = 1 day
            mom_6h = momentum(closes[sym], lookback=SHORT_MOM_LOOKBACK, idx=idx)
            vol = realized_vol(closes[sym], window=48, idx=idx)  # ~12h window
            negative_mom = mom_24h < 0
            ma_short = 0.0
            ma_long = 0.0
            if idx + 1 >= MA_SHORT:
                window_closes = closes[sym][idx - MA_SHORT + 1 : idx + 1]
                ma_short = sum(window_closes) / len(window_closes)
            if MA_LONG > 0 and idx + 1 >= MA_LONG:
                window_closes = closes[sym][idx - MA_LONG + 1 : idx + 1]
                ma_long = sum(window_closes) / len(window_closes)

            # 先做风控：止盈/止损/分批
            if sym in positions:
                pos = positions[sym]
                pos["trail_peak"] = max(pos.get("trail_peak", pos["cost"]), price)
                pnl_pct = (price - pos["cost"]) / pos["cost"] if pos["cost"] else 0

                # TP1 之后启动移动止盈，防止回吐
                if pos.get("tp1_hit") and price <= pos["trail_peak"] * (1 - TRAIL_STOP):
                    qty = pos["qty"]
                    margin_released = pos["margin"]
                    pnl = (price - pos["cost"]) * qty
                    realized_pnl += pnl
                    cash += margin_released + pnl
                    trades.append({
                        "ts": klines[sym][idx]["open_time"],
                        "symbol": sym,
                        "side": "TRAIL_STOP",
                        "price": price,
                        "qty": qty,
                        "margin_released": margin_released,
                        "pnl": pnl,
                        "pnl_pct": pnl_pct,
                    })
                    positions.pop(sym, None)
                    continue
                # 止损
                if pnl_pct <= SL:
                    qty = pos["qty"]
                    margin_released = pos["margin"]
                    pnl = (price - pos["cost"]) * qty
                    realized_pnl += pnl
                    cash += margin_released + pnl
                    trades.append({
                        "ts": klines[sym][idx]["open_time"],
                        "symbol": sym,
                        "side": "STOP_LOSS",
                        "price": price,
                        "qty": qty,
                        "margin_released": margin_released,
                        "pnl": pnl,
                        "pnl_pct": pnl_pct,
                    })
                    positions.pop(sym, None)
                    continue

                # 首次止盈部分减仓
                if pnl_pct >= TP1 and not pos.get("tp1_hit"):
                    close_qty = pos["qty"] * TP1_CLOSE
                    margin_share = pos["margin"] * TP1_CLOSE
                    pnl = (price - pos["cost"]) * close_qty
                    realized_pnl += pnl
                    cash += margin_share + pnl
                    pos["qty"] -= close_qty
                    pos["margin"] -= margin_share
                    pos["trail_peak"] = price
                    trades.append({
                        "ts": klines[sym][idx]["open_time"],
                        "symbol": sym,
                        "side": "TAKE_PROFIT_1",
                        "price": price,
                        "qty": close_qty,
                        "margin_released": margin_share,
                        "pnl": pnl,
                        "pnl_pct": pnl_pct,
                    })
                    pos["tp1_hit"] = True
                    if pos["qty"] <= 0:
                        positions.pop(sym, None)
                        continue

                # 二次止盈全部平仓
                if pnl_pct >= TP2:
                    close_qty = positions[sym]["qty"]
                    margin_released = positions[sym]["margin"]
                    pnl = (price - positions[sym]["cost"]) * close_qty
                    realized_pnl += pnl
                    cash += margin_released + pnl
                    trades.append({
                        "ts": klines[sym][idx]["open_time"],
                        "symbol": sym,
                        "side": "TAKE_PROFIT_2",
                        "price": price,
                        "qty": close_qty,
                        "margin_released": margin_released,
                        "pnl": pnl,
                        "pnl_pct": pnl_pct,
                    })
                    positions.pop(sym, None)
                    continue

            # DeepSeek 决策（有 key 时 ask，失败则 mock）
            prompt = f"""
你是量化交易顾问，请给出 {sym} 在 15m 周期下的操作建议，必须从 BUY/SELL/HOLD 中选择。
硬约束：
1) 若 24h 动量为负且当前有多头持仓，优先 SELL 做减仓（可部分减仓）；
2) 若 confidence < 0.6 强制 HOLD；
3) 若波动率高于 {VOL_HOLD:.2f} 强制 HOLD；
4) 避免过度加仓，倾向轻仓或空仓；
5) 牛市优先持仓，让利润多跑，止盈可延后。

输出 JSON 字段: action(BUY/SELL/HOLD), confidence(0-1), reason。

上下文：
- 现价: {price:.2f}
- 24h 动量: {mom_24h:+.2f}%
- 12h 波动率: {vol:.4f}
- 当前持仓: {positions.get(sym, {}).get('qty', 0):.6f} @ {positions.get(sym, {}).get('cost', 0):.2f}
- 杠杆: {LEVERAGE}x
- 可用保证金: {cash:.2f} USDT
"""

            ai = {}
            for attempt in range(3):
                ai = deepseek.ask(prompt, system_prompt="你是严格输出 JSON 的量化交易顾问", temperature=0.1, force_json=False)
                if not ai.get("error"):
                    break
                if REQUIRE_REAL_AI:
                    time.sleep(1 + attempt)
            if REQUIRE_REAL_AI and ai.get("error"):
                raise RuntimeError(f"DeepSeek error for {sym}: {ai.get('error')}")

            action = str(ai.get("action", "HOLD")).upper()
            confidence = float(ai.get("confidence", 0)) if isinstance(ai.get("confidence", 0), (int, float)) else 0.0
            # 硬约束修正
            if vol > VOL_HOLD:
                action = "HOLD"
            if confidence < MIN_CONF:
                action = "HOLD"
            # 避免逆势抄底：24h 动量不正时不新开多
            if negative_mom and sym not in positions:
                action = "HOLD"
            if negative_mom and sym in positions and positions[sym]["qty"] > 0:
                action = "SELL"
            # 双动量 + 均线过滤（仅用于开新仓）
            if sym not in positions:
                if mom_24h <= MOM_24H_MIN or mom_6h <= 0:
                    action = "HOLD"
                if ma_short and price <= ma_short:
                    action = "HOLD"
                # 冷却期限制
                last_idx = last_buy_idx.get(sym, -10**9)
                if idx - last_idx < COOLDOWN_BARS:
                    action = "HOLD"

            ai_actions.append(action)
            ai_align_total += 1
            if (mom_24h > 0 and action == "BUY") or (mom_24h < 0 and action == "SELL"):
                ai_align_hits += 1

            max_notional = INITIAL_EQUITY * POSITION_PCT * LEVERAGE
            current_notional = sum(pos["qty"] * price_map[s] for s, pos in positions.items())

            score = confidence * 100 + max(0.0, mom_24h) + max(0.0, mom_6h)
            if action == "BUY" and confidence >= MIN_CONF and sym not in positions:
                margin_available = cash
                trend_factor = min(2.0, 1 + max(0.0, mom_24h) / 50)  # 趋势向上时放大下单额度，最高翻倍
                budget_notional = min(BASE_INVESTMENT * trend_factor, max_notional - current_notional)
                if budget_notional <= 0:
                    continue
                if len(positions) >= MAX_POSITIONS:
                    lowest_sym, lowest_pos = min(positions.items(), key=lambda kv: kv[1].get("score", 0))
                    if score <= lowest_pos.get("score", 0):
                        continue
                    lowest_price = price_map[lowest_sym]
                    qty = lowest_pos["qty"]
                    margin_released = lowest_pos["margin"]
                    pnl = (lowest_price - lowest_pos["cost"]) * qty
                    realized_pnl += pnl
                    cash += margin_released + pnl
                    trades.append({
                        "ts": klines[lowest_sym][idx]["open_time"],
                        "symbol": lowest_sym,
                        "side": "ROTATE_OUT",
                        "price": lowest_price,
                        "qty": qty,
                        "margin_released": margin_released,
                        "pnl": pnl,
                        "reason": "rotate_to_higher_score",
                    })
                    positions.pop(lowest_sym, None)
                margin_needed = budget_notional / LEVERAGE
                if margin_needed > margin_available:
                    continue
                qty = budget_notional / price if price > 0 else 0
                if qty <= 0:
                    continue
                cash -= margin_needed
                positions[sym] = {"qty": qty, "cost": price, "margin": margin_needed, "tp1_hit": False, "trail_peak": price, "score": score}
                last_buy_idx[sym] = idx
                trades.append({
                    "ts": klines[sym][idx]["open_time"],
                    "symbol": sym,
                    "side": "BUY",
                    "price": price,
                    "qty": qty,
                    "margin": margin_needed,
                    "notional": budget_notional,
                    "confidence": confidence,
                    "reason": ai.get("reason", ""),
                })

            elif action == "SELL" and sym in positions and positions[sym]["qty"] > 0:
                pos = positions[sym]
                if negative_mom and NEG_MOM_TRIM < 1.0:
                    close_qty = pos["qty"] * NEG_MOM_TRIM
                    margin_released = pos["margin"] * NEG_MOM_TRIM
                    pnl = (price - pos["cost"]) * close_qty
                    realized_pnl += pnl
                    cash += margin_released + pnl
                    remaining_qty = pos["qty"] - close_qty
                    remaining_margin = pos["margin"] - margin_released
                    trades.append({
                        "ts": klines[sym][idx]["open_time"],
                        "symbol": sym,
                        "side": "SELL_TRIM",
                        "price": price,
                        "qty": close_qty,
                        "margin_released": margin_released,
                        "pnl": pnl,
                        "reason": ai.get("reason", ""),
                        "confidence": confidence,
                    })
                    if remaining_qty <= 0:
                        positions.pop(sym, None)
                    else:
                        positions[sym]["qty"] = remaining_qty
                        positions[sym]["margin"] = remaining_margin
                    continue

                qty = pos["qty"]
                margin_released = pos["margin"]
                pnl = (price - pos["cost"]) * qty
                realized_pnl += pnl
                cash += margin_released + pnl
                positions.pop(sym, None)
                trades.append({
                    "ts": klines[sym][idx]["open_time"],
                    "symbol": sym,
                    "side": "SELL",
                    "price": price,
                    "qty": qty,
                    "margin_released": margin_released,
                    "pnl": pnl,
                    "reason": ai.get("reason", ""),
                    "confidence": confidence,
                })

    # Final MTM
    final_price_map = {sym: klines[sym][steps - 1]["close"] for sym in active_symbols}
    equity = cash
    open_pnls = {}
    for sym, pos in positions.items():
        price = final_price_map[sym]
        unrealized = (price - pos["cost"]) * pos["qty"]
        equity += pos["margin"] + unrealized
        open_pnls[sym] = unrealized
    equity_curve.append(equity)

    total_return_pct = (equity / INITIAL_EQUITY - 1) * 100
    mdd = max_drawdown(equity_curve)

    realized_trades = [t for t in trades if t.get("pnl") is not None and t.get("side") in {"SELL", "TAKE_PROFIT_1", "TAKE_PROFIT_2", "STOP_LOSS"}]
    wins = sum(1 for t in realized_trades if t.get("pnl", 0) > 0)
    losses = sum(1 for t in realized_trades if t.get("pnl", 0) < 0)
    win_rate = (wins / len(realized_trades) * 100) if realized_trades else 0

    ai_align_ratio = (ai_align_hits / ai_align_total * 100) if ai_align_total else 0

    summary = {
        "params": {
            "days": DAYS,
            "interval": INTERVAL,
            "market": MARKET,
            "bar_count": steps,
            "initial_equity": INITIAL_EQUITY,
            "deployable_pct": POSITION_PCT,
            "leverage": LEVERAGE,
            "base_investment": BASE_INVESTMENT,
            "max_positions": MAX_POSITIONS,
        },
        "results": {
            "final_equity": round(equity, 2),
            "total_return_pct": round(total_return_pct, 2),
            "max_drawdown_pct": round(mdd, 2),
            "open_positions": {sym: {"qty": pos["qty"], "cost": pos["cost"], "margin": pos["margin"], "unrealized": open_pnls.get(sym, 0)} for sym, pos in positions.items()},
            "trade_count": len(trades),
            "closed_trades": len(realized_trades),
            "win_rate_pct": round(win_rate, 2),
            "realized_pnl": round(realized_pnl, 2),
        },
        "ai_reliability": {
            "action_counts": {a: ai_actions.count(a) for a in set(ai_actions)},
            "trend_alignment_pct": round(ai_align_ratio, 2),
        },
        "generated_at": datetime.now().isoformat(),
    }

    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\n" + "-" * 80)
    print("🏁 Backtest done")
    print(f"Final equity: {summary['results']['final_equity']:.2f} USDT | Return: {summary['results']['total_return_pct']:+.2f}%")
    print(f"Max drawdown: {summary['results']['max_drawdown_pct']:.2f}% | Win rate: {summary['results']['win_rate_pct']:.2f}%")
    print(f"AI trend-alignment: {summary['ai_reliability']['trend_alignment_pct']:.2f}%")
    print(f"Report saved to: {REPORT_PATH}")

if __name__ == "__main__":
    main()
