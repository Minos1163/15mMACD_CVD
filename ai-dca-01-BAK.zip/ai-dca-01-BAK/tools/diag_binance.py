from broker.binance_broker import BinanceBroker

b = BinanceBroker()
print('HAS get_klines ->', hasattr(b, 'get_klines'))
print('Dir klines matches:', [name for name in dir(b) if 'klines' in name.lower()])
print('Methods containing get_:', [name for name in dir(b) if name.startswith('get_')])
print('\nSample call attributes:')
for n in dir(b):
    if n.startswith('get_'):
        print(' -', n)
