import json
import sys
from pathlib import Path
from datetime import datetime

# ensure repo root is on sys.path so local packages can be imported when script run directly
sys.path.insert(0, str(Path(__file__).parents[1]))
from replay.backtest_scorer import BacktestScorer

LOG = Path(__file__).parents[1] / 'storage' / 'shadow_dca_log.jsonl'
REPORT = Path(__file__).parents[1] / 'SHADOW_MODE_TEST_REPORT.md'

# Load trades
trades = []
with open(LOG, 'r', encoding='utf-8') as f:
    for line in f:
        trades.append(json.loads(line))

# Sort trades by timestamp
for t in trades:
    # ensure timestamp -> unix
    try:
        dt = datetime.fromisoformat(t['timestamp'])
    except Exception:
        dt = datetime.strptime(t['timestamp'], '%Y-%m-%dT%H:%M:%S')
    t['_ts'] = int(dt.timestamp())

trades.sort(key=lambda x: x['_ts'])

# Reconstruct daily portfolio values
initial_capital = 1000.0
cash = initial_capital
positions = {}

daily_points = []  # list of (ts, total_value)
current_day = None
last_total = initial_capital

# Group trades by day (date)
from collections import defaultdict
trades_by_day = defaultdict(list)
for t in trades:
    day = datetime.fromtimestamp(t['_ts']).date()
    trades_by_day[day].append(t)

sorted_days = sorted(trades_by_day.keys())
for day in sorted_days:
    day_trades = trades_by_day[day]
    # process trades sequentially
    for tr in day_trades:
        amount = float(tr.get('amount', 0))
        fee = float(tr.get('fee', 0))
        qty = float(tr.get('quantity', 0))
        sym = tr.get('symbol')
        action = tr.get('action')
        if action == 'BUY':
            cash -= (amount + fee)
            positions[sym] = positions.get(sym, 0) + qty
        elif action == 'SELL':
            cash += (amount - fee)
            positions[sym] = positions.get(sym, 0) - qty
    # estimate portfolio value using last trade prices of the day
    total_value = cash
    # determine last price per symbol for that day
    last_price = {}
    for tr in day_trades:
        last_price[tr['symbol']] = float(tr['price'])
    for sym, qty in positions.items():
        price = last_price.get(sym, 0)
        total_value += qty * price
    # use timestamp of last trade
    ts = day_trades[-1]['_ts']
    daily_points.append({'timestamp': ts, 'total_value': total_value})

# create pnl entries per day
pnl_entries = []
prev = initial_capital
for pt in daily_points:
    pnl = pt['total_value'] - prev
    pnl_entries.append({'timestamp': pt['timestamp'], 'pnl': pnl})
    prev = pt['total_value']

final_capital = daily_points[-1]['total_value'] if daily_points else initial_capital

# use BacktestScorer
scorer = BacktestScorer()
result = scorer.create_backtest_result(
    strategy_name='Shadow DCA',
    model_version='v1',
    parameters={'base_investment': 50, 'period': 'DAILY'},
    start_date=str(sorted_days[0]) if sorted_days else '',
    end_date=str(sorted_days[-1]) if sorted_days else '',
    remarks='Computed from shadow_dca_log.jsonl'
)

# convert pnl_entries to trades format expected by scorer (with timestamp and pnl)
metrics = scorer.calculate_metrics(result, initial_capital, final_capital, pnl_entries)

# write metrics JSON and append markdown to report
out_json = Path(__file__).parents[1] / 'storage' / 'backtest_metrics.json'
with open(out_json, 'w', encoding='utf-8') as f:
    json.dump({'metrics': metrics.__dict__}, f, indent=2, ensure_ascii=False)

md = '\n\n**回测性能指标（自动计算）**\n\n'
md += '| 指标 | 值 |\n|---|---:|\n'
md += f"| 总收益率 (％) | {metrics.total_return_pct} |\n"
md += f"| 年化收益率 (％) | {metrics.annualized_return_pct} |\n"
md += f"| Sharpe 比 | {metrics.sharpe_ratio} |\n"
md += f"| Sortino 比 | {metrics.sortino_ratio} |\n"
md += f"| 最大回撤 (％) | {metrics.max_drawdown_pct} |\n"
md += f"| 胜率 (％) | {metrics.win_rate_pct} |\n"
md += f"| 盈利因子 | {metrics.profit_factor} |\n"
md += f"| 交易次数 | {metrics.num_trades} |\n"
md += f"| 赢利交易数 | {metrics.num_winning_trades} |\n"
md += f"| 亏损交易数 | {metrics.num_losing_trades} |\n"

with open(REPORT, 'a', encoding='utf-8') as f:
    f.write(md)

print('Metrics written to', out_json)
print('Appended metrics to', REPORT)
print('\nSummary:')
print(json.dumps(metrics.__dict__, indent=2, ensure_ascii=False))
