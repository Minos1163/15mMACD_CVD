#!/usr/bin/env python3
import sys
sys.path.insert(0, '.')
from replay.correction_engine import SelfCorrectionEngine
from pathlib import Path

prompt_dir = Path(__file__).parent / "ai" / "prompts"
config_dir = Path(__file__).parent / "config"

corrector = SelfCorrectionEngine(
    prompt_dir=str(prompt_dir),
    config_dir=str(config_dir)
)

# 模拟回测结果
backtest_results = {
    "trader": {"win_rate": 35},
    "risk": {"max_drawdown": 25}
}

try:
    suggestions = corrector.suggest_prompt_modifications(backtest_results)
    print(f"建议: {suggestions}")
except Exception as e:
    print(f"错误: {e}")
    import traceback
    traceback.print_exc()