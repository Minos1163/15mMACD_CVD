#!/usr/bin/env python3
"""
在 Shadow Mode 运行 DCA 定投测试
模拟真实交易流程，无实际资金风险
"""

import sys
import os
import json
import time
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env 文件
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

print("=" * 80)
print("🚀 Shadow Mode DCA 定投测试")
print("=" * 80)

# ========== 环境检查 ==========
print("\n📋 环境初始化")
print("-" * 80)

api_key = os.getenv("BINANCE_API_KEY")
api_secret = os.getenv("BINANCE_SECRET")
deepseek_key = os.getenv("DEEPSEEK_API_KEY")

if not all([api_key, api_secret, deepseek_key]):
    print("❌ 错误: 缺少必要的 API 密钥")
    sys.exit(1)

print("✅ API 密钥已配置")

# 导入必要的模块
from broker.binance_broker import BinanceBroker
from shadow.shadow_account import ShadowAccount
from strategy.dca_engine import DCAEngine, DCAPeriod
from ai.deepseek_client import DeepSeekClient
from execution.executor import ExecutionEngine, OrderSide, OrderType
import requests
import random

# ========== 初始化组件 ==========
print("\n🔧 组件初始化")
print("-" * 80)

try:
    # 初始化 Broker（确保传入 str，避免 Pylance 报错）
    broker = BinanceBroker(api_key=api_key or "", api_secret=api_secret or "")
    print(f"✅ Broker 已初始化 (模式: {broker.mode.value})")

    # 初始化影子账户 (1000 USDT 初始余额)
    shadow = ShadowAccount(equity=1000.0)
    print(f"✅ Shadow 账户已初始化 (初始余额: {shadow.equity:.2f} USDT)")

    # 初始化 DCA 引擎
    dca = DCAEngine(base_investment=50, period=DCAPeriod.DAILY)  # 每日投入 50 USDT
    print(f"✅ DCA 引擎已初始化 (每日投入: 50 USDT)")

    # 初始化执行器
    executor = ExecutionEngine()
    print(f"✅ 执行器已初始化")

    # 初始化 DeepSeek 客户端
    deepseek = DeepSeekClient(api_key=deepseek_key)
    print(f"✅ DeepSeek 客户端已初始化")

except Exception as e:
    print(f"❌ 初始化失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# ========== 模拟市场数据 ==========
print("\n" + "=" * 80)
print("📊 模拟市场数据和交易")
print("=" * 80)

# 选择定投的币种
trading_symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

# 模拟价格数据 (开始价格)
base_prices = {
    "BTCUSDT": 42000,
    "ETHUSDT": 2500,
    "BNBUSDT": 600
}

print(f"\n📌 定投币种: {', '.join(trading_symbols)}")
print(f"📌 初始价格:")
for symbol in trading_symbols:
    print(f"   {symbol}: ${base_prices[symbol]:,.2f}")

# ========== 准备历史数据与模拟时间 ==========
print("\n获取历史日线价格（最多10条）...")
historical_prices = {}
for symbol in trading_symbols:
    try:
        r = requests.get(
            "https://api.binance.com/api/v3/klines",
            params={"symbol": symbol, "interval": "1d", "limit": 10},
            timeout=10,
        )
        r.raise_for_status()
        klines = r.json()
        closes = [float(k[4]) for k in klines]
        if len(closes) >= 10:
            historical_prices[symbol] = closes
        else:
            raise ValueError("不足10条K线")
        print(f"  ✅ {symbol}: 获取 {len(closes)} 条日线")
    except Exception:
        historical_prices[symbol] = [base_prices[symbol]] * 10
        print(f"  ⚠️ {symbol}: 获取历史K线失败，使用基准价格回退")

# 使用模拟时间（按天推进）
sim_start = int(time.time())

# ========== 模拟 DCA 定投周期 ==========
print("\n" + "=" * 80)
print("🔄 模拟 10 天的 DCA 定投过程")
print("=" * 80)

trading_log = []
current_balance = shadow.equity
current_prices = {}

for day in range(1, 11):
    current_time_for_day = sim_start + (day - 1) * 86400
    print(f"\n📅 第 {day} 天")
    print("-" * 60)

    # 取历史价格（按日索引），如果没有则随机小幅波动
    current_prices = {}
    for symbol in trading_symbols:
        try:
            current_price = historical_prices[symbol][day - 1]
            change_pct = (current_price - base_prices[symbol]) / base_prices[symbol]
        except Exception:
            change_pct = random.uniform(-0.05, 0.05)
            current_price = base_prices[symbol] * (1 + change_pct)
        current_prices[symbol] = current_price
        print(f"   {symbol}: ${current_price:,.2f} (变化: {change_pct*100:+.1f}%)")

    # 对每个币种执行 DCA（使用模拟时间）
    for symbol in trading_symbols:
        current_price = current_prices[symbol]

        # 检查是否应该买入（使用模拟时间）
        if dca.should_dca_buy(symbol, current_time_for_day):
            # 计算投入金额
            amount, quantity = dca.calculate_dca_amount(
                symbol=symbol,
                current_price=current_price,
                account_balance=current_balance,
                volatility=random.uniform(0.01, 0.03),
            )

            if amount > 0 and current_balance >= amount:
                # 创建订单
                order = executor.create_order(
                    symbol=symbol,
                    side=OrderSide.BUY,
                    quantity=quantity,
                    price=current_price,
                    order_type=OrderType.MARKET,
                    remarks=f"DCA #{day}",
                )

                # 提交并成交
                executor.submit_order(order.order_id)
                executor.fill_order(
                    order_id=order.order_id,
                    filled_quantity=quantity,
                    filled_price=current_price,
                    fee=amount * 0.001,
                )

                # 更新影子账户与余额
                shadow.buy(symbol, quantity, current_price)
                current_balance -= (amount + amount * 0.001)

                # 更新 DCA 头寸（使用模拟时间）
                dca.update_position(symbol, amount, current_price, current_time_for_day)

                # 记录交易（使用模拟时间戳）
                trading_log.append({
                    "day": day,
                    "symbol": symbol,
                    "action": "BUY",
                    "quantity": quantity,
                    "price": current_price,
                    "amount": amount,
                    "fee": amount * 0.001,
                    "timestamp": datetime.fromtimestamp(current_time_for_day).isoformat(),
                })

                print(f"   ✅ {symbol} 买入: {quantity:.6f} @ ${current_price:,.2f} = ${amount:.2f}")

                # 显示 DCA 进度
                stats = dca.get_statistics(symbol, current_price)
                if stats:
                    print(f"      进度: {stats['progress_pct']:.1f}% | 平均成本: ${stats['average_cost']:.2f}")

    # 显示账户快照
    print(f"\n   💰 账户快照:")
    print(f"      现金余额: ${current_balance:,.2f}")

    positions = shadow.get_positions()
    if positions:
        total_value = 0
        for pos_symbol, quantity in positions.items():
            pos_value = quantity * current_prices.get(pos_symbol, 0)
            total_value += pos_value
            print(f"      {pos_symbol}: {quantity:.6f} = ${pos_value:,.2f}")

        total_assets = current_balance + total_value
        print(f"      总资产: ${total_assets:,.2f}")

# ========== 最终统计 ==========
print("\n" + "=" * 80)
print("📈 最终统计")
print("=" * 80)

print(f"\n✅ 总交易次数: {len(trading_log)}")

# 按币种统计
symbol_stats = {}
for trade in trading_log:
    symbol = trade["symbol"]
    if symbol not in symbol_stats:
        symbol_stats[symbol] = {"count": 0, "total_amount": 0, "total_quantity": 0}

    symbol_stats[symbol]["count"] += 1
    symbol_stats[symbol]["total_amount"] += trade["amount"]
    symbol_stats[symbol]["total_quantity"] += trade["quantity"]

print("\n💵 按币种统计:")
for symbol in trading_symbols:
    if symbol in symbol_stats:
        stats = symbol_stats[symbol]
        avg_cost = stats["total_amount"] / stats["total_quantity"] if stats["total_quantity"] > 0 else 0
        print(f"   {symbol}:")
        print(f"      投入次数: {stats['count']}")
        print(f"      总投入: ${stats['total_amount']:.2f}")
        print(f"      总数量: {stats['total_quantity']:.6f}")
        print(f"      平均成本: ${avg_cost:.2f}")

# 最终持仓评估
print(f"\n📊 最终持仓评估:")
print("-" * 60)

final_positions = shadow.get_positions()
total_cost = sum(trade["amount"] for trade in trading_log)
total_value = current_balance

print(f"初始余额: $1,000.00")
print(f"总投入: ${total_cost:.2f}")
print(f"现金余额: ${current_balance:.2f}")

for symbol in trading_symbols:
    if symbol in final_positions:
        quantity = final_positions[symbol]
        current_price = current_prices[symbol]
        position_value = quantity * current_price
        total_value += position_value

        # 计算成本
        position_cost = sum(t["amount"] for t in trading_log if t["symbol"] == symbol)
        unrealized_pnl = position_value - position_cost
        pnl_pct = (unrealized_pnl / position_cost * 100) if position_cost > 0 else 0

        print(f"\n{symbol}:")
        print(f"   持仓数量: {quantity:.6f}")
        print(f"   当前价格: ${current_price:.2f}")
        print(f"   头寸价值: ${position_value:.2f}")
        print(f"   成本: ${position_cost:.2f}")
        print(f"   未实现PnL: ${unrealized_pnl:+.2f} ({pnl_pct:+.1f}%)")

print(f"\n📈 账户总价值: ${total_value:,.2f}")
print(f"   投资收益: ${total_value - 1000:+.2f} ({(total_value - 1000) / 10 * 100:+.1f}%)")

# ========== 生成交易日志 ==========
print("\n" + "=" * 80)
print("💾 保存交易日志")
print("=" * 80)

log_file = Path(__file__).parent / "storage" / "shadow_dca_log.jsonl"
log_file.parent.mkdir(parents=True, exist_ok=True)

with open(log_file, "w", encoding="utf-8") as f:
    for trade in trading_log:
        f.write(json.dumps(trade, ensure_ascii=False) + "\n")

print(f"✅ 交易日志已保存: {log_file}")
print(f"   共 {len(trading_log)} 条交易记录")

# ========== 导出 DCA 状态 ==========
print("\n💾 导出 DCA 状态")
print("-" * 60)

dca_state = dca.export_state()
dca_file = Path(__file__).parent / "storage" / "dca_state.json"

with open(dca_file, "w", encoding="utf-8") as f:
    f.write(dca_state)

print(f"✅ DCA 状态已保存: {dca_file}")

# ========== 执行器统计 ==========
print("\n📊 执行器统计")
print("-" * 60)

exec_summary = executor.get_execution_summary()
print(f"总订单数: {exec_summary['total_orders']}")
print(f"成功订单: {exec_summary['successful_orders']}")
print(f"成功率: {exec_summary['success_rate_pct']:.1f}%")
print(f"总手续费: ${exec_summary['total_fee']:.2f}")

# ========== 测试总结 ==========
print("\n" + "=" * 80)
print("✅ Shadow Mode DCA 定投测试完成")
print("=" * 80)

print(f"""
📊 测试摘要:
   ✅ 运行天数: 10 天
   ✅ 定投币种: {len(trading_symbols)} 个
   ✅ 总交易次数: {len(trading_log)}
   ✅ 总投入金额: ${total_cost:.2f}
   ✅ 最终账户价值: ${total_value:,.2f}
   ✅ 投资收益: ${total_value - 1000:+.2f}

🎯 下一步建议:
   1. 检查 shadow_dca_log.jsonl 中的交易详情
   2. 分析 DCA 策略的有效性
   3. 调整定投金额或币种
   4. 在实际市场数据上进行回测
   5. 集成 AI 决策引擎进行优化

💡 关键指标:
   • 平均每笔投入: ${total_cost / len(trading_log) if trading_log else 0:.2f}
   • 交易成功率: {exec_summary['success_rate_pct']:.1f}%
   • 总成本: ${total_cost:.2f}
   • 总收益: ${total_value - total_cost - 1000:+.2f}

📁 生成的文件:
   • {log_file}
   • {dca_file}
""")

print("✅ 测试完成！")
