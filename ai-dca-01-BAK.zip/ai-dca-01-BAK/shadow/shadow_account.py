from typing import Dict, List
from dataclasses import dataclass, field
import json

@dataclass
class ShadowPosition:
    symbol: str
    entry_price: float
    quantity: float
    direction: str  # LONG or SHORT

@dataclass
class ShadowAccount:
    """Shadow trading account for risk-free testing"""
    equity: float = 1000.0
    positions: List[ShadowPosition] = field(default_factory=list)
    pnl_history: List[float] = field(default_factory=list)
    max_drawdown: float = 0.0
    
    def apply_decision(self, decision: Dict, current_price: float) -> Dict:
        """Apply AI decision to shadow account"""
        action = decision.get("action", "HOLD")
        
        if action == "BUY":
            return self._apply_buy(decision, current_price)
        elif action == "SELL":
            return self._apply_sell(decision, current_price)
        else:
            return {"status": "HOLD"}
    
    def _apply_buy(self, decision: Dict, current_price: float) -> Dict:
        """Simulate BUY"""
        quantity = 0.01
        position = ShadowPosition(
            symbol=decision["symbol"],
            entry_price=current_price,
            quantity=quantity,
            direction=decision.get("direction", "LONG")
        )
        self.positions.append(position)
        
        return {
            "status": "EXECUTED",
            "action": "BUY",
            "symbol": decision["symbol"],
            "quantity": quantity,
            "price": current_price
        }
    
    def _apply_sell(self, decision: Dict, current_price: float) -> Dict:
        """Simulate SELL"""
        symbol = decision["symbol"]
        
        pnl = 0.0
        for pos in self.positions[:]:
            if pos.symbol == symbol:
                pnl = (current_price - pos.entry_price) * pos.quantity
                self.positions.remove(pos)
                self.pnl_history.append(pnl)
                break
        
        return {
            "status": "CLOSED",
            "action": "SELL",
            "symbol": symbol,
            "pnl": pnl
        }
    
    def get_summary(self) -> Dict:
        """Get shadow account summary"""
        total_pnl = sum(self.pnl_history) if self.pnl_history else 0.0
        
        return {
            "equity": self.equity + total_pnl,
            "pnl": total_pnl,
            "positions": len(self.positions),
            "trades": len(self.pnl_history),
            "max_drawdown": self.max_drawdown
        }
    
    def buy(self, symbol: str, quantity: float, price: float) -> Dict:
        """Buy (add position)"""
        position = ShadowPosition(
            symbol=symbol,
            entry_price=price,
            quantity=quantity,
            direction="LONG"
        )
        self.positions.append(position)
        
        return {
            "status": "EXECUTED",
            "action": "BUY",
            "symbol": symbol,
            "quantity": quantity,
            "price": price
        }
    
    def sell(self, symbol: str, quantity: float = None, price: float = 0) -> Dict:
        """Sell (close position)"""
        pnl = 0.0
        sold_quantity = 0.0
        
        for pos in self.positions[:]:
            if pos.symbol == symbol:
                if quantity is None or sold_quantity < quantity:
                    sell_qty = min(pos.quantity, quantity - sold_quantity if quantity else pos.quantity)
                    pnl += (price - pos.entry_price) * sell_qty
                    pos.quantity -= sell_qty
                    sold_quantity += sell_qty
                    
                    if pos.quantity <= 0:
                        self.positions.remove(pos)
                    
                    if quantity and sold_quantity >= quantity:
                        break
        
        self.pnl_history.append(pnl)
        
        return {
            "status": "EXECUTED",
            "action": "SELL",
            "symbol": symbol,
            "quantity": sold_quantity,
            "pnl": pnl
        }
    
    def get_positions(self) -> Dict[str, float]:
        """Get all positions as {symbol: quantity}"""
        positions = {}
        for pos in self.positions:
            if pos.symbol not in positions:
                positions[pos.symbol] = 0
            positions[pos.symbol] += pos.quantity
        return positions
